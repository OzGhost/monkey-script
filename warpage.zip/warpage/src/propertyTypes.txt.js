var src = src || {}
  src.propertyTypes = [ {
    "code" : "1",
    "language" : "de",
    "shortcut" : "EFH",
    "description" : "Einfamilienhaus",
    "sortNr" : 1100
  }, {
    "code" : "1",
    "language" : "fr",
    "shortcut" : "MaFam",
    "description" : "Maison familiale",
    "sortNr" : 1100
  }, {
    "code" : "1",
    "language" : "en",
    "shortcut" : "FamHo",
    "description" : "Single-family home",
    "sortNr" : 1100
  }, {
    "code" : "2",
    "language" : "de",
    "shortcut" : "STWE",
    "description" : "Stockwerkeigentum",
    "sortNr" : 1300
  }, {
    "code" : "2",
    "language" : "fr",
    "shortcut" : "Propr",
    "description" : "Propriété par étage",
    "sortNr" : 1300
  }, {
    "code" : "2",
    "language" : "en",
    "shortcut" : "EFO",
    "description" : "Residential flat",
    "sortNr" : 1300
  }, {
    "code" : "3",
    "language" : "de",
    "shortcut" : "MFH",
    "description" : "Mehrfamilienhaus",
    "sortNr" : 1200
  }, {
    "code" : "3",
    "language" : "fr",
    "shortcut" : "Immeu",
    "description" : "Immeuble locatif",
    "sortNr" : 1200
  }, {
    "code" : "3",
    "language" : "en",
    "shortcut" : "MFH",
    "description" : "Multi-family house",
    "sortNr" : 1200
  }, {
    "code" : "4",
    "language" : "de",
    "shortcut" : "WoBür",
    "description" : "Wohnen / Büro",
    "sortNr" : 2000
  }, {
    "code" : "4",
    "language" : "fr",
    "shortcut" : "HabB",
    "description" : "Habitation / bureau",
    "sortNr" : 2000
  }, {
    "code" : "4",
    "language" : "en",
    "shortcut" : "HoOf",
    "description" : "Home/office",
    "sortNr" : 2000
  }, {
    "code" : "5",
    "language" : "de",
    "shortcut" : "WoGew",
    "description" : "Wohnen / Gewerbe",
    "sortNr" : 2100
  }, {
    "code" : "5",
    "language" : "fr",
    "shortcut" : "HaArM",
    "description" : "Habitation / artisanat",
    "sortNr" : 2100
  }, {
    "code" : "5",
    "language" : "en",
    "shortcut" : "Ho/Co",
    "description" : "Home/commerce",
    "sortNr" : 2100
  }, {
    "code" : "6",
    "language" : "de",
    "shortcut" : "LW",
    "description" : "Landwirtschaft",
    "sortNr" : 2300
  }, {
    "code" : "6",
    "language" : "fr",
    "shortcut" : "AGR",
    "description" : "Agriculture",
    "sortNr" : 2300
  }, {
    "code" : "6",
    "language" : "en",
    "shortcut" : "AGRIC",
    "description" : "Agriculture",
    "sortNr" : 2300
  }, {
    "code" : "7",
    "language" : "de",
    "shortcut" : "Land",
    "description" : "Land",
    "sortNr" : 4100
  }, {
    "code" : "7",
    "language" : "fr",
    "shortcut" : "Terra",
    "description" : "Terrain",
    "sortNr" : 4100
  }, {
    "code" : "7",
    "language" : "en",
    "shortcut" : "Count",
    "description" : "Country",
    "sortNr" : 4100
  }, {
    "code" : "9",
    "language" : "de",
    "shortcut" : "G/I",
    "description" : "Gewerbe / Industrie",
    "sortNr" : 2200
  }, {
    "code" : "9",
    "language" : "fr",
    "shortcut" : "AR/IN",
    "description" : "Artisanat / industrie",
    "sortNr" : 2200
  }, {
    "code" : "9",
    "language" : "en",
    "shortcut" : "COIND",
    "description" : "Commerce/industry",
    "sortNr" : 2200
  }, {
    "code" : "11",
    "language" : "de",
    "shortcut" : "ÜObj",
    "description" : "Übrige Objekte",
    "sortNr" : 9999
  }, {
    "code" : "11",
    "language" : "fr",
    "shortcut" : "Aobj.",
    "description" : "Autres objets",
    "sortNr" : 9999
  }, {
    "code" : "11",
    "language" : "en",
    "shortcut" : "OthOb",
    "description" : "Other objects",
    "sortNr" : 9999
  } ]
