var prop_empty = {
    "key": "",
    "designation": "",
    "address": {
        "street": "",
        "postcode": "",
        "place": "",
        "country:country": {
            "href": ""
        },
        "_links": {
            "curies": [
                {
                    "name": "",
                    "href": "",
                    "templated": null
                }
            ]
        }
    },
    "landRegisterNumber": {
        "number1": "",
        "number2": null,
        "number3": null
    },
    "landRegistryLocation": "",
    "landRegisterOffice": "",
    "taxMunicipality": null,
    "egrid": null,
    "loanToValueRatio": 0,
    "residentialSpaceRate": 0,
    "masterPlot": {
        "landRegNumber1": null,
        "landRegNumber2": null,
        "landRegNumber3": null
    },
    "valueOfShareNumerator": null,
    "valueOfShareDenominator": null,
    "owners": [
        {
            "clientKey": "",
            "designation": "",
            "ownershipRelationship:ownershipStructure": {
                "href": 0
            },
            "_links": {
                "curies": [
                    {
                        "name": "",
                        "href": "",
                        "templated": null
                    }
                ]
            }
        }
    ],
    "propertyType:propertyType": {
        "href": 0
    },
    "propertyTypeOfUse:usageType": {
        "href": 0
    },
    "buildingType:buildingType": {
        "href": 0
    },
    "typeOfConstruction:typeOfConstruction": {
        "href": 0
    },
    "buildingResidenceType:buildingResidenceType": {
        "href": 0
    },
    "_links": {
        "curies": [
            {
                "name": "",
                "href": "",
                "templated": null
            },
            {
                "name": "",
                "href": "",
                "templated": null
            },
            {
                "name": "",
                "href": "",
                "templated": null
            },
            {
                "name": "",
                "href": "",
                "templated": null
            },
            {
                "name": "",
                "href": "",
                "templated": null
            }
        ]
    }
}
