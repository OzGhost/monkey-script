var src = src || {}
src.orderSecurity = [
	{
    "orderKeyOnlyForFinnova": "54530902270136",
    "securities": [
      {
        "key": "40913551429310",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598700",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 120000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551429310",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598700",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 120000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551429310",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598700",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 120000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551429310",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598700",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 120000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551429310",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598700",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 120000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551429310",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598700",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 120000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551429310",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598700",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 120000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551429310",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598700",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 120000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568564",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598701",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568564",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598701",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568564",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598701",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568564",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598701",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568564",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598701",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568564",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598701",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568564",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598701",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568564",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598701",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568565",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598702",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 280000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568565",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598702",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 280000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568565",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598702",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 280000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568565",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598702",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 280000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568565",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598702",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 280000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568565",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598702",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 280000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568565",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598702",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 280000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568565",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598702",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 280000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568566",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598703",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568566",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598703",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568566",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598703",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568566",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598703",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568566",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598703",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568566",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598703",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568566",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598703",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568566",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598703",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568567",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598704",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568567",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598704",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568567",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598704",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568567",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598704",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568567",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598704",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568567",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598704",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568567",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598704",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568567",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598704",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568568",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598705",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568568",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598705",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568568",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598705",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568568",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598705",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568568",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598705",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568568",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598705",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568568",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598705",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568568",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598705",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568569",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598706",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568569",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598706",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568569",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598706",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568569",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598706",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568569",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598706",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568569",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598706",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568569",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598706",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568569",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598706",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568643",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598707",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 96000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 4000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568643",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598707",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 96000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 4000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568643",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598707",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 96000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 4000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568643",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598707",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 96000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 4000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568643",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598707",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 96000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 4000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568643",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598707",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 96000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 4000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568643",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598707",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 96000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 4000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913549568643",
        "designation": "1959   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913558598707",
          "propertyKey": "40913296211527",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Lastname Firstname",
        "collateralValue": {
          "amount": 2256000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 96000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 4000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 2820000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      }
    ]
  },
  {
    "orderKeyOnlyForFinnova": "62964341203191",
    "securities": [
      {
        "key": "40913548534551",
        "designation": "3060   Adelboden EFH",
        "securityMortgageCertificate": {
          "key": "40913558489221",
          "propertyKey": "40913296212852",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "14.012.023 Lastname Firstname",
        "collateralValue": {
          "amount": 173250,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 231000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 1
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548534551",
        "designation": "3060   Adelboden EFH",
        "securityMortgageCertificate": {
          "key": "40913558489221",
          "propertyKey": "40913296212852",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "14.012.023 Lastname Firstname",
        "collateralValue": {
          "amount": 173250,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 231000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 1
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548534553",
        "designation": "3060   Adelboden EFH",
        "securityMortgageCertificate": {
          "key": "40913558489222",
          "propertyKey": "40913296212852",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "14.012.023 Lastname Firstname",
        "collateralValue": {
          "amount": 173250,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 231000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 1
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548534553",
        "designation": "3060   Adelboden EFH",
        "securityMortgageCertificate": {
          "key": "40913558489222",
          "propertyKey": "40913296212852",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "14.012.023 Lastname Firstname",
        "collateralValue": {
          "amount": 173250,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 231000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 1
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      }
    ]
  },
  {
    "orderKeyOnlyForFinnova": "59560732583955",
    "securities": [
      {
        "key": "40913548740726",
        "designation": "9930   KÃ¶niz EFH",
        "securityMortgageCertificate": {
          "key": "40913558706352",
          "propertyKey": "40913282011500",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.157.779 Lastname Firstname",
        "collateralValue": {
          "amount": 566400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 410000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 708000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 1
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      }
    ]
  },
  {
    "orderKeyOnlyForFinnova": "59093316108491",
    "securities": [
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430076",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804940",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 50000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913548430077",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804941",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 200000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222766",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804934",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 8000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222767",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804935",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 13000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222768",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804936",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 40000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "43309914554979",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "43309913054734",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 259000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 88000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222858",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804937",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 10000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222861",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804938",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913551222863",
        "designation": "3251   Wohlen b. Bern MFH",
        "securityMortgageCertificate": {
          "key": "40913560804939",
          "propertyKey": "40913322583453",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Lastname Firstname",
        "taker": "13.156.728 Lastname Firstname",
        "collateralValue": {
          "amount": 708000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 20000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 885000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      }
    ]
  },
  {
    "orderKeyOnlyForFinnova": "52665579170713",
    "securities": [
      {
        "key": "40913550392568",
        "designation": "1918-2   Neuenegg STWE",
        "securityMortgageCertificate": {
          "key": "40913560910244",
          "propertyKey": "40913297033235",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "abc def",
        "taker": "13.183.671 abc def",
        "collateralValue": {
          "amount": 456000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 458000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 570000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 2
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913553558652",
        "designation": "42 8.266.788.08 PRIVOR Vorsorgekonto 3a",
        "securityMortgageCertificate": null,
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": {
          "accountKey": "40909244808718",
          "accountNumber": "42 8.266.788.08",
          "category": "PRIVOR VORSORGE 3A",
          "balance": {
            "amount": 51720.75,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          }
        },
        "provider": "Aeschlimann Beat",
        "taker": "13.183.671 Aeschlimann Beat",
        "collateralValue": {
          "amount": 51720.75,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 49697.6,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 2023.15,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 51720.75,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1100
        },
        "CollateralSubtypes:subType": {
          "href": 1105
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913553558430",
        "designation": "100000 Rentenanstalt / Swiss Life",
        "securityMortgageCertificate": null,
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "Aeschlimann Beat",
        "taker": "13.183.671 Aeschlimann Beat",
        "collateralValue": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": {
          "insuranceCompanyKey": "40907952332326",
          "insuranceHolder": "Aeschlimann Beat (1964), Köniz",
          "insuredPerson": "Aeschlimann Beat (1964), Köniz",
          "beneficiary": null,
          "nominal": {
            "amount": 100000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "premium": null,
          "expiryDate": "2020-12-01",
          "securitiesNumber": null,
          "securitiesShortText": null
        },
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 0,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1400
        },
        "CollateralSubtypes:subType": {
          "href": 1401
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      }
    ]
  },
  {
    "orderKeyOnlyForFinnova": "62057340725463",
    "securities": [
      {
        "key": "40913547501192",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696404",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501192",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696404",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501192",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696404",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501192",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696404",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501192",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696404",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501192",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696404",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501192",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696404",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501192",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696404",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 1000000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501193",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696405",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 400000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501193",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696405",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 400000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501193",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696405",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 400000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501193",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696405",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 400000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501193",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696405",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 400000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501193",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696405",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 400000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501193",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696405",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 400000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501193",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696405",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 400000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501194",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696406",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501194",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696406",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501194",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696406",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501194",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696406",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501194",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696406",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501194",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696406",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501194",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696406",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501194",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696406",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501195",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696407",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501195",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696407",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501195",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696407",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501195",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696407",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501195",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696407",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501195",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696407",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501195",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696407",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501195",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696407",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501196",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696408",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501196",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696408",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501196",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696408",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501196",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696408",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501196",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696408",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501196",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696408",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501196",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696408",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501196",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696408",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501197",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696409",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501197",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696409",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501197",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696409",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501197",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696409",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501197",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696409",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501197",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696409",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501197",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696409",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501197",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696409",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501198",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696410",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501198",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696410",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501198",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696410",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501198",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696410",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501198",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696410",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501198",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696410",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501198",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696410",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501198",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696410",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501199",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696411",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501199",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696411",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501199",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696411",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501199",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696411",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501199",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696411",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501199",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696411",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501199",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696411",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "key": "40913547501199",
        "designation": "1976   Neuenegg MFH",
        "securityMortgageCertificate": {
          "key": "40913560696411",
          "propertyKey": "40913324985400",
          "isMultipleLien": false
        },
        "portfolioKey": null,
        "portfolioNumber": null,
        "accountCustodyAccount": null,
        "provider": "mehrere",
        "taker": "13.986.226 Gasser Klaus",
        "collateralValue": {
          "amount": 2426400,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "claimedLending": {
          "amount": 100000,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "availableLending": {
          "amount": 0,
          "currency:currency": {
            "href": "CHF"
          },
          "_links": {
            "curies": [
              {
                "name": "currency",
                "href": "/v2/banks/6300/codes/Currencies/{rel}",
                "templated": true
              }
            ]
          }
        },
        "insurance": null,
        "guarantee": null,
        "marketValue": {
          "value": {
            "amount": 3033000,
            "currency:currency": {
              "href": "CHF"
            },
            "_links": {
              "curies": [
                {
                  "name": "currency",
                  "href": "/v2/banks/6300/codes/Currencies/{rel}",
                  "templated": true
                }
              ]
            }
          },
          "date": null
        },
        "CollateralTypes:type": {
          "href": 1000
        },
        "CollateralSubtypes:subType": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "CollateralTypes",
              "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
              "templated": true
            },
            {
              "name": "CollateralSubtypes",
              "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
              "templated": true
            }
          ]
        }
      }
    ]
  },
  {
	"orderKeyOnlyForFinnova" : "63915860156330",
	"securities" : 
	[
	  {
		"key": "40913553869606",
		"designation": "250000 ZÃ¼rich Lebensversicherungs-",
		"securityMortgageCertificate": null,
		"portfolioKey": null,
		"portfolioNumber": null,
		"accountCustodyAccount": null,
		"provider": "AbbÃ¼hl Ulrich",
		"taker": "13.152.782 AbbÃ¼hl Ulrich",
		"collateralValue": {
		  "amount": 180994.37,
		  "currency:currency": {
			"href": "CHF"
		  },
		  "_links": {
			"curies": [
			  {
				"name": "currency",
				"href": "/v2/banks/6300/codes/Currencies/{rel}",
				"templated": true
			  }
			]
		  }
		},
		"claimedLending": {
		  "amount": 150000,
		  "currency:currency": {
			"href": "CHF"
		  },
		  "_links": {
			"curies": [
			  {
				"name": "currency",
				"href": "/v2/banks/6300/codes/Currencies/{rel}",
				"templated": true
			  }
			]
		  }
		},
		"availableLending": {
		  "amount": 30994.37,
		  "currency:currency": {
			"href": "CHF"
		  },
		  "_links": {
			"curies": [
			  {
				"name": "currency",
				"href": "/v2/banks/6300/codes/Currencies/{rel}",
				"templated": true
			  }
			]
		  }
		},
		"insurance": {
		  "insuranceCompanyKey": "40907983333133",
		  "insuranceHolder": "AbbÃ¼hl Ulrich (1957), KÃ¼ttigkofen",
		  "insuredPerson": "AbbÃ¼hl Ulrich, KÃ¼ttigkofen",
		  "beneficiary": null,
		  "nominal": {
			"amount": 250000,
			"currency:currency": {
			  "href": "CHF"
			},
			"_links": {
			  "curies": [
				{
				  "name": "currency",
				  "href": "/v2/banks/6300/codes/Currencies/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  "premium": null,
		  "expiryDate": "2020-03-01",
		  "securitiesNumber": null,
		  "securitiesShortText": null
		},
		"guarantee": null,
		"marketValue": {
		  "value": {
			"amount": 201104.85,
			"currency:currency": {
			  "href": "CHF"
			},
			"_links": {
			  "curies": [
				{
				  "name": "currency",
				  "href": "/v2/banks/6300/codes/Currencies/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  "date": "2015-01-31"
		},
		"CollateralTypes:type": {
		  "href": 1400
		},
		"CollateralSubtypes:subType": {
		  "href": 1403
		},
		"_links": {
		  "curies": [
			{
			  "name": "CollateralTypes",
			  "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
			  "templated": true
			},
			{
			  "name": "CollateralSubtypes",
			  "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
			  "templated": true
			}
		  ]
		}
	  }
	]
  }
]
