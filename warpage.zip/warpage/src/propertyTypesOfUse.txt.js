var src = src || {}
  src.propertyTypesOfUse = [ {
    "code" : "1",
    "language" : "de",
    "shortcut" : "Wohn",
    "description" : "Wohnen",
    "sortNr" : 9999
  }, {
    "code" : "1",
    "language" : "fr",
    "shortcut" : "Habit",
    "description" : "Habitation",
    "sortNr" : 9999
  }, {
    "code" : "1",
    "language" : "en",
    "shortcut" : "OU",
    "description" : "Own use",
    "sortNr" : 9999
  }, {
    "code" : "10",
    "language" : "de",
    "shortcut" : "Fer",
    "description" : "Ferien",
    "sortNr" : 9999
  }, {
    "code" : "10",
    "language" : "fr",
    "shortcut" : "Vacan",
    "description" : "Vacances",
    "sortNr" : 9999
  }, {
    "code" : "10",
    "language" : "en",
    "shortcut" : "HOLS",
    "description" : "Holidays",
    "sortNr" : 9999
  }, {
    "code" : "11",
    "language" : "de",
    "shortcut" : "HoRes",
    "description" : "Hotel/ Restaurant",
    "sortNr" : 9999
  }, {
    "code" : "11",
    "language" : "fr",
    "shortcut" : "HôRes",
    "description" : "Hôtel / restaurant",
    "sortNr" : 9999
  }, {
    "code" : "11",
    "language" : "en",
    "shortcut" : "HoRes",
    "description" : "Hotel/ Restaurant",
    "sortNr" : 9999
  }, {
    "code" : "12",
    "language" : "de",
    "shortcut" : "Gewe",
    "description" : "Gewerbe",
    "sortNr" : 9999
  }, {
    "code" : "12",
    "language" : "fr",
    "shortcut" : "Artis",
    "description" : "Artisanat",
    "sortNr" : 9999
  }, {
    "code" : "12",
    "language" : "en",
    "shortcut" : "Comme",
    "description" : "Commerce",
    "sortNr" : 9999
  }, {
    "code" : "13",
    "language" : "de",
    "shortcut" : "Büro",
    "description" : "Büro",
    "sortNr" : 9999
  }, {
    "code" : "13",
    "language" : "fr",
    "shortcut" : "Bure",
    "description" : "Bureau",
    "sortNr" : 9999
  }, {
    "code" : "13",
    "language" : "en",
    "shortcut" : "Offic",
    "description" : "Office",
    "sortNr" : 9999
  }, {
    "code" : "14",
    "language" : "de",
    "shortcut" : "Indus",
    "description" : "Industrie",
    "sortNr" : 9999
  }, {
    "code" : "14",
    "language" : "fr",
    "shortcut" : "Indus",
    "description" : "Industrie",
    "sortNr" : 9999
  }, {
    "code" : "14",
    "language" : "en",
    "shortcut" : "Indus",
    "description" : "Industry",
    "sortNr" : 9999
  }, {
    "code" : "110",
    "language" : "de",
    "shortcut" : "Gem.",
    "description" : "Gemischte Nutzung",
    "sortNr" : 9999
  }, {
    "code" : "110",
    "language" : "fr",
    "shortcut" : "Utili",
    "description" : "Utilisation mixte",
    "sortNr" : 9999
  }, {
    "code" : "110",
    "language" : "en",
    "shortcut" : "Mixed",
    "description" : "Mixed usage",
    "sortNr" : 9999
  }, {
    "code" : "135",
    "language" : "de",
    "shortcut" : "HeSpi",
    "description" : "Heim / Spital",
    "sortNr" : 9999
  }, {
    "code" : "135",
    "language" : "fr",
    "shortcut" : "EM/HO",
    "description" : "EMS / hôpital",
    "sortNr" : 9999
  }, {
    "code" : "135",
    "language" : "en",
    "shortcut" : "ReCom",
    "description" : "Residential and commercial building >=50%",
    "sortNr" : 9999
  }, {
    "code" : "150",
    "language" : "de",
    "shortcut" : "Luxus",
    "description" : "Luxus",
    "sortNr" : 9999
  }, {
    "code" : "150",
    "language" : "fr",
    "shortcut" : "Luxe",
    "description" : "Luxe",
    "sortNr" : 9999
  }, {
    "code" : "150",
    "language" : "en",
    "shortcut" : "Luxur",
    "description" : "Luxury",
    "sortNr" : 9999
  }, {
    "code" : "160",
    "language" : "de",
    "shortcut" : "Wohn",
    "description" : "Wohnen Eigennutzung",
    "sortNr" : 9999
  }, {
    "code" : "160",
    "language" : "fr",
    "shortcut" : "Habit",
    "description" : "Habitation Usage propre",
    "sortNr" : 9999
  }, {
    "code" : "160",
    "language" : "en",
    "shortcut" : "OU",
    "description" : "Own use",
    "sortNr" : 9999
  }, {
    "code" : "161",
    "language" : "de",
    "shortcut" : "Wohn",
    "description" : "Wohnen Eigennutzung und Vermietet",
    "sortNr" : 9999
  }, {
    "code" : "161",
    "language" : "fr",
    "shortcut" : "Habit",
    "description" : "Habitation Usage propre et location",
    "sortNr" : 9999
  }, {
    "code" : "161",
    "language" : "en",
    "shortcut" : "OU",
    "description" : "Own use and letting/lease",
    "sortNr" : 9999
  }, {
    "code" : "162",
    "language" : "de",
    "shortcut" : "Wohn",
    "description" : "Wohnen Vermietet",
    "sortNr" : 9999
  }, {
    "code" : "162",
    "language" : "fr",
    "shortcut" : "Habit",
    "description" : "Habitation location",
    "sortNr" : 9999
  }, {
    "code" : "162",
    "language" : "en",
    "shortcut" : "LL",
    "description" : "Let/lease",
    "sortNr" : 9999
  }, {
    "code" : "170",
    "language" : "de",
    "shortcut" : "FerEi",
    "description" : "Ferien Eigennutzung",
    "sortNr" : 9999
  }, {
    "code" : "170",
    "language" : "fr",
    "shortcut" : "Vacan",
    "description" : "Vacances Usage propre",
    "sortNr" : 9999
  }, {
    "code" : "170",
    "language" : "en",
    "shortcut" : "HOL",
    "description" : "Holidays own use",
    "sortNr" : 9999
  }, {
    "code" : "171",
    "language" : "de",
    "shortcut" : "FerEi",
    "description" : "Ferien Eigennutzung und Vermietet",
    "sortNr" : 9999
  }, {
    "code" : "171",
    "language" : "fr",
    "shortcut" : "Vacan",
    "description" : "Vacances Usage propre et location",
    "sortNr" : 9999
  }, {
    "code" : "171",
    "language" : "en",
    "shortcut" : "HOL",
    "description" : "Holidays Own use and letting/lease",
    "sortNr" : 9999
  }, {
    "code" : "172",
    "language" : "de",
    "shortcut" : "FVerm",
    "description" : "Ferien Vermietet",
    "sortNr" : 9999
  }, {
    "code" : "172",
    "language" : "fr",
    "shortcut" : "Vacan",
    "description" : "Vacances location",
    "sortNr" : 9999
  }, {
    "code" : "172",
    "language" : "en",
    "shortcut" : "HOL",
    "description" : "Holidays let/lease",
    "sortNr" : 9999
  }, {
    "code" : "180",
    "language" : "de",
    "shortcut" : "LuxEi",
    "description" : "Luxus Eigennutzung",
    "sortNr" : 9999
  }, {
    "code" : "180",
    "language" : "fr",
    "shortcut" : "Luxup",
    "description" : "Luxe Usage propre",
    "sortNr" : 9999
  }, {
    "code" : "180",
    "language" : "en",
    "shortcut" : "Luxu",
    "description" : "Luxury Own use",
    "sortNr" : 9999
  }, {
    "code" : "181",
    "language" : "de",
    "shortcut" : "LuxEV",
    "description" : "Luxus Eigennutzung und Vermietet",
    "sortNr" : 9999
  }, {
    "code" : "181",
    "language" : "fr",
    "shortcut" : "Luxul",
    "description" : "Luxe Usage propre et location",
    "sortNr" : 9999
  }, {
    "code" : "181",
    "language" : "en",
    "shortcut" : "Lux",
    "description" : "Luxury Own use and letting/lease",
    "sortNr" : 9999
  }, {
    "code" : "182",
    "language" : "de",
    "shortcut" : "LuxV",
    "description" : "Luxus Vermietet",
    "sortNr" : 9999
  }, {
    "code" : "182",
    "language" : "fr",
    "shortcut" : "LuxuL",
    "description" : "Luxe location",
    "sortNr" : 9999
  }, {
    "code" : "182",
    "language" : "en",
    "shortcut" : "Lux",
    "description" : "Luxury Let/lease",
    "sortNr" : 9999
  } ]
