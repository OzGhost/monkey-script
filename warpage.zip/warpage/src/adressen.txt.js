var src = src || {}
src.adressen = [
  {
    "addressNumber": 11,
    "clientNumber": "13986226",
    "country": "country-1",
    "id": "40907937079144-11",
    "place": "Ho Chi Minh",
    "poBox": null,
    "receiverReference": null,
    "salutation": "customerSalutation-2",
    "street": "Duong Cong Khi 28",
    "zipCode": "7710"
  },
  {
    "addressNumber": 11,
    "clientNumber": "14012023",
    "country": "country-1",
    "id": "40907908177191-11",
    "place": "Viano",
    "poBox": null,
    "receiverReference": "Trung Ly",
    "salutation": null,
    "street": null,
    "zipCode": "7747"
  },
  {
    "addressNumber": 11,
    "clientNumber": "13157779",
    "country": "country-1",
    "id": "40907883083914-11",
    "place": "Brusio",
    "poBox": null,
    "receiverReference": null,
    "salutation": "customerSalutation-1",
    "street": "Vancouver 78",
    "zipCode": "7743"
  },
  {
    "addressNumber": 11,
    "clientNumber": "13156728",
    "country": "country-1",
    "id": "40907944905943-11",
    "place": "Valchava",
    "poBox": null,
    "receiverReference": null,
    "salutation": "customerSalutation-2",
    "street": "Tokyo 65",
    "zipCode": "7535"
  },
  {
    "addressNumber": 11,
    "clientNumber": "13152782",
    "country": "country-1",
    "id": "40907948419302-11",
    "place": "Obermutten",
    "poBox": null,
    "receiverReference": "Ho Quang Dieu",
    "salutation": "customerSalutation-2",
    "street": "Tran Quoc Toan 18",
    "zipCode": "7431"
  },
  {
    "addressNumber": 11,
    "clientNumber": "13183671",
    "country": "country-1",
    "id": "40907915403472-11",
    "place": "Nufenen",
    "poBox": null,
    "receiverReference": "Mechaniker",
    "salutation": "customerSalutation-2",
    "street": "Phan Dinh Phung 128",
    "zipCode": "7437"
  }
]
