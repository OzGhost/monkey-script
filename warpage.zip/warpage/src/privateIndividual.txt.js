var src = src || {}
src.privateIndividual = [
  {
    "clientKey": "40907937079144",
    "privateIndividual": {
      "master": {
        "clientNumber": "13986226",
        "editClientNumber": "13.986.226",
        "openingDate": "1900-01-01",
        "closureDate": null,
        "mainAdvisor": {
          "key": 37918336,
          "lastNameFirstName": "Chan Jacky",
          "telephoneNo": "+41 31 311 11 11",
          "email": "Chan.Jacky@valiant.ch"
        },
        "securityAbroad": false,
        "clientDesignation": "Herr Test Tester, Mustertown",
        "domicileAddress": {
          "address": "address 123",
          "postcode": "9999",
          "placeDes": "Z�rich Hometown",
          "country": "CH",
          "_links": {
            "country": {
              "href": "/v1/banks/6300/codes/Countries/CH"
            }
          }
        },
        "relevantTelNo": {
          "tel": "+41 76 777 77 77",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "TN1",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/TN1"
            }
          }
        },
        "relevantEmail": {
          "address": "abc.abc@gmail.com",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "EMP",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/EMP"
            }
          }
        },
        "nogaCode": "970000",
        "identityChecked": true,
        "activeBlock": false,
        "blocks": [],
        "occupationalPension": true,
        "clientMainType": "1",
        "branch": "2003",
        "clientLanguage": "de",
        "clientStatus": "0",
        "legalForm": "102",
        "legalStatus": "",
        "characteristic1": "",
        "characteristic2": "",
        "category": "10",
        "vsbStatus": "3",
        "riskClass": "",
        "riskCategory": "1",
        "groupType": "3",
        "clientSegment": "11",
        "isOccupationalPension": true,
        "_links": {
          "nogaCode": {
            "href": "/v1/banks/6300/codes/NogaCodes/970000"
          },
          "clientMainType": {
            "href": "/v1/banks/6300/codes/ClientMainTypes/1"
          },
          "branch": {
            "href": "/v1/banks/6300/codes/Offices/2003"
          },
          "clientLanguage": {
            "href": "/v1/banks/6300/codes/Languages/de"
          },
          "clientStatus": {
            "href": "/v1/banks/6300/codes/ClientStatus/0"
          },
          "legalForm": {
            "href": "/v1/banks/6300/codes/LegalForms/102"
          },
          "legalStatus": {
            "href": "/v1/banks/6300/codes/LegalStatus/"
          },
          "characteristic1": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "characteristic2": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "category": {
            "href": "/v1/banks/6300/codes/ClientCategories/10"
          },
          "vsbStatus": {
            "href": "/v1/banks/6300/codes/VsbStatus/3"
          },
          "riskClass": {
            "href": "/v1/banks/6300/codes/Mandates/"
          },
          "riskCategory": {
            "href": "/v1/banks/6300/codes/RiskCategories/1"
          },
          "groupType": {
            "href": "/v1/banks/6300/codes/ClientGroups/3"
          },
          "clientSegment": {
            "href": "/v1/banks/6300/codes/ClientSegments/11"
          }
        }
      },
      "person": {
        "firstName": "Firstname",
        "officialFirstName": null,
        "lastName": "Lastname",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 2,
        "dateOfBirth": "1981-01-01",
        "dateOfDeath": null,
        "formOfAddress": "2",
        "title": "",
        "maritalStatus": "1",
        "matrimonialPropertyRegime": "0",
        "countryOfBirth": "CH",
        "nationality": "IT",
        "nationality2": "",
        "profession": "67",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/2"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/1"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/0"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/IT"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/67"
          }
        }
      }
    }
  },
  {
    "clientKey": "40907883083914",
    "privateIndividual": {
      "master": {
        "clientNumber": "13157779",
        "editClientNumber": "13.157.779",
        "openingDate": "1900-01-01",
        "closureDate": null,
        "mainAdvisor": {
          "key": 12345678,
          "lastNameFirstName": "Federer Roger",
          "telephoneNo": "+41 31 311 11 11",
          "email": "Federer.Roger@valiant.ch"
        },
        "securityAbroad": false,
        "clientDesignation": "Herr Test Tester, Mustertown",
        "domicileAddress": {
          "address": "address 123",
          "postcode": "9999",
          "placeDes": "Z�rich Hometown",
          "country": "CH",
          "_links": {
            "country": {
              "href": "/v1/banks/6300/codes/Countries/CH"
            }
          }
        },
        "relevantTelNo": {
          "tel": "+41 76 777 77 77",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "TN1",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/TN1"
            }
          }
        },
        "relevantEmail": {
          "address": "abc.abc@gmail.com",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "EMP",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/EMP"
            }
          }
        },
        "nogaCode": "970000",
        "identityChecked": true,
        "activeBlock": false,
        "blocks": [],
        "occupationalPension": true,
        "clientMainType": "1",
        "branch": "2003",
        "clientLanguage": "de",
        "clientStatus": "0",
        "legalForm": "102",
        "legalStatus": "",
        "characteristic1": "",
        "characteristic2": "",
        "category": "10",
        "vsbStatus": "3",
        "riskClass": "",
        "riskCategory": "1",
        "groupType": "3",
        "clientSegment": "11",
        "isOccupationalPension": true,
        "_links": {
          "nogaCode": {
            "href": "/v1/banks/6300/codes/NogaCodes/970000"
          },
          "clientMainType": {
            "href": "/v1/banks/6300/codes/ClientMainTypes/1"
          },
          "branch": {
            "href": "/v1/banks/6300/codes/Offices/2003"
          },
          "clientLanguage": {
            "href": "/v1/banks/6300/codes/Languages/de"
          },
          "clientStatus": {
            "href": "/v1/banks/6300/codes/ClientStatus/0"
          },
          "legalForm": {
            "href": "/v1/banks/6300/codes/LegalForms/102"
          },
          "legalStatus": {
            "href": "/v1/banks/6300/codes/LegalStatus/"
          },
          "characteristic1": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "characteristic2": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "category": {
            "href": "/v1/banks/6300/codes/ClientCategories/10"
          },
          "vsbStatus": {
            "href": "/v1/banks/6300/codes/VsbStatus/3"
          },
          "riskClass": {
            "href": "/v1/banks/6300/codes/Mandates/"
          },
          "riskCategory": {
            "href": "/v1/banks/6300/codes/RiskCategories/1"
          },
          "groupType": {
            "href": "/v1/banks/6300/codes/ClientGroups/3"
          },
          "clientSegment": {
            "href": "/v1/banks/6300/codes/ClientSegments/11"
          }
        }
      },
      "person": {
        "firstName": "Firstname",
        "officialFirstName": null,
        "lastName": "Lastname",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 2,
        "dateOfBirth": "1981-01-01",
        "dateOfDeath": null,
        "formOfAddress": "2",
        "title": "",
        "maritalStatus": "1",
        "matrimonialPropertyRegime": "0",
        "countryOfBirth": "CH",
        "nationality": "IT",
        "nationality2": "",
        "profession": "67",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/2"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/1"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/0"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/IT"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/67"
          }
        }
      }
    }
  },
  {
    "clientKey": "40907948419302",
    "privateIndividual": {
      "master": {
        "clientNumber": "13152782",
        "editClientNumber": "13.152.782",
        "openingDate": "1900-01-01",
        "closureDate": null,
        "mainAdvisor": {
          "key": 12345678,
          "lastNameFirstName": "Lee Bruce",
          "telephoneNo": "+41 31 311 12 12",
          "email": "Bruce.Lee@valiant.ch"
        },
        "securityAbroad": false,
        "clientDesignation": "Herr Test Tester, Mustertown",
        "domicileAddress": {
          "address": "address 123",
          "postcode": "9999",
          "placeDes": "Z�rich Hometown",
          "country": "CH",
          "_links": {
            "country": {
              "href": "/v1/banks/6300/codes/Countries/CH"
            }
          }
        },
        "relevantTelNo": {
          "tel": "+41 76 777 77 77",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "TN1",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/TN1"
            }
          }
        },
        "relevantEmail": {
          "address": "abc.abc@gmail.com",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "EMP",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/EMP"
            }
          }
        },
        "nogaCode": "970000",
        "identityChecked": true,
        "activeBlock": false,
        "blocks": [],
        "occupationalPension": true,
        "clientMainType": "1",
        "branch": "2003",
        "clientLanguage": "de",
        "clientStatus": "0",
        "legalForm": "102",
        "legalStatus": "",
        "characteristic1": "",
        "characteristic2": "",
        "category": "10",
        "vsbStatus": "3",
        "riskClass": "",
        "riskCategory": "1",
        "groupType": "3",
        "clientSegment": "11",
        "isOccupationalPension": true,
        "_links": {
          "nogaCode": {
            "href": "/v1/banks/6300/codes/NogaCodes/970000"
          },
          "clientMainType": {
            "href": "/v1/banks/6300/codes/ClientMainTypes/1"
          },
          "branch": {
            "href": "/v1/banks/6300/codes/Offices/2003"
          },
          "clientLanguage": {
            "href": "/v1/banks/6300/codes/Languages/de"
          },
          "clientStatus": {
            "href": "/v1/banks/6300/codes/ClientStatus/0"
          },
          "legalForm": {
            "href": "/v1/banks/6300/codes/LegalForms/102"
          },
          "legalStatus": {
            "href": "/v1/banks/6300/codes/LegalStatus/"
          },
          "characteristic1": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "characteristic2": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "category": {
            "href": "/v1/banks/6300/codes/ClientCategories/10"
          },
          "vsbStatus": {
            "href": "/v1/banks/6300/codes/VsbStatus/3"
          },
          "riskClass": {
            "href": "/v1/banks/6300/codes/Mandates/"
          },
          "riskCategory": {
            "href": "/v1/banks/6300/codes/RiskCategories/1"
          },
          "groupType": {
            "href": "/v1/banks/6300/codes/ClientGroups/3"
          },
          "clientSegment": {
            "href": "/v1/banks/6300/codes/ClientSegments/11"
          }
        }
      },
      "person": {
        "firstName": "Firstname",
        "officialFirstName": null,
        "lastName": "Lastname",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 2,
        "dateOfBirth": "1981-01-01",
        "dateOfDeath": null,
        "formOfAddress": "2",
        "title": "",
        "maritalStatus": "1",
        "matrimonialPropertyRegime": "0",
        "countryOfBirth": "CH",
        "nationality": "IT",
        "nationality2": "",
        "profession": "67",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/2"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/1"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/0"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/IT"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/67"
          }
        }
      }
    }
  }
]
