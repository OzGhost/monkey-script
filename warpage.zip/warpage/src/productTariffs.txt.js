var src = src || {}
  src.productTariffs = [
    {
      "code": "2000",
      "language": "de",
      "shortcut": "D uku",
      "description": "Darlehen variabel unkurant",
      "sortNr": 1930
    },
    {
      "code": "2000",
      "language": "fr",
      "shortcut": "D uku",
      "description": "PrÃªt variable non courant",
      "sortNr": 1930
    },
    {
      "code": "2000",
      "language": "en",
      "shortcut": "D uku",
      "description": "Darlehen variabel unkurant",
      "sortNr": 1930
    },
    {
      "code": "2001",
      "language": "de",
      "shortcut": "KKOer",
      "description": "Kontokorrent Kredit CHF OERK",
      "sortNr": 1070
    },
    {
      "code": "2001",
      "language": "fr",
      "shortcut": "KKOer",
      "description": "Compte courant CrÃ©dit CHF CDDP",
      "sortNr": 1070
    },
    {
      "code": "2001",
      "language": "en",
      "shortcut": "KKOer",
      "description": "Kontokorrent Kredit CHF OERK",
      "sortNr": 1070
    },
    {
      "code": "2002",
      "language": "de",
      "shortcut": "KKUSb",
      "description": "Kontokorrent Kredit USD blanko",
      "sortNr": 1250
    },
    {
      "code": "2002",
      "language": "fr",
      "shortcut": "KKUSb",
      "description": "Compte courant crÃ©dit USD en blanc",
      "sortNr": 1250
    },
    {
      "code": "2002",
      "language": "en",
      "shortcut": "KKUSb",
      "description": "Kontokorrent Kredit USD blanko",
      "sortNr": 1250
    },
    {
      "code": "2003",
      "language": "de",
      "shortcut": "KKÃ¼ b",
      "description": "Kontokorrent Kredit Ã¼brige FW blanko",
      "sortNr": 1350
    },
    {
      "code": "2003",
      "language": "fr",
      "shortcut": "KKÃ¼ b",
      "description": "Compte courant CrÃ©dit Autres ME en blanc",
      "sortNr": 1350
    },
    {
      "code": "2003",
      "language": "en",
      "shortcut": "KKÃ¼ b",
      "description": "Kontokorrent Kredit Ã¼brige FW blanko",
      "sortNr": 1350
    },
    {
      "code": "2004",
      "language": "de",
      "shortcut": "Akkr",
      "description": "Akkreditivlimite",
      "sortNr": 1750
    },
    {
      "code": "2004",
      "language": "fr",
      "shortcut": "Akkr",
      "description": "Limite accrÃ©ditif",
      "sortNr": 1750
    },
    {
      "code": "2004",
      "language": "en",
      "shortcut": "Akkr",
      "description": "Akkreditivlimite",
      "sortNr": 1750
    },
    {
      "code": "2005",
      "language": "de",
      "shortcut": "TK k",
      "description": "Terminkredit kurant",
      "sortNr": 1410
    },
    {
      "code": "2005",
      "language": "fr",
      "shortcut": "TK k",
      "description": "CrÃ©dit Ã  terme courant",
      "sortNr": 1410
    },
    {
      "code": "2005",
      "language": "en",
      "shortcut": "TK k",
      "description": "Terminkredit kurant",
      "sortNr": 1410
    },
    {
      "code": "2006",
      "language": "de",
      "shortcut": "FDk4J",
      "description": "Festdarlehen kurant 4 Jahre",
      "sortNr": 2040
    },
    {
      "code": "2006",
      "language": "fr",
      "shortcut": "FDk4J",
      "description": "PrÃªt fixe courant 4 ans",
      "sortNr": 2040
    },
    {
      "code": "2006",
      "language": "en",
      "shortcut": "FDk4J",
      "description": "Festdarlehen kurant 4 Jahre",
      "sortNr": 2040
    },
    {
      "code": "2007",
      "language": "de",
      "shortcut": "Kau",
      "description": "Kautionen",
      "sortNr": 1700
    },
    {
      "code": "2007",
      "language": "fr",
      "shortcut": "Kau",
      "description": "Cautions",
      "sortNr": 1700
    },
    {
      "code": "2007",
      "language": "en",
      "shortcut": "Kau",
      "description": "Kautionen",
      "sortNr": 1700
    },
    {
      "code": "2008",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2008",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2008",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2009",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2009",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2009",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2010",
      "language": "de",
      "shortcut": "FDb3J",
      "description": "Festdarlehen blanko 3 Jahre",
      "sortNr": 2430
    },
    {
      "code": "2010",
      "language": "fr",
      "shortcut": "FDb3J",
      "description": "PrÃªt fixe en blanc 3 ans",
      "sortNr": 2430
    },
    {
      "code": "2010",
      "language": "en",
      "shortcut": "FDb3J",
      "description": "Festdarlehen blanko 3 Jahre",
      "sortNr": 2430
    },
    {
      "code": "2011",
      "language": "de",
      "shortcut": "FDb5J",
      "description": "Festdarlehen blanko 5 Jahre",
      "sortNr": 2450
    },
    {
      "code": "2011",
      "language": "fr",
      "shortcut": "FDb5J",
      "description": "PrÃªt fixe en blanc 5 ans",
      "sortNr": 2450
    },
    {
      "code": "2011",
      "language": "en",
      "shortcut": "FDb5J",
      "description": "Festdarlehen blanko 5 Jahre",
      "sortNr": 2450
    },
    {
      "code": "2012",
      "language": "de",
      "shortcut": "FDb10",
      "description": "Festdarlehen blanko 10 Jahre",
      "sortNr": 2500
    },
    {
      "code": "2012",
      "language": "fr",
      "shortcut": "FDb10",
      "description": "PrÃªt fixe en blanc 10 ans",
      "sortNr": 2500
    },
    {
      "code": "2012",
      "language": "en",
      "shortcut": "FDb10",
      "description": "Festdarlehen blanko 10 Jahre",
      "sortNr": 2500
    },
    {
      "code": "2013",
      "language": "de",
      "shortcut": "FDo9J",
      "description": "Festdarlehen OERK 9 Jahre",
      "sortNr": 2690
    },
    {
      "code": "2013",
      "language": "fr",
      "shortcut": "FDo9J",
      "description": "PrÃªt fixe CDDP 9 ans",
      "sortNr": 2690
    },
    {
      "code": "2013",
      "language": "en",
      "shortcut": "FDo9J",
      "description": "Festdarlehen OERK 9 Jahre",
      "sortNr": 2690
    },
    {
      "code": "2014",
      "language": "de",
      "shortcut": "KPRes",
      "description": "Kaufpreisrestanz",
      "sortNr": 2800
    },
    {
      "code": "2014",
      "language": "fr",
      "shortcut": "KPRes",
      "description": "Prix d'achat rÃ©siduel",
      "sortNr": 2800
    },
    {
      "code": "2014",
      "language": "en",
      "shortcut": "KPRes",
      "description": "Kaufpreisrestanz",
      "sortNr": 2800
    },
    {
      "code": "2015",
      "language": "de",
      "shortcut": "TK",
      "description": "Terminkredit",
      "sortNr": 8020
    },
    {
      "code": "2015",
      "language": "fr",
      "shortcut": "TK",
      "description": "CrÃ©dit Ã  terme",
      "sortNr": 8020
    },
    {
      "code": "2015",
      "language": "en",
      "shortcut": "TK",
      "description": "Terminkredit",
      "sortNr": 8020
    },
    {
      "code": "2016",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2016",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "2016",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2017",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2017",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2017",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2018",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2018",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2018",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2019",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2019",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2019",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2020",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2020",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2020",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2021",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2021",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2021",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2022",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2022",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2022",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2023",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2023",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "2023",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2024",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2024",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2024",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2025",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2025",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2025",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2026",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2026",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2026",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2027",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2027",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2027",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2028",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2028",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "2028",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2029",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2029",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "2029",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2030",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2030",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "2030",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2031",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2031",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "2031",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2032",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2032",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "2032",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2033",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2033",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2033",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2034",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2034",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2034",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2035",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2035",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2035",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2036",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2036",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2036",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2037",
      "language": "de",
      "shortcut": "1FW5J",
      "description": "1. Festhypothek WEG 5 Jahre",
      "sortNr": 4850
    },
    {
      "code": "2037",
      "language": "fr",
      "shortcut": "1FW5J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 5 ans",
      "sortNr": 4850
    },
    {
      "code": "2037",
      "language": "en",
      "shortcut": "1FW5J",
      "description": "1. Festhypothek WEG 5 Jahre",
      "sortNr": 4850
    },
    {
      "code": "2038",
      "language": "de",
      "shortcut": "1FW10",
      "description": "1. Festhypothek WEG 10 Jahre",
      "sortNr": 4900
    },
    {
      "code": "2038",
      "language": "fr",
      "shortcut": "1FW10",
      "description": "HypothÃ¨que fixe 1er rang LCAP 10 ans",
      "sortNr": 4900
    },
    {
      "code": "2038",
      "language": "en",
      "shortcut": "1FW10",
      "description": "1. Festhypothek WEG 10 Jahre",
      "sortNr": 4900
    },
    {
      "code": "2039",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2039",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2039",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2040",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2040",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2040",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2041",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2041",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2041",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2042",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2042",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2042",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2043",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2043",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2043",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2044",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2044",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2044",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2045",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2045",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "2045",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2046",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2046",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "2046",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2047",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2047",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2047",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2048",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2048",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2048",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2049",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2049",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2049",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2050",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2050",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2050",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2051",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2051",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "2051",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2052",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2052",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "2052",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2053",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2053",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2053",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2054",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2054",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "2054",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2055",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2055",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "2055",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2056",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2056",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2056",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2057",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2057",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2057",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2058",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2058",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2058",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2059",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2059",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "2059",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2060",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2060",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2060",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2061",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2061",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2061",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2062",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2062",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2062",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2063",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2063",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2063",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2064",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2064",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2064",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2065",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2065",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "2065",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2066",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2066",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2066",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2067",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2067",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2067",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2068",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2068",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2068",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2069",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2069",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "2069",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2070",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2070",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "2070",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2071",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2071",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "2071",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2072",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2072",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "2072",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2073",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2073",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "2073",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2074",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2074",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "2074",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2075",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2075",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2075",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2076",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2076",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2076",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2077",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2077",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2077",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2078",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2078",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "2078",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2079",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2079",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "2079",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2080",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2080",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "2080",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2081",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2081",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "2081",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2082",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2082",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "2082",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2083",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2083",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "2083",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2084",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2084",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "2084",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2085",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2085",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "2085",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2086",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2086",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2086",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2087",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2087",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "2087",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2088",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2088",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "2088",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2089",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2089",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "2089",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2090",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2090",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2090",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2091",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2091",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2091",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2092",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2092",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "2092",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2093",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2093",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "2093",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2094",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2094",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "2094",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2095",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2095",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "2095",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2096",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2096",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "2096",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2097",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2097",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2097",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2098",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2098",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2098",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2099",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2099",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2099",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2100",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2100",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "2100",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2101",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2101",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "2101",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2102",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2102",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "2102",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2103",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2103",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2103",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2104",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2104",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2104",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2105",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2105",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2105",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2106",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2106",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "2106",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2107",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2107",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "2107",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2108",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2108",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "2108",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2109",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2109",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "2109",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2110",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2110",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "2110",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2111",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2111",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "2111",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2112",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2112",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "2112",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2113",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2113",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "2113",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2114",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2114",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "2114",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2115",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2115",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "2115",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2116",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2116",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2116",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2117",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2117",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2117",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2118",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2118",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2118",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2119",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2119",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2119",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2120",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2120",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2120",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2121",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2121",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "2121",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2122",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2122",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "2122",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2123",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2123",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "2123",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2124",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2124",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "2124",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2125",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2125",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "2125",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2126",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2126",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "2126",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2127",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2127",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "2127",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2128",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2128",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "2128",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2129",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2129",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2129",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2130",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2130",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2130",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2131",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2131",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2131",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2132",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2132",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "2132",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2133",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2133",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "2133",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2134",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2134",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "2134",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2135",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2135",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "2135",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2136",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2136",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "2136",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2137",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2137",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "2137",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2138",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2138",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "2138",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2139",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2139",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "2139",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2140",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2140",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "2140",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2141",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2141",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "2141",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2142",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2142",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2142",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2143",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2143",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2143",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2144",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2144",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "2144",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2145",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2145",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2145",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2146",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2146",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "2146",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2147",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2147",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2147",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2148",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2148",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "2148",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2149",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2149",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "2149",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2150",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2150",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "2150",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2151",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2151",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "2151",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2152",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2152",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2152",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2153",
      "language": "de",
      "shortcut": "TK uk",
      "description": "Terminkredit unkurant",
      "sortNr": 1430
    },
    {
      "code": "2153",
      "language": "fr",
      "shortcut": "TK uk",
      "description": "CrÃ©dit Ã  terme non courant",
      "sortNr": 1430
    },
    {
      "code": "2153",
      "language": "en",
      "shortcut": "TK uk",
      "description": "Terminkredit unkurant",
      "sortNr": 1430
    },
    {
      "code": "2154",
      "language": "de",
      "shortcut": "KKEUu",
      "description": "Kontokorrent Kredit EUR unkurant",
      "sortNr": 1130
    },
    {
      "code": "2154",
      "language": "fr",
      "shortcut": "KKEUu",
      "description": "Compte courant CrÃ©dit EUR non courant",
      "sortNr": 1130
    },
    {
      "code": "2154",
      "language": "en",
      "shortcut": "KKEUu",
      "description": "Kontokorrent Kredit EUR unkurant",
      "sortNr": 1130
    },
    {
      "code": "2155",
      "language": "de",
      "shortcut": "KKUSk",
      "description": "Kontokorrent Kredit USD kurant",
      "sortNr": 1210
    },
    {
      "code": "2155",
      "language": "fr",
      "shortcut": "KKUSk",
      "description": "Compte courant CrÃ©dit USD courant",
      "sortNr": 1210
    },
    {
      "code": "2155",
      "language": "en",
      "shortcut": "KKUSk",
      "description": "Kontokorrent Kredit USD kurant",
      "sortNr": 1210
    },
    {
      "code": "2156",
      "language": "de",
      "shortcut": "KKCHk",
      "description": "Kontokorrent Kredit CHF kurant",
      "sortNr": 1010
    },
    {
      "code": "2156",
      "language": "fr",
      "shortcut": "KKCHk",
      "description": "Compte courant CrÃ©dit CHF courant",
      "sortNr": 1010
    },
    {
      "code": "2156",
      "language": "en",
      "shortcut": "KKCHk",
      "description": "Kontokorrent Kredit CHF kurant",
      "sortNr": 1010
    },
    {
      "code": "2157",
      "language": "de",
      "shortcut": "PK uk",
      "description": "Personalkredit unkurant",
      "sortNr": 1630
    },
    {
      "code": "2157",
      "language": "fr",
      "shortcut": "PK uk",
      "description": "CrÃ©dit personnel, non courant",
      "sortNr": 1630
    },
    {
      "code": "2157",
      "language": "en",
      "shortcut": "PK uk",
      "description": "Personalkredit unkurant",
      "sortNr": 1630
    },
    {
      "code": "2158",
      "language": "de",
      "shortcut": "FDk5J",
      "description": "Festdarlehen kurant 5 Jahre",
      "sortNr": 2050
    },
    {
      "code": "2158",
      "language": "fr",
      "shortcut": "FDk5J",
      "description": "PrÃªt fixe courant 5 ans",
      "sortNr": 2050
    },
    {
      "code": "2158",
      "language": "en",
      "shortcut": "FDk5J",
      "description": "Festdarlehen kurant 5 Jahre",
      "sortNr": 2050
    },
    {
      "code": "2159",
      "language": "de",
      "shortcut": "FDk6J",
      "description": "Festdarlehen kurant 6 Jahre",
      "sortNr": 2060
    },
    {
      "code": "2159",
      "language": "fr",
      "shortcut": "FDk6J",
      "description": "PrÃªt fixe courant 6 ans",
      "sortNr": 2060
    },
    {
      "code": "2159",
      "language": "en",
      "shortcut": "FDk6J",
      "description": "Festdarlehen kurant 6 Jahre",
      "sortNr": 2060
    },
    {
      "code": "2160",
      "language": "de",
      "shortcut": "FDuk3",
      "description": "Festdarlehen unkurant 3 Jahre",
      "sortNr": 2230
    },
    {
      "code": "2160",
      "language": "fr",
      "shortcut": "FDuk3",
      "description": "PrÃªt fixe non courant 3 ans",
      "sortNr": 2230
    },
    {
      "code": "2160",
      "language": "en",
      "shortcut": "FDuk3",
      "description": "Festdarlehen unkurant 3 Jahre",
      "sortNr": 2230
    },
    {
      "code": "2161",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2161",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2161",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2162",
      "language": "de",
      "shortcut": "FDuk5",
      "description": "Festdarlehen unkurant 5 Jahre",
      "sortNr": 2250
    },
    {
      "code": "2162",
      "language": "fr",
      "shortcut": "FDuk5",
      "description": "PrÃªt fixe non courant 5 ans",
      "sortNr": 2250
    },
    {
      "code": "2162",
      "language": "en",
      "shortcut": "FDuk5",
      "description": "Festdarlehen unkurant 5 Jahre",
      "sortNr": 2250
    },
    {
      "code": "2163",
      "language": "de",
      "shortcut": "FDuk9",
      "description": "Festdarlehen unkurant 9 Jahre",
      "sortNr": 2290
    },
    {
      "code": "2163",
      "language": "fr",
      "shortcut": "FDuk9",
      "description": "PrÃªt fixe non courant 9 ans",
      "sortNr": 2290
    },
    {
      "code": "2163",
      "language": "en",
      "shortcut": "FDuk9",
      "description": "Festdarlehen unkurant 9 Jahre",
      "sortNr": 2290
    },
    {
      "code": "2164",
      "language": "de",
      "shortcut": "FDb4J",
      "description": "Festdarlehen blanko 4 Jahre",
      "sortNr": 2440
    },
    {
      "code": "2164",
      "language": "fr",
      "shortcut": "FDb4J",
      "description": "PrÃªt fixe en blanc 4 ans",
      "sortNr": 2440
    },
    {
      "code": "2164",
      "language": "en",
      "shortcut": "FDb4J",
      "description": "Festdarlehen blanko 4 Jahre",
      "sortNr": 2440
    },
    {
      "code": "2165",
      "language": "de",
      "shortcut": "FDb6J",
      "description": "Festdarlehen blanko 6 Jahre",
      "sortNr": 2460
    },
    {
      "code": "2165",
      "language": "fr",
      "shortcut": "FDb6J",
      "description": "PrÃªt fixe en blanc 6 ans",
      "sortNr": 2460
    },
    {
      "code": "2165",
      "language": "en",
      "shortcut": "FDb6J",
      "description": "Festdarlehen blanko 6 Jahre",
      "sortNr": 2460
    },
    {
      "code": "2166",
      "language": "de",
      "shortcut": "FDb8J",
      "description": "Festdarlehen blanko 8 Jahre",
      "sortNr": 2480
    },
    {
      "code": "2166",
      "language": "fr",
      "shortcut": "FDb8J",
      "description": "PrÃªt fixe en blanc 8 ans",
      "sortNr": 2480
    },
    {
      "code": "2166",
      "language": "en",
      "shortcut": "FDb8J",
      "description": "Festdarlehen blanko 8 Jahre",
      "sortNr": 2480
    },
    {
      "code": "2167",
      "language": "de",
      "shortcut": "FDo5J",
      "description": "Festdarlehen OERK 5 Jahre",
      "sortNr": 2650
    },
    {
      "code": "2167",
      "language": "fr",
      "shortcut": "FDo5J",
      "description": "PrÃªt fixe CDDP 5 ans",
      "sortNr": 2650
    },
    {
      "code": "2167",
      "language": "en",
      "shortcut": "FDo5J",
      "description": "Festdarlehen OERK 5 Jahre",
      "sortNr": 2650
    },
    {
      "code": "2168",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2820
    },
    {
      "code": "2168",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2820
    },
    {
      "code": "2168",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2820
    },
    {
      "code": "2169",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2880
    },
    {
      "code": "2169",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2880
    },
    {
      "code": "2169",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2880
    },
    {
      "code": "2170",
      "language": "de",
      "shortcut": "KKCH",
      "description": "Kontokorrent Kredit CHF",
      "sortNr": 8010
    },
    {
      "code": "2170",
      "language": "fr",
      "shortcut": "KKCH",
      "description": "Compte courant CrÃ©dit CHF",
      "sortNr": 8010
    },
    {
      "code": "2170",
      "language": "en",
      "shortcut": "KKCH",
      "description": "Kontokorrent Kredit CHF",
      "sortNr": 8010
    },
    {
      "code": "2171",
      "language": "de",
      "shortcut": "Lomb",
      "description": "Lombardkredit",
      "sortNr": 8030
    },
    {
      "code": "2171",
      "language": "fr",
      "shortcut": "Lomb",
      "description": "CrÃ©dit lombard",
      "sortNr": 8030
    },
    {
      "code": "2171",
      "language": "en",
      "shortcut": "Lomb",
      "description": "Lombardkredit",
      "sortNr": 8030
    },
    {
      "code": "2172",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 8040
    },
    {
      "code": "2172",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 8040
    },
    {
      "code": "2172",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 8040
    },
    {
      "code": "2173",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2173",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "2173",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2174",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2174",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2174",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2175",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2175",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2175",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2176",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2176",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2176",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2177",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2177",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "2177",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2178",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2178",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "2178",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2179",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2179",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2179",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2180",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2180",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2180",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2181",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2181",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2181",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2182",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2182",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2182",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2183",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2183",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2183",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2184",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2184",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "2184",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2185",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2185",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2185",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2186",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2186",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2186",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2187",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2187",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2187",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2188",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2188",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2188",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2189",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2189",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2189",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2190",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2190",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2190",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2191",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2191",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "2191",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2192",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2192",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "2192",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2193",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2193",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "2193",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2194",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2194",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "2194",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2195",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2195",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "2195",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2196",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2196",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "2196",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2197",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2197",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "2197",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2198",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2198",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2198",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2199",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2199",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2199",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2200",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2200",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2200",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2201",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2201",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2201",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2202",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2202",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2202",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2203",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2203",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2203",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2204",
      "language": "de",
      "shortcut": "1FW4J",
      "description": "1. Festhypothek WEG 4 Jahre",
      "sortNr": 4840
    },
    {
      "code": "2204",
      "language": "fr",
      "shortcut": "1FW4J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 4 ans",
      "sortNr": 4840
    },
    {
      "code": "2204",
      "language": "en",
      "shortcut": "1FW4J",
      "description": "1. Festhypothek WEG 4 Jahre",
      "sortNr": 4840
    },
    {
      "code": "2205",
      "language": "de",
      "shortcut": "1FW7J",
      "description": "1. Festhypothek WEG 7 Jahre",
      "sortNr": 4870
    },
    {
      "code": "2205",
      "language": "fr",
      "shortcut": "1FW7J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 7 ans",
      "sortNr": 4870
    },
    {
      "code": "2205",
      "language": "en",
      "shortcut": "1FW7J",
      "description": "1. Festhypothek WEG 7 Jahre",
      "sortNr": 4870
    },
    {
      "code": "2206",
      "language": "de",
      "shortcut": "2FW5J",
      "description": "2. Festhypothek WEG 5 Jahre",
      "sortNr": 4950
    },
    {
      "code": "2206",
      "language": "fr",
      "shortcut": "2FW5J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 5 ans",
      "sortNr": 4950
    },
    {
      "code": "2206",
      "language": "en",
      "shortcut": "2FW5J",
      "description": "2. Festhypothek WEG 5 Jahre",
      "sortNr": 4950
    },
    {
      "code": "2207",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2207",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2207",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2208",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2208",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2208",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2209",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2209",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2209",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2210",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2210",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2210",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2211",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2211",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2211",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2212",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2212",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2212",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2213",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2213",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2213",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2214",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2214",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2214",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2215",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2215",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2215",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2216",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2216",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2216",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2217",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2217",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2217",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2218",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2218",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2218",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2219",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2219",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2219",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2220",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2220",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "2220",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2221",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2221",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "2221",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2222",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2222",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "2222",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2223",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2223",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "2223",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2224",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2224",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "2224",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2225",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2225",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "2225",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2226",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2226",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "2226",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2227",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2227",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "2227",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2228",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2228",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2228",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2229",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2229",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2229",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2230",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2230",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2230",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2231",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2231",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "2231",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2232",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2232",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "2232",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2233",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2233",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "2233",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2234",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2234",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "2234",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2235",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2235",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "2235",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2236",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2236",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2236",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2237",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2237",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "2237",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2238",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2238",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2238",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2239",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2239",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2239",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2240",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2240",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2240",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2241",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2241",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "2241",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2242",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2242",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "2242",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2243",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2243",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "2243",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2244",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2244",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "2244",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2245",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2245",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2245",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2246",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2246",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2246",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2247",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2247",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "2247",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2248",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2248",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "2248",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2249",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2249",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "2249",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2250",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2250",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "2250",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2251",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2251",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "2251",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2252",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2252",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "2252",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2253",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2253",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "2253",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2254",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2254",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "2254",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2255",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2255",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2255",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2256",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2256",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2256",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2257",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2257",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2257",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2258",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2258",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "2258",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2259",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2259",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "2259",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2260",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2260",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "2260",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2261",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "2261",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "2261",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "2262",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2262",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2262",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2263",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2263",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2263",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2264",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2264",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2264",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2265",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2265",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2265",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2266",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2266",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2266",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2267",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2267",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2267",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2268",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2268",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "2268",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2269",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2269",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "2269",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2270",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2270",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "2270",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2271",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2271",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "2271",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2272",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2272",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "2272",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2273",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2273",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "2273",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2274",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2274",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "2274",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2275",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2275",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "2275",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2276",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2276",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "2276",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2277",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2277",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "2277",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2278",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2278",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "2278",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2279",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2279",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "2279",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2280",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2280",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2280",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2281",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2281",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2281",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2282",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2282",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2282",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2283",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2283",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "2283",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2284",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2284",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "2284",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2285",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2285",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "2285",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2286",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2286",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "2286",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2287",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2287",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "2287",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2288",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2288",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "2288",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2289",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2289",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "2289",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2290",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2290",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "2290",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2291",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2291",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "2291",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2292",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2292",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "2292",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2293",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2293",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2293",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2294",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2294",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2294",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2295",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2295",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "2295",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2296",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2296",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "2296",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2297",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2297",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "2297",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2298",
      "language": "de",
      "shortcut": "S4",
      "description": "Familienhypothek variabel",
      "sortNr": 8090
    },
    {
      "code": "2298",
      "language": "fr",
      "shortcut": "S4",
      "description": "HypothÃ¨que familiale variable",
      "sortNr": 8090
    },
    {
      "code": "2298",
      "language": "en",
      "shortcut": "S4",
      "description": "Familienhypothek variabel",
      "sortNr": 8090
    },
    {
      "code": "2299",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2299",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "2299",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2300",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2300",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "2300",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2301",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2301",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "2301",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2302",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2302",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "2302",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2303",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2303",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "2303",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2304",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2304",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "2304",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2305",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2305",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "2305",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2306",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2306",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2306",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2307",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2307",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2307",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2308",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2308",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2308",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2309",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2309",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2309",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2310",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2310",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "2310",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2311",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2311",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "2311",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2312",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2312",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "2312",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2313",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2313",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "2313",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2314",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2314",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2314",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2315",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2315",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2315",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2316",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2316",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2316",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2317",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2317",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2317",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2318",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2318",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2318",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2319",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2319",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2319",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2320",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2320",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2320",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2321",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2321",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "2321",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2322",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2322",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "2322",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2323",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2323",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "2323",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2324",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2324",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "2324",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2325",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2325",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2325",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2326",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2326",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2326",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2327",
      "language": "de",
      "shortcut": "PK k",
      "description": "Personalkredit kurant",
      "sortNr": 1610
    },
    {
      "code": "2327",
      "language": "fr",
      "shortcut": "PK k",
      "description": "CrÃ©dit personnel, courant",
      "sortNr": 1610
    },
    {
      "code": "2327",
      "language": "en",
      "shortcut": "PK k",
      "description": "Personalkredit kurant",
      "sortNr": 1610
    },
    {
      "code": "2328",
      "language": "de",
      "shortcut": "KKCHu",
      "description": "Kontokorrent Kredit CHF unkurant",
      "sortNr": 1030
    },
    {
      "code": "2328",
      "language": "fr",
      "shortcut": "KKCHu",
      "description": "Compte courant CrÃ©dit CHF non courant",
      "sortNr": 1030
    },
    {
      "code": "2328",
      "language": "en",
      "shortcut": "KKCHu",
      "description": "Kontokorrent Kredit CHF unkurant",
      "sortNr": 1030
    },
    {
      "code": "2329",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2329",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2329",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2330",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2330",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2330",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2331",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2331",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2331",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2332",
      "language": "de",
      "shortcut": "FDuk6",
      "description": "Festdarlehen unkurant 6 Jahre",
      "sortNr": 2260
    },
    {
      "code": "2332",
      "language": "fr",
      "shortcut": "FDuk6",
      "description": "PrÃªt fixe non courant 6 ans",
      "sortNr": 2260
    },
    {
      "code": "2332",
      "language": "en",
      "shortcut": "FDuk6",
      "description": "Festdarlehen unkurant 6 Jahre",
      "sortNr": 2260
    },
    {
      "code": "2333",
      "language": "de",
      "shortcut": "FDu10",
      "description": "Festdarlehen unkurant 10 Jahre",
      "sortNr": 2300
    },
    {
      "code": "2333",
      "language": "fr",
      "shortcut": "FDu10",
      "description": "PrÃªt fixe non courant 10 ans",
      "sortNr": 2300
    },
    {
      "code": "2333",
      "language": "en",
      "shortcut": "FDu10",
      "description": "Festdarlehen unkurant 10 Jahre",
      "sortNr": 2300
    },
    {
      "code": "2334",
      "language": "de",
      "shortcut": "FDb2J",
      "description": "Festdarlehen blanko 2 Jahre",
      "sortNr": 2420
    },
    {
      "code": "2334",
      "language": "fr",
      "shortcut": "FDb2J",
      "description": "PrÃªt fixe en blanc 2 ans",
      "sortNr": 2420
    },
    {
      "code": "2334",
      "language": "en",
      "shortcut": "FDb2J",
      "description": "Festdarlehen blanko 2 Jahre",
      "sortNr": 2420
    },
    {
      "code": "2335",
      "language": "de",
      "shortcut": "FDo7J",
      "description": "Festdarlehen OERK 7 Jahre",
      "sortNr": 2670
    },
    {
      "code": "2335",
      "language": "fr",
      "shortcut": "FDo7J",
      "description": "PrÃªt fixe CDDP 7 ans",
      "sortNr": 2670
    },
    {
      "code": "2335",
      "language": "en",
      "shortcut": "FDo7J",
      "description": "Festdarlehen OERK 7 Jahre",
      "sortNr": 2670
    },
    {
      "code": "2336",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2840
    },
    {
      "code": "2336",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2840
    },
    {
      "code": "2336",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2840
    },
    {
      "code": "2337",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2830
    },
    {
      "code": "2337",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2830
    },
    {
      "code": "2337",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2830
    },
    {
      "code": "2338",
      "language": "de",
      "shortcut": "FD",
      "description": "Festdarlehen",
      "sortNr": 8060
    },
    {
      "code": "2338",
      "language": "fr",
      "shortcut": "FD",
      "description": "PrÃªt fixe",
      "sortNr": 8060
    },
    {
      "code": "2338",
      "language": "en",
      "shortcut": "FD",
      "description": "Festdarlehen",
      "sortNr": 8060
    },
    {
      "code": "2339",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2339",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2339",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2340",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2340",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "2340",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2341",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2341",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "2341",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2342",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2342",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "2342",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2343",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2343",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2343",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2344",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2344",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "2344",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2345",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2345",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2345",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2346",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2346",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2346",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2347",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2347",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2347",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2348",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2348",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2348",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2349",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2349",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "2349",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2350",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2350",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "2350",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2351",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2351",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "2351",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2352",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2352",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2352",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2353",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2353",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2353",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2354",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2354",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2354",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2355",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2355",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "2355",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2356",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2356",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "2356",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2357",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2357",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2357",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2358",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2358",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2358",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2359",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2359",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2359",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2360",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2360",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2360",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2361",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2361",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2361",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2362",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2362",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2362",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2363",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2363",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2363",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2364",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2364",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2364",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2365",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2365",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2365",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2366",
      "language": "de",
      "shortcut": "1Wvar",
      "description": "1. Hypothek variabel WEG",
      "sortNr": 4710
    },
    {
      "code": "2366",
      "language": "fr",
      "shortcut": "1Wvar",
      "description": "HypothÃ¨que variable 1er rang LCAP",
      "sortNr": 4710
    },
    {
      "code": "2366",
      "language": "en",
      "shortcut": "1Wvar",
      "description": "1. Hypothek variabel WEG",
      "sortNr": 4710
    },
    {
      "code": "2367",
      "language": "de",
      "shortcut": "1FW1J",
      "description": "1. Festhypothek WEG 1 Jahr",
      "sortNr": 4810
    },
    {
      "code": "2367",
      "language": "fr",
      "shortcut": "1FW1J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 1 an",
      "sortNr": 4810
    },
    {
      "code": "2367",
      "language": "en",
      "shortcut": "1FW1J",
      "description": "1. Festhypothek WEG 1 Jahr",
      "sortNr": 4810
    },
    {
      "code": "2368",
      "language": "de",
      "shortcut": "1FW3J",
      "description": "1. Festhypothek WEG 3 Jahre",
      "sortNr": 4830
    },
    {
      "code": "2368",
      "language": "fr",
      "shortcut": "1FW3J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 3 ans",
      "sortNr": 4830
    },
    {
      "code": "2368",
      "language": "en",
      "shortcut": "1FW3J",
      "description": "1. Festhypothek WEG 3 Jahre",
      "sortNr": 4830
    },
    {
      "code": "2369",
      "language": "de",
      "shortcut": "2FW10",
      "description": "2. Festhypothek WEG 10 Jahre",
      "sortNr": 5000
    },
    {
      "code": "2369",
      "language": "fr",
      "shortcut": "2FW10",
      "description": "HypothÃ¨que fixe 2e rang LCAP 10 ans",
      "sortNr": 5000
    },
    {
      "code": "2369",
      "language": "en",
      "shortcut": "2FW10",
      "description": "2. Festhypothek WEG 10 Jahre",
      "sortNr": 5000
    },
    {
      "code": "2370",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2370",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2370",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2371",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2371",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2371",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2372",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2372",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2372",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2373",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2373",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "2373",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2374",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2374",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "2374",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2375",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2375",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "2375",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2376",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2376",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2376",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2377",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2377",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2377",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2378",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2378",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "2378",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2379",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2379",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "2379",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2380",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2380",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2380",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2381",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2381",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2381",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2382",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2382",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "2382",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2383",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2383",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2383",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2384",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2384",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "2384",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2385",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2385",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2385",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2386",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2386",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "2386",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2387",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2387",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "2387",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2388",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2388",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2388",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2389",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2389",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2389",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2390",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2390",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2390",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2391",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2391",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2391",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2392",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2392",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2392",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2393",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2393",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "2393",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2394",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2394",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "2394",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2395",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2395",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "2395",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2396",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2396",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2396",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2397",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2397",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2397",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2398",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2398",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "2398",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2399",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2399",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "2399",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2400",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2400",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "2400",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2401",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2401",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "2401",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2402",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2402",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "2402",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2403",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2403",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "2403",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2404",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2404",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "2404",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2405",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2405",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "2405",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2406",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2406",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "2406",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2407",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2407",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "2407",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2408",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2408",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2408",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2409",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2409",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2409",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2410",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2410",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2410",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2411",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2411",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2411",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2412",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2412",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "2412",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2413",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2413",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "2413",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2414",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2414",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "2414",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2415",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2415",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "2415",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2416",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2416",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "2416",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2417",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2417",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "2417",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2418",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2418",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2418",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2419",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2419",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "2419",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2420",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2420",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "2420",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2421",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2421",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "2421",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2422",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2422",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2422",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2423",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2423",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "2423",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2424",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2424",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "2424",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2425",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2425",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "2425",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2426",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2426",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2426",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2427",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "2427",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "2427",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "2428",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2428",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "2428",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2429",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2429",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "2429",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2430",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2430",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "2430",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2431",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2431",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "2431",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2432",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2432",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "2432",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2433",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2433",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2433",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2434",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2434",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2434",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2435",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2435",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2435",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2436",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2436",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "2436",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2437",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2437",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "2437",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2438",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2438",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "2438",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2439",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2439",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "2439",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2440",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2440",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2440",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2441",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2441",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "2441",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2442",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2442",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "2442",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2443",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2443",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "2443",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2444",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2444",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "2444",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2445",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2445",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "2445",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2446",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2446",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "2446",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2447",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2447",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "2447",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2448",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2448",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2448",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2449",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2449",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2449",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2450",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2450",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2450",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2451",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2451",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "2451",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2452",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2452",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "2452",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2453",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2453",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "2453",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2454",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2454",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "2454",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2455",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2455",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "2455",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2456",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2456",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "2456",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2457",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2457",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "2457",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2458",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2458",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "2458",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2459",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2459",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "2459",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2460",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2460",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "2460",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2461",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2461",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "2461",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2462",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2462",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2462",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2463",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2463",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "2463",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2464",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2464",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "2464",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2465",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2465",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "2465",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2466",
      "language": "de",
      "shortcut": "S1",
      "description": "Familienhypothek fest",
      "sortNr": 8100
    },
    {
      "code": "2466",
      "language": "fr",
      "shortcut": "S1",
      "description": "HypothÃ¨que familiale fixe",
      "sortNr": 8100
    },
    {
      "code": "2466",
      "language": "en",
      "shortcut": "S1",
      "description": "Familienhypothek fest",
      "sortNr": 8100
    },
    {
      "code": "2467",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2467",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "2467",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2468",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2468",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "2468",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2469",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2469",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "2469",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2470",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2470",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2470",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2471",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2471",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2471",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2472",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2472",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "2472",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2473",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2473",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "2473",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2474",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2474",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2474",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2475",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2475",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2475",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2476",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2476",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2476",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2477",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2477",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2477",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2478",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2478",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2478",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2479",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2479",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "2479",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2480",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2480",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "2480",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2481",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2481",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "2481",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2482",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2482",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "2482",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2483",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2483",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "2483",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "2484",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2484",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "2484",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2485",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2485",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "2485",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2486",
      "language": "de",
      "shortcut": "FDuk1",
      "description": "Festdarlehen unkurant 1 Jahr",
      "sortNr": 2210
    },
    {
      "code": "2486",
      "language": "fr",
      "shortcut": "FDuk1",
      "description": "PrÃªt fixe non courant 1 an",
      "sortNr": 2210
    },
    {
      "code": "2486",
      "language": "en",
      "shortcut": "FDuk1",
      "description": "Festdarlehen unkurant 1 Jahr",
      "sortNr": 2210
    },
    {
      "code": "2487",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2487",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2487",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2488",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2488",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2488",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2489",
      "language": "de",
      "shortcut": "KKÃ¼ u",
      "description": "Kontokorrent Kredit Ã¼brige FW unkurant",
      "sortNr": 1330
    },
    {
      "code": "2489",
      "language": "fr",
      "shortcut": "KKÃ¼ u",
      "description": "Compte courant CrÃ©dit Autres ME non courant",
      "sortNr": 1330
    },
    {
      "code": "2489",
      "language": "en",
      "shortcut": "KKÃ¼ u",
      "description": "Kontokorrent Kredit Ã¼brige FW unkurant",
      "sortNr": 1330
    },
    {
      "code": "2490",
      "language": "de",
      "shortcut": "FDk2J",
      "description": "Festdarlehen kurant 2 Jahre",
      "sortNr": 2020
    },
    {
      "code": "2490",
      "language": "fr",
      "shortcut": "FDk2J",
      "description": "PrÃªt fixe courant 2 ans",
      "sortNr": 2020
    },
    {
      "code": "2490",
      "language": "en",
      "shortcut": "FDk2J",
      "description": "Festdarlehen kurant 2 Jahre",
      "sortNr": 2020
    },
    {
      "code": "2491",
      "language": "de",
      "shortcut": "FDb9J",
      "description": "Festdarlehen blanko 9 Jahre",
      "sortNr": 2490
    },
    {
      "code": "2491",
      "language": "fr",
      "shortcut": "FDb9J",
      "description": "PrÃªt fixe en blanc 9 ans",
      "sortNr": 2490
    },
    {
      "code": "2491",
      "language": "en",
      "shortcut": "FDb9J",
      "description": "Festdarlehen blanko 9 Jahre",
      "sortNr": 2490
    },
    {
      "code": "2492",
      "language": "de",
      "shortcut": "FDo10",
      "description": "Festdarlehen OERK 10 Jahre",
      "sortNr": 2700
    },
    {
      "code": "2492",
      "language": "fr",
      "shortcut": "FDo10",
      "description": "PrÃªt fixe CDDP 10 ans",
      "sortNr": 2700
    },
    {
      "code": "2492",
      "language": "en",
      "shortcut": "FDo10",
      "description": "Festdarlehen OERK 10 Jahre",
      "sortNr": 2700
    },
    {
      "code": "2493",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2493",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2493",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2494",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2494",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "2494",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2495",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2495",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "2495",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2496",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2496",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "2496",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2497",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2497",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2497",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2498",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2498",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2498",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2499",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2499",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "2499",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2500",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2500",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2500",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2501",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2501",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2501",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2502",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2502",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2502",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2503",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2503",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2503",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2504",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2504",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2504",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2505",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2505",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2505",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2506",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2506",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2506",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2507",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2507",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "2507",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2508",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2508",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "2508",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2509",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2509",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "2509",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2510",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2510",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "2510",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2511",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2511",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "2511",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2512",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2512",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "2512",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2513",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2513",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "2513",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2514",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2514",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "2514",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2515",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2515",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2515",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2516",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2516",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2516",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2517",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2517",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2517",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2518",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2518",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2518",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2519",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2519",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2519",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2520",
      "language": "de",
      "shortcut": "2FW6J",
      "description": "2. Festhypothek WEG 6 Jahre",
      "sortNr": 4960
    },
    {
      "code": "2520",
      "language": "fr",
      "shortcut": "2FW6J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 6 ans",
      "sortNr": 4960
    },
    {
      "code": "2520",
      "language": "en",
      "shortcut": "2FW6J",
      "description": "2. Festhypothek WEG 6 Jahre",
      "sortNr": 4960
    },
    {
      "code": "2521",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2521",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2521",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2522",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2522",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2522",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2523",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2523",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2523",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2524",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2524",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2524",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2525",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2525",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "2525",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2526",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2526",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "2526",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2527",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2527",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2527",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2528",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2528",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2528",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2529",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2529",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2529",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2530",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2530",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "2530",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2531",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2531",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "2531",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2532",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2532",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "2532",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2533",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2533",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "2533",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2534",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2534",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "2534",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2535",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2535",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "2535",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2536",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2536",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "2536",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2537",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2537",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2537",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2538",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2538",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2538",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2539",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2539",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2539",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2540",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2540",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "2540",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2541",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2541",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "2541",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2542",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2542",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2542",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2543",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2543",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "2543",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2544",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2544",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "2544",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2545",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2545",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2545",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2546",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2546",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "2546",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2547",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2547",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "2547",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2548",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2548",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "2548",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2549",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2549",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "2549",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2550",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2550",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "2550",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2551",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2551",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "2551",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2552",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2552",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "2552",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2553",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2553",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2553",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2554",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2554",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2554",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2555",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2555",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2555",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2556",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2556",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2556",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2557",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2557",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "2557",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2558",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2558",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "2558",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2559",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2559",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "2559",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2560",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2560",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "2560",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2561",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2561",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "2561",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "2562",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2562",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2562",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2563",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2563",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2563",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2564",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2564",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2564",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2565",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2565",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2565",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2566",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2566",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2566",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2567",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2567",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "2567",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2568",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2568",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "2568",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2569",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2569",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "2569",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2570",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2570",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "2570",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2571",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2571",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "2571",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2572",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2572",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "2572",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2573",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2573",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "2573",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2574",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2574",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2574",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2575",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2575",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "2575",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2576",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2576",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "2576",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2577",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2577",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "2577",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2578",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2578",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2578",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2579",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2579",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "2579",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2580",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2580",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "2580",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2581",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2581",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "2581",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2582",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2582",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "2582",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2583",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2583",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "2583",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2584",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2584",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2584",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2585",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2585",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2585",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2586",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2586",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2586",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2587",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2587",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "2587",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2588",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2588",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "2588",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2589",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2589",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "2589",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2590",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2590",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "2590",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2591",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2591",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "2591",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2592",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2592",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "2592",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2593",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2593",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "2593",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2594",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2594",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "2594",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2595",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2595",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "2595",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2596",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2596",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "2596",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2597",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2597",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2597",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2598",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2598",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2598",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2599",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2599",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "2599",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2600",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2600",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "2600",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2601",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2601",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "2601",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2602",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2602",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "2602",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2603",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2603",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "2603",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2604",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2604",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "2604",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2605",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2605",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "2605",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2606",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2606",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "2606",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2607",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2607",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "2607",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2608",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2608",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "2608",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2609",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2609",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2609",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2610",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2610",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "2610",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2611",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2611",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2611",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2612",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2612",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "2612",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2613",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2613",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "2613",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2614",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2614",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "2614",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2615",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2615",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2615",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2616",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2616",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2616",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2617",
      "language": "de",
      "shortcut": "KKEUb",
      "description": "Kontokorrent Kredit EUR blanko",
      "sortNr": 1150
    },
    {
      "code": "2617",
      "language": "fr",
      "shortcut": "KKEUb",
      "description": "Compte courant CrÃ©dit EUR en blanc",
      "sortNr": 1150
    },
    {
      "code": "2617",
      "language": "en",
      "shortcut": "KKEUb",
      "description": "Kontokorrent Kredit EUR blanko",
      "sortNr": 1150
    },
    {
      "code": "2618",
      "language": "de",
      "shortcut": "FDk3J",
      "description": "Festdarlehen kurant 3 Jahre",
      "sortNr": 2030
    },
    {
      "code": "2618",
      "language": "fr",
      "shortcut": "FDk3J",
      "description": "PrÃªt fixe courant 3 ans",
      "sortNr": 2030
    },
    {
      "code": "2618",
      "language": "en",
      "shortcut": "FDk3J",
      "description": "Festdarlehen kurant 3 Jahre",
      "sortNr": 2030
    },
    {
      "code": "2619",
      "language": "de",
      "shortcut": "FDuk2",
      "description": "Festdarlehen unkurant 2 Jahre",
      "sortNr": 2220
    },
    {
      "code": "2619",
      "language": "fr",
      "shortcut": "FDuk2",
      "description": "PrÃªt fixe non courant 2 ans",
      "sortNr": 2220
    },
    {
      "code": "2619",
      "language": "en",
      "shortcut": "FDuk2",
      "description": "Festdarlehen unkurant 2 Jahre",
      "sortNr": 2220
    },
    {
      "code": "2620",
      "language": "de",
      "shortcut": "FDuk7",
      "description": "Festdarlehen unkurant 7 Jahre",
      "sortNr": 2270
    },
    {
      "code": "2620",
      "language": "fr",
      "shortcut": "FDuk7",
      "description": "PrÃªt fixe non courant 7 ans",
      "sortNr": 2270
    },
    {
      "code": "2620",
      "language": "en",
      "shortcut": "FDuk7",
      "description": "Festdarlehen unkurant 7 Jahre",
      "sortNr": 2270
    },
    {
      "code": "2621",
      "language": "de",
      "shortcut": "FDo1J",
      "description": "Festdarlehen OERK 1 Jahr",
      "sortNr": 2610
    },
    {
      "code": "2621",
      "language": "fr",
      "shortcut": "FDo1J",
      "description": "PrÃªt fixe CDDP 1 an",
      "sortNr": 2610
    },
    {
      "code": "2621",
      "language": "en",
      "shortcut": "FDo1J",
      "description": "Festdarlehen OERK 1 Jahr",
      "sortNr": 2610
    },
    {
      "code": "2622",
      "language": "de",
      "shortcut": "FDo8J",
      "description": "Festdarlehen OERK 8 Jahre",
      "sortNr": 2680
    },
    {
      "code": "2622",
      "language": "fr",
      "shortcut": "FDo8J",
      "description": "PrÃªt fixe CDDP 8 ans",
      "sortNr": 2680
    },
    {
      "code": "2622",
      "language": "en",
      "shortcut": "FDo8J",
      "description": "Festdarlehen OERK 8 Jahre",
      "sortNr": 2680
    },
    {
      "code": "2623",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2810
    },
    {
      "code": "2623",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2810
    },
    {
      "code": "2623",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2810
    },
    {
      "code": "2624",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2624",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "2624",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2625",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2625",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "2625",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2626",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2626",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "2626",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2627",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2627",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2627",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2628",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2628",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "2628",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2629",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2629",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2629",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2630",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2630",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2630",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2631",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2631",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2631",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2632",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2632",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "2632",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2633",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2633",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "2633",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2634",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2634",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "2634",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "2635",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2635",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2635",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2636",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2636",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2636",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2637",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2637",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2637",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2638",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2638",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2638",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2639",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2639",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "2639",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2640",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2640",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "2640",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2641",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2641",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "2641",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2642",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2642",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "2642",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2643",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2643",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "2643",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2644",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2644",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2644",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2645",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2645",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2645",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2646",
      "language": "de",
      "shortcut": "1FW9J",
      "description": "1. Festhypothek WEG 9 Jahre",
      "sortNr": 4890
    },
    {
      "code": "2646",
      "language": "fr",
      "shortcut": "1FW9J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 9 ans",
      "sortNr": 4890
    },
    {
      "code": "2646",
      "language": "en",
      "shortcut": "1FW9J",
      "description": "1. Festhypothek WEG 9 Jahre",
      "sortNr": 4890
    },
    {
      "code": "2647",
      "language": "de",
      "shortcut": "2FW9J",
      "description": "2. Festhypothek WEG 9 Jahre",
      "sortNr": 4990
    },
    {
      "code": "2647",
      "language": "fr",
      "shortcut": "2FW9J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 9 ans",
      "sortNr": 4990
    },
    {
      "code": "2647",
      "language": "en",
      "shortcut": "2FW9J",
      "description": "2. Festhypothek WEG 9 Jahre",
      "sortNr": 4990
    },
    {
      "code": "2648",
      "language": "de",
      "shortcut": "2FW2J",
      "description": "2. Festhypothek WEG 2 Jahre",
      "sortNr": 4920
    },
    {
      "code": "2648",
      "language": "fr",
      "shortcut": "2FW2J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 2 ans",
      "sortNr": 4920
    },
    {
      "code": "2648",
      "language": "en",
      "shortcut": "2FW2J",
      "description": "2. Festhypothek WEG 2 Jahre",
      "sortNr": 4920
    },
    {
      "code": "2649",
      "language": "de",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2649",
      "language": "fr",
      "shortcut": "S11 5",
      "description": "HypothÃ¨que familiale fixe 1er rang 5 ans",
      "sortNr": 3850
    },
    {
      "code": "2649",
      "language": "en",
      "shortcut": "S11 5",
      "description": "1. Familienhypothek fest 5 Jahre",
      "sortNr": 3850
    },
    {
      "code": "2650",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2650",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2650",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2651",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2651",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2651",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2652",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2652",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2652",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2653",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2653",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2653",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2654",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2654",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2654",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2655",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2655",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "2655",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2656",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2656",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "2656",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2657",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2657",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2657",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2658",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2658",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "2658",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2659",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2659",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "2659",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2660",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2660",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2660",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2661",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2661",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "2661",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2662",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2662",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2662",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2663",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2663",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2663",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2664",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2664",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "2664",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2665",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2665",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "2665",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2666",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2666",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2666",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2667",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2667",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2667",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2668",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2668",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "2668",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2669",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2669",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "2669",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2670",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2670",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "2670",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2671",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2671",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2671",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2672",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2672",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "2672",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2673",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2673",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "2673",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2674",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2674",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "2674",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2675",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2675",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2675",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2676",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2676",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2676",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2677",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2677",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "2677",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2678",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2678",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "2678",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "2679",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2679",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "2679",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "2680",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2680",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "2680",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2681",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2681",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "2681",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2682",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2682",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "2682",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2683",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2683",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "2683",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2684",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2684",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "2684",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2685",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2685",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "2685",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "2686",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2686",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "2686",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2687",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2687",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "2687",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2688",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2688",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2688",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2689",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2689",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2689",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2690",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2690",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "2690",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2691",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2691",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "2691",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "2692",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2692",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "2692",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2693",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2693",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "2693",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2694",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2694",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "2694",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2695",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2695",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "2695",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2696",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2696",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "2696",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2697",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2697",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2697",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2698",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2698",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "2698",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2699",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2699",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "2699",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "2700",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2700",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2700",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2701",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2701",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "2701",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "2702",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2702",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "2702",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2703",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2703",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "2703",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2704",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2704",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "2704",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2705",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2705",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "2705",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "2706",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2706",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2706",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2707",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2707",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2707",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2708",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2708",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2708",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2709",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2709",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "2709",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "2710",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2710",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "2710",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2711",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2711",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "2711",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2712",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2712",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "2712",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "2713",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2713",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "2713",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2714",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2714",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "2714",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2715",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2715",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2715",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2716",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2716",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "2716",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "2717",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2717",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "2717",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2718",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2718",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "2718",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2719",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2719",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "2719",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2720",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2720",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "2720",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2721",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2721",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "2721",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2722",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2722",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "2722",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2723",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2723",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "2723",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2724",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2724",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "2724",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2725",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2725",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "2725",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "2726",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2726",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2726",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2727",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2727",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2727",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2728",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2728",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2728",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2729",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2729",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2729",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2730",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2730",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2730",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2731",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2731",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2731",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2732",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2732",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "2732",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2733",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2733",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "2733",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2734",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2734",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "2734",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2735",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2735",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "2735",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2736",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2736",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "2736",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2737",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2737",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "2737",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2738",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2738",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "2738",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2739",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2739",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "2739",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "2740",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2740",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "2740",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2741",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2741",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "2741",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2742",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2742",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2742",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2743",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2743",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "2743",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2744",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2744",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "2744",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2745",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2745",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "2745",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2746",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2746",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "2746",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "2747",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2747",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "2747",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2748",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2748",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "2748",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2749",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2749",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "2749",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "2750",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2750",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "2750",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2751",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2751",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "2751",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2752",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2752",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "2752",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "2753",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2753",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "2753",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2754",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2754",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "2754",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2755",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2755",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "2755",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2756",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2756",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "2756",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2757",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2757",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "2757",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "2758",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2758",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2758",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2759",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2759",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2759",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2760",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2760",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2760",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2761",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2761",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2761",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2762",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2762",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2762",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2763",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2763",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "2763",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2764",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2764",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "2764",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2765",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2765",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2765",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2766",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2766",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "2766",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2767",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2767",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "2767",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2768",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2768",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2768",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2769",
      "language": "de",
      "shortcut": "D bl",
      "description": "Darlehen variabel blanko",
      "sortNr": 1950
    },
    {
      "code": "2769",
      "language": "fr",
      "shortcut": "D bl",
      "description": "PrÃªt variable en blanc",
      "sortNr": 1950
    },
    {
      "code": "2769",
      "language": "en",
      "shortcut": "D bl",
      "description": "Darlehen variabel blanko",
      "sortNr": 1950
    },
    {
      "code": "2770",
      "language": "de",
      "shortcut": "FDb1J",
      "description": "Festdarlehen blanko 1 Jahr",
      "sortNr": 2410
    },
    {
      "code": "2770",
      "language": "fr",
      "shortcut": "FDb1J",
      "description": "PrÃªt fixe en blanc 1 an",
      "sortNr": 2410
    },
    {
      "code": "2770",
      "language": "en",
      "shortcut": "FDb1J",
      "description": "Festdarlehen blanko 1 Jahr",
      "sortNr": 2410
    },
    {
      "code": "2771",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2771",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2771",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2772",
      "language": "de",
      "shortcut": "KKUSu",
      "description": "Kontokorrent Kredit USD unkurant",
      "sortNr": 1230
    },
    {
      "code": "2772",
      "language": "fr",
      "shortcut": "KKUSu",
      "description": "Compte courant CrÃ©dit USD non courant",
      "sortNr": 1230
    },
    {
      "code": "2772",
      "language": "en",
      "shortcut": "KKUSu",
      "description": "Kontokorrent Kredit USD unkurant",
      "sortNr": 1230
    },
    {
      "code": "2773",
      "language": "de",
      "shortcut": "KKCHb",
      "description": "Kontokorrent Kredit CHF blanko",
      "sortNr": 1050
    },
    {
      "code": "2773",
      "language": "fr",
      "shortcut": "KKCHb",
      "description": "Compte courant crÃ©dit CHF en blanc",
      "sortNr": 1050
    },
    {
      "code": "2773",
      "language": "en",
      "shortcut": "KKCHb",
      "description": "Kontokorrent Kredit CHF blanko",
      "sortNr": 1050
    },
    {
      "code": "2774",
      "language": "de",
      "shortcut": "FDk8J",
      "description": "Festdarlehen kurant 8 Jahre",
      "sortNr": 2080
    },
    {
      "code": "2774",
      "language": "fr",
      "shortcut": "FDk8J",
      "description": "PrÃªt fixe courant 8 ans",
      "sortNr": 2080
    },
    {
      "code": "2774",
      "language": "en",
      "shortcut": "FDk8J",
      "description": "Festdarlehen kurant 8 Jahre",
      "sortNr": 2080
    },
    {
      "code": "2775",
      "language": "de",
      "shortcut": "FDo3J",
      "description": "Festdarlehen OERK 3 Jahre",
      "sortNr": 2630
    },
    {
      "code": "2775",
      "language": "fr",
      "shortcut": "FDo3J",
      "description": "PrÃªt fixe CDDP 3 ans",
      "sortNr": 2630
    },
    {
      "code": "2775",
      "language": "en",
      "shortcut": "FDo3J",
      "description": "Festdarlehen OERK 3 Jahre",
      "sortNr": 2630
    },
    {
      "code": "2776",
      "language": "de",
      "shortcut": "FDo4J",
      "description": "Festdarlehen OERK 4 Jahre",
      "sortNr": 2640
    },
    {
      "code": "2776",
      "language": "fr",
      "shortcut": "FDo4J",
      "description": "PrÃªt fixe CDDP 4 ans",
      "sortNr": 2640
    },
    {
      "code": "2776",
      "language": "en",
      "shortcut": "FDo4J",
      "description": "Festdarlehen OERK 4 Jahre",
      "sortNr": 2640
    },
    {
      "code": "2777",
      "language": "de",
      "shortcut": "FDo6J",
      "description": "Festdarlehen OERK 6 Jahre",
      "sortNr": 2660
    },
    {
      "code": "2777",
      "language": "fr",
      "shortcut": "FDo6J",
      "description": "PrÃªt fixe CDDP 6 ans",
      "sortNr": 2660
    },
    {
      "code": "2777",
      "language": "en",
      "shortcut": "FDo6J",
      "description": "Festdarlehen OERK 6 Jahre",
      "sortNr": 2660
    },
    {
      "code": "2778",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2850
    },
    {
      "code": "2778",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2850
    },
    {
      "code": "2778",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2850
    },
    {
      "code": "2779",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2890
    },
    {
      "code": "2779",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2890
    },
    {
      "code": "2779",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2890
    },
    {
      "code": "2780",
      "language": "de",
      "shortcut": "Hvar",
      "description": "Hypothek variabel",
      "sortNr": 8070
    },
    {
      "code": "2780",
      "language": "fr",
      "shortcut": "Hvar",
      "description": "HypothÃ¨que variable",
      "sortNr": 8070
    },
    {
      "code": "2780",
      "language": "en",
      "shortcut": "Hvar",
      "description": "Hypothek variabel",
      "sortNr": 8070
    },
    {
      "code": "2781",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2781",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "2781",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2782",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2782",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "2782",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2783",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2783",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2783",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2784",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2784",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2784",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2785",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2785",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2785",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2786",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2786",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2786",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2787",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2787",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2787",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2788",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2788",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2788",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2789",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2789",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2789",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2790",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2790",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2790",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2791",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2791",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2791",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2792",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2792",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2792",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2793",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2793",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2793",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2794",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2794",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "2794",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2795",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2795",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "2795",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2796",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2796",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "2796",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2797",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2797",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "2797",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2798",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2798",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "2798",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2799",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2799",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "2799",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2800",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2800",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "2800",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2801",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2801",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "2801",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2802",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2802",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "2802",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "2803",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2803",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2803",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2804",
      "language": "de",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2804",
      "language": "fr",
      "shortcut": "1FH9J",
      "description": "HypothÃ¨que fixe 1er rang 9 ans",
      "sortNr": 3190
    },
    {
      "code": "2804",
      "language": "en",
      "shortcut": "1FH9J",
      "description": "1. Festhypothek 9 Jahre",
      "sortNr": 3190
    },
    {
      "code": "2805",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2805",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2805",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2806",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2806",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2806",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2807",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2807",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2807",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2808",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2808",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang 10 ans",
      "sortNr": 3200
    },
    {
      "code": "2808",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek 10 Jahre",
      "sortNr": 3200
    },
    {
      "code": "2809",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2809",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2809",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2810",
      "language": "de",
      "shortcut": "2Wvar",
      "description": "2. Hypothek variabel WEG",
      "sortNr": 4730
    },
    {
      "code": "2810",
      "language": "fr",
      "shortcut": "2Wvar",
      "description": "HypothÃ¨que variable 2e rang LCAP",
      "sortNr": 4730
    },
    {
      "code": "2810",
      "language": "en",
      "shortcut": "2Wvar",
      "description": "2. Hypothek variabel WEG",
      "sortNr": 4730
    },
    {
      "code": "2811",
      "language": "de",
      "shortcut": "2FW1J",
      "description": "2. Festhypothek WEG 1 Jahr",
      "sortNr": 4910
    },
    {
      "code": "2811",
      "language": "fr",
      "shortcut": "2FW1J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 1 an",
      "sortNr": 4910
    },
    {
      "code": "2811",
      "language": "en",
      "shortcut": "2FW1J",
      "description": "2. Festhypothek WEG 1 Jahr",
      "sortNr": 4910
    },
    {
      "code": "2812",
      "language": "de",
      "shortcut": "1FW6J",
      "description": "1. Festhypothek WEG 6 Jahre",
      "sortNr": 4860
    },
    {
      "code": "2812",
      "language": "fr",
      "shortcut": "1FW6J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 6 ans",
      "sortNr": 4860
    },
    {
      "code": "2812",
      "language": "en",
      "shortcut": "1FW6J",
      "description": "1. Festhypothek WEG 6 Jahre",
      "sortNr": 4860
    },
    {
      "code": "2813",
      "language": "de",
      "shortcut": "2FW7J",
      "description": "2. Festhypothek WEG 7 Jahre",
      "sortNr": 4970
    },
    {
      "code": "2813",
      "language": "fr",
      "shortcut": "2FW7J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 7 ans",
      "sortNr": 4970
    },
    {
      "code": "2813",
      "language": "en",
      "shortcut": "2FW7J",
      "description": "2. Festhypothek WEG 7 Jahre",
      "sortNr": 4970
    },
    {
      "code": "2814",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2814",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2814",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2815",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2815",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "2815",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2816",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2816",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "2816",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2817",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2817",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "2817",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2818",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2818",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2818",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2819",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2819",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2819",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2820",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2820",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2820",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2821",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2821",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "2821",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "2822",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2822",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2822",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2823",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2823",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2823",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2824",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2824",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "2824",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2825",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2825",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "2825",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "2826",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2826",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "2826",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "2827",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2827",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2827",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2828",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2828",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2828",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2829",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2829",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "2829",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2830",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2830",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2830",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2831",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2831",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2831",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2832",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2832",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "2832",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "2833",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2833",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2833",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2834",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2834",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2834",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2835",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2835",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2835",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2836",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2836",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "2836",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2837",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2837",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2837",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2838",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2838",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "2838",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "2839",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2839",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "2839",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2840",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2840",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "2840",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2841",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2841",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "2841",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2842",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2842",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "2842",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2843",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2843",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2843",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2844",
      "language": "de",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2844",
      "language": "fr",
      "shortcut": "2FC52",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3550
    },
    {
      "code": "2844",
      "language": "en",
      "shortcut": "2FC52",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3550
    },
    {
      "code": "2845",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2845",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "2845",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2846",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2846",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "2846",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2847",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2847",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "2847",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2848",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2848",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2848",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2849",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2849",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "2849",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "2850",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2850",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "2850",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "2851",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2851",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "2851",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "2852",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2852",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "2852",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2853",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2853",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "2853",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "2854",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2854",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "2854",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2855",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2855",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "2855",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "2856",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2856",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "2856",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "2857",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2857",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2857",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2858",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2858",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "2858",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "2859",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2859",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "2859",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "2860",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2860",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "2860",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2861",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2861",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "2861",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2862",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2862",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "2862",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "2863",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2863",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "2863",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2864",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2864",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "2864",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "2865",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2865",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "2865",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "2866",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2866",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "2866",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "2867",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2867",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "2867",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2868",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2868",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "2868",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "2869",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2869",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2869",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2870",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2870",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2870",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2871",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2871",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "2871",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "2872",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2872",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "2872",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "2873",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2873",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "2873",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2874",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2874",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "2874",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "2875",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2875",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "2875",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "2876",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2876",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "2876",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "2877",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2877",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "2877",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "2878",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2878",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "2878",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2879",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2879",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "2879",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2880",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2880",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "2880",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "2881",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2881",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2881",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2882",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2882",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2882",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2883",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2883",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "2883",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "2884",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2884",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "2884",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "2885",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2885",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "2885",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "2886",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2886",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "2886",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2887",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2887",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "2887",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "2888",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2888",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "2888",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "2889",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2889",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "2889",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "2890",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2890",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2890",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2891",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2891",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "2891",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "2892",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2892",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2892",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2893",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2893",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2893",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2894",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2894",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2894",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2895",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2895",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "2895",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "2896",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2896",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "2896",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "2897",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2897",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "2897",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2898",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2898",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "2898",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "2899",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2899",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "2899",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "2900",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2900",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "2900",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "2901",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2901",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "2901",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "2902",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2902",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "2902",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2903",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2903",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "2903",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2904",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2904",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "2904",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "2905",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2905",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "2905",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "2906",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2906",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "2906",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "2907",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2907",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "2907",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "2908",
      "language": "de",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2908",
      "language": "fr",
      "shortcut": "2F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3551
    },
    {
      "code": "2908",
      "language": "en",
      "shortcut": "2F3 1",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3551
    },
    {
      "code": "2909",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2909",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "2909",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2910",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2910",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "2910",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "2911",
      "language": "de",
      "shortcut": "S2",
      "description": "HypoTenplus",
      "sortNr": 8110
    },
    {
      "code": "2911",
      "language": "fr",
      "shortcut": "S2",
      "description": "HypoTenplus",
      "sortNr": 8110
    },
    {
      "code": "2911",
      "language": "en",
      "shortcut": "S2",
      "description": "HypoTenplus",
      "sortNr": 8110
    },
    {
      "code": "2912",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2912",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "2912",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "2913",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2913",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "2913",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2914",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2914",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "2914",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "2915",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2915",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "2915",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "2916",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2916",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "2916",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "2917",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2917",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2917",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2918",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2918",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2918",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2919",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2919",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "2919",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "2920",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2920",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "2920",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "2921",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2921",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "2921",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2922",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2922",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "2922",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "2923",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2923",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "2923",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "2924",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2924",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "2924",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "2925",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2925",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "2925",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "2926",
      "language": "de",
      "shortcut": "KpGar",
      "description": "Kaufpreisgarantie",
      "sortNr": 3000
    },
    {
      "code": "2926",
      "language": "fr",
      "shortcut": "KpGar",
      "description": "Garantie du prix d'achat",
      "sortNr": 3000
    },
    {
      "code": "2926",
      "language": "en",
      "shortcut": "KpGar",
      "description": "Kaufpreisgarantie",
      "sortNr": 3000
    },
    {
      "code": "2927",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2927",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "2927",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "2928",
      "language": "de",
      "shortcut": "D ku",
      "description": "Darlehen variabel kurant",
      "sortNr": 1910
    },
    {
      "code": "2928",
      "language": "fr",
      "shortcut": "D ku",
      "description": "PrÃªt variable courant",
      "sortNr": 1910
    },
    {
      "code": "2928",
      "language": "en",
      "shortcut": "D ku",
      "description": "Darlehen variabel kurant",
      "sortNr": 1910
    },
    {
      "code": "2929",
      "language": "de",
      "shortcut": "FDk1J",
      "description": "Festdarlehen kurant 1 Jahr",
      "sortNr": 2010
    },
    {
      "code": "2929",
      "language": "fr",
      "shortcut": "FDk1J",
      "description": "PrÃªt fixe courant 1 an",
      "sortNr": 2010
    },
    {
      "code": "2929",
      "language": "en",
      "shortcut": "FDk1J",
      "description": "Festdarlehen kurant 1 Jahr",
      "sortNr": 2010
    },
    {
      "code": "2930",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2930",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "2930",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "2931",
      "language": "de",
      "shortcut": "KKEUk",
      "description": "Kontokorrent Kredit EUR kurant",
      "sortNr": 1110
    },
    {
      "code": "2931",
      "language": "fr",
      "shortcut": "KKEUk",
      "description": "Compte courant CrÃ©dit EUR courant",
      "sortNr": 1110
    },
    {
      "code": "2931",
      "language": "en",
      "shortcut": "KKEUk",
      "description": "Kontokorrent Kredit EUR kurant",
      "sortNr": 1110
    },
    {
      "code": "2932",
      "language": "de",
      "shortcut": "TK b",
      "description": "Terminkredit blanko",
      "sortNr": 1450
    },
    {
      "code": "2932",
      "language": "fr",
      "shortcut": "TK b",
      "description": "CrÃ©dit Ã  terme en blanc",
      "sortNr": 1450
    },
    {
      "code": "2932",
      "language": "en",
      "shortcut": "TK b",
      "description": "Terminkredit blanko",
      "sortNr": 1450
    },
    {
      "code": "2933",
      "language": "de",
      "shortcut": "Lomb",
      "description": "Lombardkredit",
      "sortNr": 1500
    },
    {
      "code": "2933",
      "language": "fr",
      "shortcut": "Lomb",
      "description": "CrÃ©dit lombard",
      "sortNr": 1500
    },
    {
      "code": "2933",
      "language": "en",
      "shortcut": "Lomb",
      "description": "Lombardkredit",
      "sortNr": 1500
    },
    {
      "code": "2934",
      "language": "de",
      "shortcut": "KKÃ¼ k",
      "description": "Kontokorrent Kredit Ã¼brige FW kurant",
      "sortNr": 1310
    },
    {
      "code": "2934",
      "language": "fr",
      "shortcut": "KKÃ¼ k",
      "description": "Compte courant CrÃ©dit Autres ME courant",
      "sortNr": 1310
    },
    {
      "code": "2934",
      "language": "en",
      "shortcut": "KKÃ¼ k",
      "description": "Kontokorrent Kredit Ã¼brige FW kurant",
      "sortNr": 1310
    },
    {
      "code": "2935",
      "language": "de",
      "shortcut": "D OER",
      "description": "Darlehen variabel OERK",
      "sortNr": 1970
    },
    {
      "code": "2935",
      "language": "fr",
      "shortcut": "D OER",
      "description": "PrÃªt variable CDDP",
      "sortNr": 1970
    },
    {
      "code": "2935",
      "language": "en",
      "shortcut": "D OER",
      "description": "Darlehen variabel OERK",
      "sortNr": 1970
    },
    {
      "code": "2936",
      "language": "de",
      "shortcut": "FDk7J",
      "description": "Festdarlehen kurant 7 Jahre",
      "sortNr": 2070
    },
    {
      "code": "2936",
      "language": "fr",
      "shortcut": "FDk7J",
      "description": "PrÃªt fixe courant 7 ans",
      "sortNr": 2070
    },
    {
      "code": "2936",
      "language": "en",
      "shortcut": "FDk7J",
      "description": "Festdarlehen kurant 7 Jahre",
      "sortNr": 2070
    },
    {
      "code": "2937",
      "language": "de",
      "shortcut": "FDk9J",
      "description": "Festdarlehen kurant 9 Jahre",
      "sortNr": 2090
    },
    {
      "code": "2937",
      "language": "fr",
      "shortcut": "FDk9J",
      "description": "PrÃªt fixe courant 9 ans",
      "sortNr": 2090
    },
    {
      "code": "2937",
      "language": "en",
      "shortcut": "FDk9J",
      "description": "Festdarlehen kurant 9 Jahre",
      "sortNr": 2090
    },
    {
      "code": "2938",
      "language": "de",
      "shortcut": "FDuk4",
      "description": "Festdarlehen unkurant 4 Jahre",
      "sortNr": 2240
    },
    {
      "code": "2938",
      "language": "fr",
      "shortcut": "FDuk4",
      "description": "PrÃªt fixe non courant 4 ans",
      "sortNr": 2240
    },
    {
      "code": "2938",
      "language": "en",
      "shortcut": "FDuk4",
      "description": "Festdarlehen unkurant 4 Jahre",
      "sortNr": 2240
    },
    {
      "code": "2939",
      "language": "de",
      "shortcut": "FDb7J",
      "description": "Festdarlehen blanko 7 Jahre",
      "sortNr": 2470
    },
    {
      "code": "2939",
      "language": "fr",
      "shortcut": "FDb7J",
      "description": "PrÃªt fixe en blanc 7 ans",
      "sortNr": 2470
    },
    {
      "code": "2939",
      "language": "en",
      "shortcut": "FDb7J",
      "description": "Festdarlehen blanko 7 Jahre",
      "sortNr": 2470
    },
    {
      "code": "2940",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2860
    },
    {
      "code": "2940",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2860
    },
    {
      "code": "2940",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2860
    },
    {
      "code": "2941",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2941",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "2941",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "2942",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2942",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "2942",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "2943",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2943",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "2943",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2944",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2944",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "2944",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2945",
      "language": "de",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2945",
      "language": "fr",
      "shortcut": "2FH1J",
      "description": "HypothÃ¨que fixe 2e rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "2945",
      "language": "en",
      "shortcut": "2FH1J",
      "description": "2. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "2946",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2946",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "2946",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "2947",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2947",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2947",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2948",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2948",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "2948",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "2949",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2949",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "2949",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "2950",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2950",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "2950",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "2951",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2951",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "2951",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "2952",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2952",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2952",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2953",
      "language": "de",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2953",
      "language": "fr",
      "shortcut": "2FH4J",
      "description": "HypothÃ¨que fixe 2e rang 4 ans",
      "sortNr": 3240
    },
    {
      "code": "2953",
      "language": "en",
      "shortcut": "2FH4J",
      "description": "2. Festhypothek 4 Jahre",
      "sortNr": 3240
    },
    {
      "code": "2954",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2954",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2954",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2955",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2955",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2955",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2956",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2956",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2956",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2957",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2957",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2957",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2958",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2958",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2958",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2959",
      "language": "de",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2959",
      "language": "fr",
      "shortcut": "1FH5J",
      "description": "HypothÃ¨que fixe 1er rang 5 ans",
      "sortNr": 3150
    },
    {
      "code": "2959",
      "language": "en",
      "shortcut": "1FH5J",
      "description": "1. Festhypothek 5 Jahre",
      "sortNr": 3150
    },
    {
      "code": "2960",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2960",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "2960",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "2961",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2961",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "2961",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "2962",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2962",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "2962",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "2963",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2963",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "2963",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "2964",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2964",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "2964",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "2965",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2965",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2965",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2966",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2966",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2966",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2967",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2967",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2967",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2968",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2968",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "2968",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "2969",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2969",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2969",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2970",
      "language": "de",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2970",
      "language": "fr",
      "shortcut": "2FH10",
      "description": "HypothÃ¨que fixe 2e rang 10 ans",
      "sortNr": 3300
    },
    {
      "code": "2970",
      "language": "en",
      "shortcut": "2FH10",
      "description": "2. Festhypothek 10 Jahre",
      "sortNr": 3300
    },
    {
      "code": "2971",
      "language": "de",
      "shortcut": "2FW4J",
      "description": "2. Festhypothek WEG 4 Jahre",
      "sortNr": 4940
    },
    {
      "code": "2971",
      "language": "fr",
      "shortcut": "2FW4J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 4 ans",
      "sortNr": 4940
    },
    {
      "code": "2971",
      "language": "en",
      "shortcut": "2FW4J",
      "description": "2. Festhypothek WEG 4 Jahre",
      "sortNr": 4940
    },
    {
      "code": "2972",
      "language": "de",
      "shortcut": "2FW3J",
      "description": "2. Festhypothek WEG 3 Jahre",
      "sortNr": 4930
    },
    {
      "code": "2972",
      "language": "fr",
      "shortcut": "2FW3J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 3 ans",
      "sortNr": 4930
    },
    {
      "code": "2972",
      "language": "en",
      "shortcut": "2FW3J",
      "description": "2. Festhypothek WEG 3 Jahre",
      "sortNr": 4930
    },
    {
      "code": "2973",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2973",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "2973",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "2974",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2974",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "2974",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "2975",
      "language": "de",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2975",
      "language": "fr",
      "shortcut": "S11 8",
      "description": "HypothÃ¨que familiale fixe 1er rang 8 ans",
      "sortNr": 3880
    },
    {
      "code": "2975",
      "language": "en",
      "shortcut": "S11 8",
      "description": "1. Familienhypothek fest 8 Jahre",
      "sortNr": 3880
    },
    {
      "code": "2976",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2976",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2976",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2977",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2977",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "2977",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "2978",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2978",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2978",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2979",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2979",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2979",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2980",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2980",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2980",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2981",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2981",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2981",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2982",
      "language": "de",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2982",
      "language": "fr",
      "shortcut": "1FC52",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V2",
      "sortNr": 3440
    },
    {
      "code": "2982",
      "language": "en",
      "shortcut": "1FC52",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V2",
      "sortNr": 3440
    },
    {
      "code": "2983",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2983",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2983",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2984",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2984",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2984",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2985",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2985",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2985",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2986",
      "language": "de",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2986",
      "language": "fr",
      "shortcut": "1F3 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3450
    },
    {
      "code": "2986",
      "language": "en",
      "shortcut": "1F3 3",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3450
    },
    {
      "code": "2987",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2987",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "2987",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "2988",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2988",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "2988",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2989",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2989",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "2989",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "2990",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2990",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2990",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2991",
      "language": "de",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2991",
      "language": "fr",
      "shortcut": "1F6 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3480
    },
    {
      "code": "2991",
      "language": "en",
      "shortcut": "1F6 2",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3480
    },
    {
      "code": "2992",
      "language": "de",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2992",
      "language": "fr",
      "shortcut": "1F6 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3500
    },
    {
      "code": "2992",
      "language": "en",
      "shortcut": "1F6 4",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3500
    },
    {
      "code": "2993",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2993",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "2993",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2994",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2994",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "2994",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "2995",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2995",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "2995",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "2996",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2996",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "2996",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2997",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2997",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "2997",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "2998",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2998",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "2998",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "2999",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "2999",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "2999",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "3000",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "3000",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "3000",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "3001",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "3001",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "3001",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "3002",
      "language": "de",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "3002",
      "language": "fr",
      "shortcut": "2F6 1",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 1 an",
      "sortNr": 3580
    },
    {
      "code": "3002",
      "language": "en",
      "shortcut": "2F6 1",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3580
    },
    {
      "code": "3003",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "3003",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "3003",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "3004",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "3004",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "3004",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "3005",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "3005",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "3005",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "3006",
      "language": "de",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "3006",
      "language": "fr",
      "shortcut": "2F6 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 2 ans",
      "sortNr": 3590
    },
    {
      "code": "3006",
      "language": "en",
      "shortcut": "2F6 2",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 2 Jahre",
      "sortNr": 3590
    },
    {
      "code": "3007",
      "language": "de",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "3007",
      "language": "fr",
      "shortcut": "2F6 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3600
    },
    {
      "code": "3007",
      "language": "en",
      "shortcut": "2F6 3",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3600
    },
    {
      "code": "3008",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "3008",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "3008",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "3009",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "3009",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "3009",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "3010",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "3010",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "3010",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "3011",
      "language": "de",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "3011",
      "language": "fr",
      "shortcut": "S41",
      "description": "HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "3011",
      "language": "en",
      "shortcut": "S41",
      "description": "1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "3012",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "3012",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "3012",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "3013",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "3013",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "3013",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "3014",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "3014",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "3014",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "3015",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "3015",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "3015",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "3016",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "3016",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "3016",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "3017",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "3017",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "3017",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "3018",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "3018",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "3018",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "3019",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "3019",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "3019",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "3020",
      "language": "de",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "3020",
      "language": "fr",
      "shortcut": "S31 4",
      "description": "HypothÃ¨que Promotion 1er rang 4 ans",
      "sortNr": 4440
    },
    {
      "code": "3020",
      "language": "en",
      "shortcut": "S31 4",
      "description": "1. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4440
    },
    {
      "code": "3021",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "3021",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "3021",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "3022",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "3022",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "3022",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "3023",
      "language": "de",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "3023",
      "language": "fr",
      "shortcut": "S31 5",
      "description": "HypothÃ¨que Promotion 1er rang 5 ans",
      "sortNr": 4450
    },
    {
      "code": "3023",
      "language": "en",
      "shortcut": "S31 5",
      "description": "1. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4450
    },
    {
      "code": "3024",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "3024",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "3024",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "3025",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "3025",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "3025",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "3026",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "3026",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "3026",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "3027",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "3027",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "3027",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "3028",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3028",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "3028",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3029",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3029",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "3029",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3030",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3030",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "3030",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3031",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3031",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "3031",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3032",
      "language": "de",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "3032",
      "language": "fr",
      "shortcut": "S12 4",
      "description": "HypothÃ¨que familiale fixe 2e rang 4 ans",
      "sortNr": 3940
    },
    {
      "code": "3032",
      "language": "en",
      "shortcut": "S12 4",
      "description": "2. Familienhypothek fest 4 Jahre",
      "sortNr": 3940
    },
    {
      "code": "3033",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "3033",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "3033",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "3034",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "3034",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "3034",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "3035",
      "language": "de",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "3035",
      "language": "fr",
      "shortcut": "S12 5",
      "description": "HypothÃ¨que familiale fixe 2e rang 5 ans",
      "sortNr": 3950
    },
    {
      "code": "3035",
      "language": "en",
      "shortcut": "S12 5",
      "description": "2. Familienhypothek fest 5 Jahre",
      "sortNr": 3950
    },
    {
      "code": "3036",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3036",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "3036",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3037",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3037",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "3037",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3038",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3038",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "3038",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3039",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3039",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "3039",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3040",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3040",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "3040",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3041",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3041",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "3041",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3042",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "3042",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "3042",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "3043",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "3043",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "3043",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "3044",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "3044",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "3044",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "3045",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "3045",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "3045",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "3046",
      "language": "de",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "3046",
      "language": "fr",
      "shortcut": "S12 9",
      "description": "HypothÃ¨que familiale fixe 2e rang 9 ans",
      "sortNr": 3990
    },
    {
      "code": "3046",
      "language": "en",
      "shortcut": "S12 9",
      "description": "2. Familienhypothek fest 9 Jahre",
      "sortNr": 3990
    },
    {
      "code": "3047",
      "language": "de",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "3047",
      "language": "fr",
      "shortcut": "S21 1",
      "description": "HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "3047",
      "language": "en",
      "shortcut": "S21 1",
      "description": "1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "3048",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "3048",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "3048",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "3049",
      "language": "de",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "3049",
      "language": "fr",
      "shortcut": "S21 2",
      "description": "HypoTenplus 1er rang 2 ans",
      "sortNr": 4120
    },
    {
      "code": "3049",
      "language": "en",
      "shortcut": "S21 2",
      "description": "1. HypoTenplus 2 Jahre",
      "sortNr": 4120
    },
    {
      "code": "3050",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "3050",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "3050",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "3051",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "3051",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "3051",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "3052",
      "language": "de",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "3052",
      "language": "fr",
      "shortcut": "S21 5",
      "description": "HypoTenplus 1er rang 5 ans",
      "sortNr": 4150
    },
    {
      "code": "3052",
      "language": "en",
      "shortcut": "S21 5",
      "description": "1. HypoTenplus 5 Jahre",
      "sortNr": 4150
    },
    {
      "code": "3053",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3053",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "3053",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3054",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3054",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "3054",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3055",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3055",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "3055",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3056",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "3056",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "3056",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "3057",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "3057",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "3057",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "3058",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "3058",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "3058",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "3059",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "3059",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "3059",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "3060",
      "language": "de",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "3060",
      "language": "fr",
      "shortcut": "S22 4",
      "description": "HypoTenplus 2e rang 4 ans",
      "sortNr": 4240
    },
    {
      "code": "3060",
      "language": "en",
      "shortcut": "S22 4",
      "description": "2. HypoTenplus 4 Jahre",
      "sortNr": 4240
    },
    {
      "code": "3061",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "3061",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "3061",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "3062",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "3062",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "3062",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "3063",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "3063",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "3063",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "3064",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "3064",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "3064",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "3065",
      "language": "de",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "3065",
      "language": "fr",
      "shortcut": "S22 9",
      "description": "HypoTenplus 2e rang 9 ans",
      "sortNr": 4290
    },
    {
      "code": "3065",
      "language": "en",
      "shortcut": "S22 9",
      "description": "2. HypoTenplus 9 Jahre",
      "sortNr": 4290
    },
    {
      "code": "3066",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "3066",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "3066",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "3067",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "3067",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "3067",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "3068",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "3068",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "3068",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "3069",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "3069",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "3069",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "3070",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "3070",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "3070",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "3071",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "3071",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "3071",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "3072",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "3072",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "3072",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "3073",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "3073",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "3073",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "3074",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "3074",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "3074",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "3075",
      "language": "de",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "3075",
      "language": "fr",
      "shortcut": "2F3 2",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3552
    },
    {
      "code": "3075",
      "language": "en",
      "shortcut": "2F3 2",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3552
    },
    {
      "code": "3076",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "3076",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "3076",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "3077",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "3077",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "3077",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "3078",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "3078",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "3078",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "3079",
      "language": "de",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "3079",
      "language": "fr",
      "shortcut": "S31 6",
      "description": "HypothÃ¨que Promotion 1er rang 6 ans",
      "sortNr": 4460
    },
    {
      "code": "3079",
      "language": "en",
      "shortcut": "S31 6",
      "description": "1. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4460
    },
    {
      "code": "3080",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "3080",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "3080",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "3081",
      "language": "de",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "3081",
      "language": "fr",
      "shortcut": "S31 8",
      "description": "HypothÃ¨que Promotion 1er rang 8 ans",
      "sortNr": 4480
    },
    {
      "code": "3081",
      "language": "en",
      "shortcut": "S31 8",
      "description": "1. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4480
    },
    {
      "code": "3082",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "3082",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "3082",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "3083",
      "language": "de",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "3083",
      "language": "fr",
      "shortcut": "S32 1",
      "description": "HypothÃ¨que Promotion 2e rang 1 an",
      "sortNr": 4510
    },
    {
      "code": "3083",
      "language": "en",
      "shortcut": "S32 1",
      "description": "2. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4510
    },
    {
      "code": "3084",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "3084",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "3084",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "3085",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "3085",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "3085",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "3086",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "3086",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "3086",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "3087",
      "language": "de",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "3087",
      "language": "fr",
      "shortcut": "S32 4",
      "description": "HypothÃ¨que Promotion 2e rang 4 ans",
      "sortNr": 4540
    },
    {
      "code": "3087",
      "language": "en",
      "shortcut": "S32 4",
      "description": "2. Einsteiger-Hypothek 4 Jahre",
      "sortNr": 4540
    },
    {
      "code": "3088",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "3088",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "3088",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "3089",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "3089",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "3089",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "3090",
      "language": "de",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "3090",
      "language": "fr",
      "shortcut": "S32 7",
      "description": "HypothÃ¨que Promotion 2e rang 7 ans",
      "sortNr": 4570
    },
    {
      "code": "3090",
      "language": "en",
      "shortcut": "S32 7",
      "description": "2. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4570
    },
    {
      "code": "3091",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "3091",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "3091",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "3092",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "3092",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "3092",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "3093",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "3093",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "3093",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "3094",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "3094",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "3094",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "3095",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "3095",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "3095",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "3096",
      "language": "de",
      "shortcut": "TKOER",
      "description": "Terminkredit OERK",
      "sortNr": 1470
    },
    {
      "code": "3096",
      "language": "fr",
      "shortcut": "TKOER",
      "description": "CrÃ©dit Ã  terme collectivitÃ© publique",
      "sortNr": 1470
    },
    {
      "code": "3096",
      "language": "en",
      "shortcut": "TKOER",
      "description": "Terminkredit OERK",
      "sortNr": 1470
    },
    {
      "code": "3097",
      "language": "de",
      "shortcut": "PK b",
      "description": "Personalkredit blanko",
      "sortNr": 1650
    },
    {
      "code": "3097",
      "language": "fr",
      "shortcut": "PK b",
      "description": "CrÃ©dit personnel, en blanc",
      "sortNr": 1650
    },
    {
      "code": "3097",
      "language": "en",
      "shortcut": "PK b",
      "description": "Personalkredit blanko",
      "sortNr": 1650
    },
    {
      "code": "3098",
      "language": "de",
      "shortcut": "FDk10",
      "description": "Festdarlehen kurant 10 Jahre",
      "sortNr": 2100
    },
    {
      "code": "3098",
      "language": "fr",
      "shortcut": "FDk10",
      "description": "PrÃªt fixe courant 10 ans",
      "sortNr": 2100
    },
    {
      "code": "3098",
      "language": "en",
      "shortcut": "FDk10",
      "description": "Festdarlehen kurant 10 Jahre",
      "sortNr": 2100
    },
    {
      "code": "3099",
      "language": "de",
      "shortcut": "FDuk8",
      "description": "Festdarlehen unkurant 8 Jahre",
      "sortNr": 2280
    },
    {
      "code": "3099",
      "language": "fr",
      "shortcut": "FDuk8",
      "description": "PrÃªt fixe non courant 8 ans",
      "sortNr": 2280
    },
    {
      "code": "3099",
      "language": "en",
      "shortcut": "FDuk8",
      "description": "Festdarlehen unkurant 8 Jahre",
      "sortNr": 2280
    },
    {
      "code": "3100",
      "language": "de",
      "shortcut": "FDo2J",
      "description": "Festdarlehen OERK 2 Jahre",
      "sortNr": 2620
    },
    {
      "code": "3100",
      "language": "fr",
      "shortcut": "FDo2J",
      "description": "PrÃªt fixe CDDP 2 ans",
      "sortNr": 2620
    },
    {
      "code": "3100",
      "language": "en",
      "shortcut": "FDo2J",
      "description": "Festdarlehen OERK 2 Jahre",
      "sortNr": 2620
    },
    {
      "code": "3101",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2870
    },
    {
      "code": "3101",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2870
    },
    {
      "code": "3101",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2870
    },
    {
      "code": "3102",
      "language": "de",
      "shortcut": null,
      "description": null,
      "sortNr": 2900
    },
    {
      "code": "3102",
      "language": "fr",
      "shortcut": null,
      "description": null,
      "sortNr": 2900
    },
    {
      "code": "3102",
      "language": "en",
      "shortcut": null,
      "description": null,
      "sortNr": 2900
    },
    {
      "code": "3103",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "3103",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "3103",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "3104",
      "language": "de",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "3104",
      "language": "fr",
      "shortcut": "1Hvar",
      "description": "HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "3104",
      "language": "en",
      "shortcut": "1Hvar",
      "description": "1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "3105",
      "language": "de",
      "shortcut": "D",
      "description": "Darlehen variabel",
      "sortNr": 8050
    },
    {
      "code": "3105",
      "language": "fr",
      "shortcut": "D",
      "description": "PrÃªt variable",
      "sortNr": 8050
    },
    {
      "code": "3105",
      "language": "en",
      "shortcut": "D",
      "description": "Darlehen variabel",
      "sortNr": 8050
    },
    {
      "code": "3106",
      "language": "de",
      "shortcut": "FH",
      "description": "Festhypothek",
      "sortNr": 8080
    },
    {
      "code": "3106",
      "language": "fr",
      "shortcut": "FH",
      "description": "Hypo taux fixe",
      "sortNr": 8080
    },
    {
      "code": "3106",
      "language": "en",
      "shortcut": "FH",
      "description": "Festhypothek",
      "sortNr": 8080
    },
    {
      "code": "3107",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "3107",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "3107",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "3108",
      "language": "de",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "3108",
      "language": "fr",
      "shortcut": "2Hvar",
      "description": "HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "3108",
      "language": "en",
      "shortcut": "2Hvar",
      "description": "2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "3109",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "3109",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "3109",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "3110",
      "language": "de",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "3110",
      "language": "fr",
      "shortcut": "1FH1J",
      "description": "HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3110
    },
    {
      "code": "3110",
      "language": "en",
      "shortcut": "1FH1J",
      "description": "1. Festhypothek 1 Jahr",
      "sortNr": 3110
    },
    {
      "code": "3111",
      "language": "de",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "3111",
      "language": "fr",
      "shortcut": "1FH2J",
      "description": "HypothÃ¨que fixe 1er rang 2 ans",
      "sortNr": 3120
    },
    {
      "code": "3111",
      "language": "en",
      "shortcut": "1FH2J",
      "description": "1. Festhypothek 2 Jahre",
      "sortNr": 3120
    },
    {
      "code": "3112",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "3112",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "3112",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "3113",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "3113",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "3113",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "3114",
      "language": "de",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "3114",
      "language": "fr",
      "shortcut": "2FH2J",
      "description": "HypothÃ¨que fixe 2e rang 2 ans",
      "sortNr": 3220
    },
    {
      "code": "3114",
      "language": "en",
      "shortcut": "2FH2J",
      "description": "2. Festhypothek 2 Jahre",
      "sortNr": 3220
    },
    {
      "code": "3115",
      "language": "de",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "3115",
      "language": "fr",
      "shortcut": "1FH3J",
      "description": "HypothÃ¨que fixe 1er rang 3 ans",
      "sortNr": 3130
    },
    {
      "code": "3115",
      "language": "en",
      "shortcut": "1FH3J",
      "description": "1. Festhypothek 3 Jahre",
      "sortNr": 3130
    },
    {
      "code": "3116",
      "language": "de",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "3116",
      "language": "fr",
      "shortcut": "2FH3J",
      "description": "HypothÃ¨que fixe 2e rang 3 ans",
      "sortNr": 3230
    },
    {
      "code": "3116",
      "language": "en",
      "shortcut": "2FH3J",
      "description": "2. Festhypothek 3 Jahre",
      "sortNr": 3230
    },
    {
      "code": "3117",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "3117",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "3117",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "3118",
      "language": "de",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "3118",
      "language": "fr",
      "shortcut": "1FH4J",
      "description": "HypothÃ¨que fixe 1er rang 4 ans",
      "sortNr": 3140
    },
    {
      "code": "3118",
      "language": "en",
      "shortcut": "1FH4J",
      "description": "1. Festhypothek 4 Jahre",
      "sortNr": 3140
    },
    {
      "code": "3119",
      "language": "de",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "3119",
      "language": "fr",
      "shortcut": "2FH5J",
      "description": "HypothÃ¨que fixe 2e rang 5 ans",
      "sortNr": 3250
    },
    {
      "code": "3119",
      "language": "en",
      "shortcut": "2FH5J",
      "description": "2. Festhypothek 5 Jahre",
      "sortNr": 3250
    },
    {
      "code": "3120",
      "language": "de",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "3120",
      "language": "fr",
      "shortcut": "1FH6J",
      "description": "HypothÃ¨que fixe 1er rang 6 ans",
      "sortNr": 3160
    },
    {
      "code": "3120",
      "language": "en",
      "shortcut": "1FH6J",
      "description": "1. Festhypothek 6 Jahre",
      "sortNr": 3160
    },
    {
      "code": "3121",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "3121",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "3121",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "3122",
      "language": "de",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "3122",
      "language": "fr",
      "shortcut": "1FH7J",
      "description": "HypothÃ¨que fixe 1er rang 7 ans",
      "sortNr": 3170
    },
    {
      "code": "3122",
      "language": "en",
      "shortcut": "1FH7J",
      "description": "1. Festhypothek 7 Jahre",
      "sortNr": 3170
    },
    {
      "code": "3123",
      "language": "de",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "3123",
      "language": "fr",
      "shortcut": "2FH6J",
      "description": "HypothÃ¨que fixe 2e rang 6 ans",
      "sortNr": 3260
    },
    {
      "code": "3123",
      "language": "en",
      "shortcut": "2FH6J",
      "description": "2. Festhypothek 6 Jahre",
      "sortNr": 3260
    },
    {
      "code": "3124",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "3124",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "3124",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "3125",
      "language": "de",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "3125",
      "language": "fr",
      "shortcut": "2FH7J",
      "description": "HypothÃ¨que fixe 2e rang 7 ans",
      "sortNr": 3270
    },
    {
      "code": "3125",
      "language": "en",
      "shortcut": "2FH7J",
      "description": "2. Festhypothek 7 Jahre",
      "sortNr": 3270
    },
    {
      "code": "3126",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "3126",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "3126",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "3127",
      "language": "de",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "3127",
      "language": "fr",
      "shortcut": "1FH8J",
      "description": "HypothÃ¨que fixe 1er rang 8 ans",
      "sortNr": 3180
    },
    {
      "code": "3127",
      "language": "en",
      "shortcut": "1FH8J",
      "description": "1. Festhypothek 8 Jahre",
      "sortNr": 3180
    },
    {
      "code": "3128",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "3128",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "3128",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "3129",
      "language": "de",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "3129",
      "language": "fr",
      "shortcut": "2FH8J",
      "description": "HypothÃ¨que fixe 2e rang 8 ans",
      "sortNr": 3280
    },
    {
      "code": "3129",
      "language": "en",
      "shortcut": "2FH8J",
      "description": "2. Festhypothek 8 Jahre",
      "sortNr": 3280
    },
    {
      "code": "3130",
      "language": "de",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "3130",
      "language": "fr",
      "shortcut": "2FH9J",
      "description": "HypothÃ¨que fixe 2e rang 9 ans",
      "sortNr": 3290
    },
    {
      "code": "3130",
      "language": "en",
      "shortcut": "2FH9J",
      "description": "2. Festhypothek 9 Jahre",
      "sortNr": 3290
    },
    {
      "code": "3131",
      "language": "de",
      "shortcut": "1FW2J",
      "description": "1. Festhypothek WEG 2 Jahre",
      "sortNr": 4820
    },
    {
      "code": "3131",
      "language": "fr",
      "shortcut": "1FW2J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 2 ans",
      "sortNr": 4820
    },
    {
      "code": "3131",
      "language": "en",
      "shortcut": "1FW2J",
      "description": "1. Festhypothek WEG 2 Jahre",
      "sortNr": 4820
    },
    {
      "code": "3132",
      "language": "de",
      "shortcut": "1FW8J",
      "description": "1. Festhypothek WEG 8 Jahre",
      "sortNr": 4880
    },
    {
      "code": "3132",
      "language": "fr",
      "shortcut": "1FW8J",
      "description": "HypothÃ¨que fixe 1er rang LCAP 8 ans",
      "sortNr": 4880
    },
    {
      "code": "3132",
      "language": "en",
      "shortcut": "1FW8J",
      "description": "1. Festhypothek WEG 8 Jahre",
      "sortNr": 4880
    },
    {
      "code": "3133",
      "language": "de",
      "shortcut": "2FW8J",
      "description": "2. Festhypothek WEG 8 Jahre",
      "sortNr": 4980
    },
    {
      "code": "3133",
      "language": "fr",
      "shortcut": "2FW8J",
      "description": "HypothÃ¨que fixe 2e rang LCAP 8 ans",
      "sortNr": 4980
    },
    {
      "code": "3133",
      "language": "en",
      "shortcut": "2FW8J",
      "description": "2. Festhypothek WEG 8 Jahre",
      "sortNr": 4980
    },
    {
      "code": "3134",
      "language": "de",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "3134",
      "language": "fr",
      "shortcut": "S11 4",
      "description": "HypothÃ¨que familiale fixe 1er rang 4 ans",
      "sortNr": 3840
    },
    {
      "code": "3134",
      "language": "en",
      "shortcut": "S11 4",
      "description": "1. Familienhypothek fest 4 Jahre",
      "sortNr": 3840
    },
    {
      "code": "3135",
      "language": "de",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "3135",
      "language": "fr",
      "shortcut": "S11 6",
      "description": "HypothÃ¨que familiale fixe 1er rang 6 ans",
      "sortNr": 3860
    },
    {
      "code": "3135",
      "language": "en",
      "shortcut": "S11 6",
      "description": "1. Familienhypothek fest 6 Jahre",
      "sortNr": 3860
    },
    {
      "code": "3136",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "3136",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "3136",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "3137",
      "language": "de",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "3137",
      "language": "fr",
      "shortcut": "S11 7",
      "description": "HypothÃ¨que familiale fixe 1er rang 7 ans",
      "sortNr": 3870
    },
    {
      "code": "3137",
      "language": "en",
      "shortcut": "S11 7",
      "description": "1. Familienhypothek fest 7 Jahre",
      "sortNr": 3870
    },
    {
      "code": "3138",
      "language": "de",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "3138",
      "language": "fr",
      "shortcut": "1FC31",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "3138",
      "language": "en",
      "shortcut": "1FC31",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "3139",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "3139",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "3139",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "3140",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "3140",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "3140",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "3141",
      "language": "de",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "3141",
      "language": "fr",
      "shortcut": "1FC32",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3420
    },
    {
      "code": "3141",
      "language": "en",
      "shortcut": "1FC32",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3420
    },
    {
      "code": "3142",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "3142",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "3142",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "3143",
      "language": "de",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "3143",
      "language": "fr",
      "shortcut": "1FC51",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3430
    },
    {
      "code": "3143",
      "language": "en",
      "shortcut": "1FC51",
      "description": "1. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3430
    },
    {
      "code": "3144",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "3144",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "3144",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "3145",
      "language": "de",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "3145",
      "language": "fr",
      "shortcut": "1F3 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3460
    },
    {
      "code": "3145",
      "language": "en",
      "shortcut": "1F3 5",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3460
    },
    {
      "code": "3146",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "3146",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "3146",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "3147",
      "language": "de",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "3147",
      "language": "fr",
      "shortcut": "1F6 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 1 an",
      "sortNr": 3470
    },
    {
      "code": "3147",
      "language": "en",
      "shortcut": "1F6 1",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 1 Jahre",
      "sortNr": 3470
    },
    {
      "code": "3148",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "3148",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "3148",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "3149",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "3149",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "3149",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "3150",
      "language": "de",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "3150",
      "language": "fr",
      "shortcut": "1F6 3",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 3 ans",
      "sortNr": 3490
    },
    {
      "code": "3150",
      "language": "en",
      "shortcut": "1F6 3",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 3 Jahre",
      "sortNr": 3490
    },
    {
      "code": "3151",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "3151",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "3151",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "3152",
      "language": "de",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "3152",
      "language": "fr",
      "shortcut": "1F6 5",
      "description": "HypothÃ¨que Flex 1er rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3510
    },
    {
      "code": "3152",
      "language": "en",
      "shortcut": "1F6 5",
      "description": "1. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3510
    },
    {
      "code": "3153",
      "language": "de",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "3153",
      "language": "fr",
      "shortcut": "2FC31",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3520
    },
    {
      "code": "3153",
      "language": "en",
      "shortcut": "2FC31",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3520
    },
    {
      "code": "3154",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "3154",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "3154",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "3155",
      "language": "de",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "3155",
      "language": "fr",
      "shortcut": "2FC32",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 3 ans V2",
      "sortNr": 3530
    },
    {
      "code": "3155",
      "language": "en",
      "shortcut": "2FC32",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 3 Jahre V2",
      "sortNr": 3530
    },
    {
      "code": "3156",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "3156",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "3156",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "3157",
      "language": "de",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "3157",
      "language": "fr",
      "shortcut": "2FC51",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) avec cap 5 ans V1",
      "sortNr": 3540
    },
    {
      "code": "3157",
      "language": "en",
      "shortcut": "2FC51",
      "description": "2. Flexhypothek (Libor 3M) mit Cap 5 Jahre V1",
      "sortNr": 3540
    },
    {
      "code": "3158",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "3158",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "3158",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "3159",
      "language": "de",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "3159",
      "language": "fr",
      "shortcut": "2F3 3",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 3 ans",
      "sortNr": 3560
    },
    {
      "code": "3159",
      "language": "en",
      "shortcut": "2F3 3",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 3 Jahre",
      "sortNr": 3560
    },
    {
      "code": "3160",
      "language": "de",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "3160",
      "language": "fr",
      "shortcut": "2F3 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 5 ans",
      "sortNr": 3570
    },
    {
      "code": "3160",
      "language": "en",
      "shortcut": "2F3 5",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 5 Jahre",
      "sortNr": 3570
    },
    {
      "code": "3161",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "3161",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "3161",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "3162",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "3162",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "3162",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "3163",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "3163",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "3163",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "3164",
      "language": "de",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "3164",
      "language": "fr",
      "shortcut": "2F6 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 4 ans",
      "sortNr": 3610
    },
    {
      "code": "3164",
      "language": "en",
      "shortcut": "2F6 4",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 4 Jahre",
      "sortNr": 3610
    },
    {
      "code": "3165",
      "language": "de",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "3165",
      "language": "fr",
      "shortcut": "2F6 5",
      "description": "HypothÃ¨que Flex 2e rang (Libor 6M) sans cap 5 ans",
      "sortNr": 3620
    },
    {
      "code": "3165",
      "language": "en",
      "shortcut": "2F6 5",
      "description": "2. Flexhypothek (Libor 6M) ohne Cap 5 Jahre",
      "sortNr": 3620
    },
    {
      "code": "3166",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "3166",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "3166",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "3167",
      "language": "de",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "3167",
      "language": "fr",
      "shortcut": "S42",
      "description": "HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "3167",
      "language": "en",
      "shortcut": "S42",
      "description": "2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "3168",
      "language": "de",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "3168",
      "language": "fr",
      "shortcut": "S11 1",
      "description": "HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3810
    },
    {
      "code": "3168",
      "language": "en",
      "shortcut": "S11 1",
      "description": "1. Familienhypothek fest 1 Jahr",
      "sortNr": 3810
    },
    {
      "code": "3169",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "3169",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "3169",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "3170",
      "language": "de",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "3170",
      "language": "fr",
      "shortcut": "S11 2",
      "description": "HypothÃ¨que familiale fixe 1er rang 2 ans",
      "sortNr": 3820
    },
    {
      "code": "3170",
      "language": "en",
      "shortcut": "S11 2",
      "description": "1. Familienhypothek fest 2 Jahre",
      "sortNr": 3820
    },
    {
      "code": "3171",
      "language": "de",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "3171",
      "language": "fr",
      "shortcut": "S11 3",
      "description": "HypothÃ¨que familiale fixe 1er rang 3 ans",
      "sortNr": 3830
    },
    {
      "code": "3171",
      "language": "en",
      "shortcut": "S11 3",
      "description": "1. Familienhypothek fest 3 Jahre",
      "sortNr": 3830
    },
    {
      "code": "3172",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "3172",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "3172",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "3173",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "3173",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "3173",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "3174",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "3174",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "3174",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "3175",
      "language": "de",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "3175",
      "language": "fr",
      "shortcut": "S31 2",
      "description": "HypothÃ¨que Promotion 1er rang 2 ans",
      "sortNr": 4420
    },
    {
      "code": "3175",
      "language": "en",
      "shortcut": "S31 2",
      "description": "1. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4420
    },
    {
      "code": "3176",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "3176",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "3176",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "3177",
      "language": "de",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "3177",
      "language": "fr",
      "shortcut": "S31 3",
      "description": "HypothÃ¨que Promotion 1er rang 3 ans",
      "sortNr": 4430
    },
    {
      "code": "3177",
      "language": "en",
      "shortcut": "S31 3",
      "description": "1. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4430
    },
    {
      "code": "3178",
      "language": "de",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "3178",
      "language": "fr",
      "shortcut": "S11 9",
      "description": "HypothÃ¨que familiale fixe 1er rang 9 ans",
      "sortNr": 3890
    },
    {
      "code": "3178",
      "language": "en",
      "shortcut": "S11 9",
      "description": "1. Familienhypothek fest 9 Jahre",
      "sortNr": 3890
    },
    {
      "code": "3179",
      "language": "de",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "3179",
      "language": "fr",
      "shortcut": "S1110",
      "description": "HypothÃ¨que familiale fixe 1er rang 10 ans",
      "sortNr": 3900
    },
    {
      "code": "3179",
      "language": "en",
      "shortcut": "S1110",
      "description": "1. Familienhypothek fest 10 Jahre",
      "sortNr": 3900
    },
    {
      "code": "3180",
      "language": "de",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3180",
      "language": "fr",
      "shortcut": "S12 1",
      "description": "HypothÃ¨que familiale fixe 2e rang 1 an",
      "sortNr": 3910
    },
    {
      "code": "3180",
      "language": "en",
      "shortcut": "S12 1",
      "description": "2. Familienhypothek fest 1 Jahr",
      "sortNr": 3910
    },
    {
      "code": "3181",
      "language": "de",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "3181",
      "language": "fr",
      "shortcut": "S12 2",
      "description": "HypothÃ¨que familiale fixe 2e rang 2 ans",
      "sortNr": 3920
    },
    {
      "code": "3181",
      "language": "en",
      "shortcut": "S12 2",
      "description": "2. Familienhypothek fest 2 Jahre",
      "sortNr": 3920
    },
    {
      "code": "3182",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "3182",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "3182",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "3183",
      "language": "de",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "3183",
      "language": "fr",
      "shortcut": "S12 3",
      "description": "HypothÃ¨que familiale fixe 2e rang 3 ans",
      "sortNr": 3930
    },
    {
      "code": "3183",
      "language": "en",
      "shortcut": "S12 3",
      "description": "2. Familienhypothek fest 3 Jahre",
      "sortNr": 3930
    },
    {
      "code": "3184",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3184",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "3184",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3185",
      "language": "de",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3185",
      "language": "fr",
      "shortcut": "S12 6",
      "description": "HypothÃ¨que familiale fixe 2e rang 6 ans",
      "sortNr": 3960
    },
    {
      "code": "3185",
      "language": "en",
      "shortcut": "S12 6",
      "description": "2. Familienhypothek fest 6 Jahre",
      "sortNr": 3960
    },
    {
      "code": "3186",
      "language": "de",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "3186",
      "language": "fr",
      "shortcut": "S12 7",
      "description": "HypothÃ¨que familiale fixe 2e rang 7 ans",
      "sortNr": 3970
    },
    {
      "code": "3186",
      "language": "en",
      "shortcut": "S12 7",
      "description": "2. Familienhypothek fest 7 Jahre",
      "sortNr": 3970
    },
    {
      "code": "3187",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "3187",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "3187",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "3188",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "3188",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "3188",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "3189",
      "language": "de",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "3189",
      "language": "fr",
      "shortcut": "S12 8",
      "description": "HypothÃ¨que familiale fixe 2e rang 8 ans",
      "sortNr": 3980
    },
    {
      "code": "3189",
      "language": "en",
      "shortcut": "S12 8",
      "description": "2. Familienhypothek fest 8 Jahre",
      "sortNr": 3980
    },
    {
      "code": "3190",
      "language": "de",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "3190",
      "language": "fr",
      "shortcut": "S1210",
      "description": "HypothÃ¨que familiale fixe 2e rang 10 ans",
      "sortNr": 4000
    },
    {
      "code": "3190",
      "language": "en",
      "shortcut": "S1210",
      "description": "2. Familienhypothek fest 10 Jahre",
      "sortNr": 4000
    },
    {
      "code": "3191",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "3191",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "3191",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "3192",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "3192",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "3192",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "3193",
      "language": "de",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "3193",
      "language": "fr",
      "shortcut": "S21 3",
      "description": "HypoTenplus 1er rang 3 ans",
      "sortNr": 4130
    },
    {
      "code": "3193",
      "language": "en",
      "shortcut": "S21 3",
      "description": "1. HypoTenplus 3 Jahre",
      "sortNr": 4130
    },
    {
      "code": "3194",
      "language": "de",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "3194",
      "language": "fr",
      "shortcut": "S21 4",
      "description": "HypoTenplus 1er rang 4 ans",
      "sortNr": 4140
    },
    {
      "code": "3194",
      "language": "en",
      "shortcut": "S21 4",
      "description": "1. HypoTenplus 4 Jahre",
      "sortNr": 4140
    },
    {
      "code": "3195",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3195",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "3195",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3196",
      "language": "de",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3196",
      "language": "fr",
      "shortcut": "S21 6",
      "description": "HypoTenplus 1er rang 6 ans",
      "sortNr": 4160
    },
    {
      "code": "3196",
      "language": "en",
      "shortcut": "S21 6",
      "description": "1. HypoTenplus 6 Jahre",
      "sortNr": 4160
    },
    {
      "code": "3197",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "3197",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "3197",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "3198",
      "language": "de",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "3198",
      "language": "fr",
      "shortcut": "S21 7",
      "description": "HypoTenplus 1er rang 7 ans",
      "sortNr": 4170
    },
    {
      "code": "3198",
      "language": "en",
      "shortcut": "S21 7",
      "description": "1. HypoTenplus 7 Jahre",
      "sortNr": 4170
    },
    {
      "code": "3199",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "3199",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "3199",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "3200",
      "language": "de",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "3200",
      "language": "fr",
      "shortcut": "S21 8",
      "description": "HypoTenplus 1er rang 8 ans",
      "sortNr": 4180
    },
    {
      "code": "3200",
      "language": "en",
      "shortcut": "S21 8",
      "description": "1. HypoTenplus 8 Jahre",
      "sortNr": 4180
    },
    {
      "code": "3201",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "3201",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "3201",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "3202",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "3202",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "3202",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "3203",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "3203",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "3203",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "3204",
      "language": "de",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "3204",
      "language": "fr",
      "shortcut": "S21 9",
      "description": "HypoTenplus 1er rang 9 ans",
      "sortNr": 4190
    },
    {
      "code": "3204",
      "language": "en",
      "shortcut": "S21 9",
      "description": "1. HypoTenplus 9 Jahre",
      "sortNr": 4190
    },
    {
      "code": "3205",
      "language": "de",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "3205",
      "language": "fr",
      "shortcut": "S2110",
      "description": "HypoTenplus 1er rang 10 ans",
      "sortNr": 4200
    },
    {
      "code": "3205",
      "language": "en",
      "shortcut": "S2110",
      "description": "1. HypoTenplus 10 Jahre",
      "sortNr": 4200
    },
    {
      "code": "3206",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "3206",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "3206",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "3207",
      "language": "de",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "3207",
      "language": "fr",
      "shortcut": "S22 1",
      "description": "HypoTenplus 2e rang 1 an",
      "sortNr": 4210
    },
    {
      "code": "3207",
      "language": "en",
      "shortcut": "S22 1",
      "description": "2. HypoTenplus 1 Jahr",
      "sortNr": 4210
    },
    {
      "code": "3208",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "3208",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "3208",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "3209",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "3209",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "3209",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "3210",
      "language": "de",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "3210",
      "language": "fr",
      "shortcut": "S22 2",
      "description": "HypoTenplus 2e rang 2 ans",
      "sortNr": 4220
    },
    {
      "code": "3210",
      "language": "en",
      "shortcut": "S22 2",
      "description": "2. HypoTenplus 2 Jahre",
      "sortNr": 4220
    },
    {
      "code": "3211",
      "language": "de",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "3211",
      "language": "fr",
      "shortcut": "S22 3",
      "description": "HypoTenplus 2e rang 3 ans",
      "sortNr": 4230
    },
    {
      "code": "3211",
      "language": "en",
      "shortcut": "S22 3",
      "description": "2. HypoTenplus 3 Jahre",
      "sortNr": 4230
    },
    {
      "code": "3212",
      "language": "de",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "3212",
      "language": "fr",
      "shortcut": "S22 5",
      "description": "HypoTenplus 2e rang 5 ans",
      "sortNr": 4250
    },
    {
      "code": "3212",
      "language": "en",
      "shortcut": "S22 5",
      "description": "2. HypoTenplus 5 Jahre",
      "sortNr": 4250
    },
    {
      "code": "3213",
      "language": "de",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "3213",
      "language": "fr",
      "shortcut": "S22 6",
      "description": "HypoTenplus 2e rang 6 ans",
      "sortNr": 4260
    },
    {
      "code": "3213",
      "language": "en",
      "shortcut": "S22 6",
      "description": "2. HypoTenplus 6 Jahre",
      "sortNr": 4260
    },
    {
      "code": "3214",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "3214",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "3214",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "3215",
      "language": "de",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "3215",
      "language": "fr",
      "shortcut": "S22 7",
      "description": "HypoTenplus 2e rang 7 ans",
      "sortNr": 4270
    },
    {
      "code": "3215",
      "language": "en",
      "shortcut": "S22 7",
      "description": "2. HypoTenplus 7 Jahre",
      "sortNr": 4270
    },
    {
      "code": "3216",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "3216",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "3216",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "3217",
      "language": "de",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "3217",
      "language": "fr",
      "shortcut": "S22 8",
      "description": "HypoTenplus 2e rang 8 ans",
      "sortNr": 4280
    },
    {
      "code": "3217",
      "language": "en",
      "shortcut": "S22 8",
      "description": "2. HypoTenplus 8 Jahre",
      "sortNr": 4280
    },
    {
      "code": "3218",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "3218",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "3218",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "3219",
      "language": "de",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "3219",
      "language": "fr",
      "shortcut": "S2210",
      "description": "HypoTenplus 2e rang 10 ans",
      "sortNr": 4300
    },
    {
      "code": "3219",
      "language": "en",
      "shortcut": "S2210",
      "description": "2. HypoTenplus 10 Jahre",
      "sortNr": 4300
    },
    {
      "code": "3220",
      "language": "de",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "3220",
      "language": "fr",
      "shortcut": "S31 1",
      "description": "HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4410
    },
    {
      "code": "3220",
      "language": "en",
      "shortcut": "S31 1",
      "description": "1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4410
    },
    {
      "code": "3221",
      "language": "de",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "3221",
      "language": "fr",
      "shortcut": "1F3 1",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 1 an",
      "sortNr": 3441
    },
    {
      "code": "3221",
      "language": "en",
      "shortcut": "1F3 1",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 1 Jahr",
      "sortNr": 3441
    },
    {
      "code": "3222",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "3222",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "3222",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "3223",
      "language": "de",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "3223",
      "language": "fr",
      "shortcut": "1F3 2",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 2 ans",
      "sortNr": 3442
    },
    {
      "code": "3223",
      "language": "en",
      "shortcut": "1F3 2",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 2 Jahre",
      "sortNr": 3442
    },
    {
      "code": "3224",
      "language": "de",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "3224",
      "language": "fr",
      "shortcut": "1F3 4",
      "description": "HypothÃ¨que Flex 1er rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3451
    },
    {
      "code": "3224",
      "language": "en",
      "shortcut": "1F3 4",
      "description": "1. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3451
    },
    {
      "code": "3225",
      "language": "de",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "3225",
      "language": "fr",
      "shortcut": "2F3 4",
      "description": "HypothÃ¨que Flex 2e rang (Libor 3M) sans cap 4 ans",
      "sortNr": 3561
    },
    {
      "code": "3225",
      "language": "en",
      "shortcut": "2F3 4",
      "description": "2. Flexhypothek (Libor 3M) ohne Cap 4 Jahre",
      "sortNr": 3561
    },
    {
      "code": "3226",
      "language": "de",
      "shortcut": "S3",
      "description": "Einsteiger-Hypothek",
      "sortNr": 8120
    },
    {
      "code": "3226",
      "language": "fr",
      "shortcut": "S3",
      "description": "HypothÃ¨que Promotion",
      "sortNr": 8120
    },
    {
      "code": "3226",
      "language": "en",
      "shortcut": "S3",
      "description": "Einsteiger-Hypothek",
      "sortNr": 8120
    },
    {
      "code": "3227",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "3227",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "3227",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "3228",
      "language": "de",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "3228",
      "language": "fr",
      "shortcut": "S31 7",
      "description": "HypothÃ¨que Promotion 1er rang 7 ans",
      "sortNr": 4470
    },
    {
      "code": "3228",
      "language": "en",
      "shortcut": "S31 7",
      "description": "1. Einsteiger-Hypothek 7 Jahre",
      "sortNr": 4470
    },
    {
      "code": "3229",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "3229",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "3229",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "3230",
      "language": "de",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "3230",
      "language": "fr",
      "shortcut": "S31 9",
      "description": "HypothÃ¨que Promotion 1er rang 9 ans",
      "sortNr": 4490
    },
    {
      "code": "3230",
      "language": "en",
      "shortcut": "S31 9",
      "description": "1. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4490
    },
    {
      "code": "3231",
      "language": "de",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "3231",
      "language": "fr",
      "shortcut": "S3110",
      "description": "HypothÃ¨que Promotion 1er rang 10 ans",
      "sortNr": 4500
    },
    {
      "code": "3231",
      "language": "en",
      "shortcut": "S3110",
      "description": "1. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4500
    },
    {
      "code": "3232",
      "language": "de",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "3232",
      "language": "fr",
      "shortcut": "S32 2",
      "description": "HypothÃ¨que Promotion 2e rang 2 ans",
      "sortNr": 4520
    },
    {
      "code": "3232",
      "language": "en",
      "shortcut": "S32 2",
      "description": "2. Einsteiger-Hypothek 2 Jahre",
      "sortNr": 4520
    },
    {
      "code": "3233",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "3233",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "3233",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "3234",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "3234",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "3234",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "3235",
      "language": "de",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "3235",
      "language": "fr",
      "shortcut": "S32 3",
      "description": "HypothÃ¨que Promotion 2e rang 3 ans",
      "sortNr": 4530
    },
    {
      "code": "3235",
      "language": "en",
      "shortcut": "S32 3",
      "description": "2. Einsteiger-Hypothek 3 Jahre",
      "sortNr": 4530
    },
    {
      "code": "3236",
      "language": "de",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "3236",
      "language": "fr",
      "shortcut": "S32 5",
      "description": "HypothÃ¨que Promotion 2e rang 5 ans",
      "sortNr": 4550
    },
    {
      "code": "3236",
      "language": "en",
      "shortcut": "S32 5",
      "description": "2. Einsteiger-Hypothek 5 Jahre",
      "sortNr": 4550
    },
    {
      "code": "3237",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "3237",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "3237",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "3238",
      "language": "de",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "3238",
      "language": "fr",
      "shortcut": "S32 6",
      "description": "HypothÃ¨que Promotion 2e rang 6 ans",
      "sortNr": 4560
    },
    {
      "code": "3238",
      "language": "en",
      "shortcut": "S32 6",
      "description": "2. Einsteiger-Hypothek 6 Jahre",
      "sortNr": 4560
    },
    {
      "code": "3239",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "3239",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "3239",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "3240",
      "language": "de",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "3240",
      "language": "fr",
      "shortcut": "S32 8",
      "description": "HypothÃ¨que Promotion 2e rang 8 ans",
      "sortNr": 4580
    },
    {
      "code": "3240",
      "language": "en",
      "shortcut": "S32 8",
      "description": "2. Einsteiger-Hypothek 8 Jahre",
      "sortNr": 4580
    },
    {
      "code": "3241",
      "language": "de",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "3241",
      "language": "fr",
      "shortcut": "S32 9",
      "description": "HypothÃ¨que Promotion 2e rang 9 ans",
      "sortNr": 4590
    },
    {
      "code": "3241",
      "language": "en",
      "shortcut": "S32 9",
      "description": "2. Einsteiger-Hypothek 9 Jahre",
      "sortNr": 4590
    },
    {
      "code": "3242",
      "language": "de",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "3242",
      "language": "fr",
      "shortcut": "S3210",
      "description": "HypothÃ¨que Promotion 2e rang 10 ans",
      "sortNr": 4600
    },
    {
      "code": "3242",
      "language": "en",
      "shortcut": "S3210",
      "description": "2. Einsteiger-Hypothek 10 Jahre",
      "sortNr": 4600
    },
    {
      "code": "3243",
      "language": "de",
      "shortcut": "DtmLi",
      "description": "Devisenterminlimite",
      "sortNr": 1690
    },
    {
      "code": "3243",
      "language": "fr",
      "shortcut": "LiDeT",
      "description": "Limite de devises Ã  terme",
      "sortNr": 1690
    },
    {
      "code": "3243",
      "language": "en",
      "shortcut": "DtmLi",
      "description": "Devisenterminlimite",
      "sortNr": 1690
    },
    {
      "code": "3244",
      "language": "de",
      "shortcut": "D",
      "description": "Darlehen variabel",
      "sortNr": 8050
    },
    {
      "code": "3244",
      "language": "fr",
      "shortcut": "D",
      "description": "PrÃªt variable",
      "sortNr": 8050
    },
    {
      "code": "3244",
      "language": "en",
      "shortcut": "D",
      "description": "Darlehen variabel",
      "sortNr": 8050
    },
    {
      "code": "3245",
      "language": "de",
      "shortcut": "ToMli",
      "description": "Toff-Margenlimite",
      "sortNr": 1691
    },
    {
      "code": "3245",
      "language": "fr",
      "shortcut": "ToMli",
      "description": "Toff-Margenlimite",
      "sortNr": 1691
    },
    {
      "code": "3245",
      "language": "en",
      "shortcut": "ToMli",
      "description": "Toff-Margenlimite",
      "sortNr": 1691
    },
    {
      "code": "3246",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3246",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3246",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3247",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3247",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3247",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3248",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3248",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3248",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3249",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3249",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3249",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3250",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3250",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3250",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3251",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3251",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3251",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3252",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3252",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3252",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3253",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3253",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3253",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3254",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3254",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3254",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3255",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3255",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3255",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3256",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3256",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3256",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3257",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3257",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3257",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3258",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3258",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3258",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3259",
      "language": "de",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3259",
      "language": "fr",
      "shortcut": "BauKr",
      "description": "CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "3259",
      "language": "en",
      "shortcut": "BauKr",
      "description": "Baukredit",
      "sortNr": 1800
    },
    {
      "code": "3260",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3260",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3260",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3261",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3261",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3261",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3262",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3262",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3262",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3263",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3263",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3263",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3264",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3264",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3264",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3265",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3265",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3265",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3266",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3266",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3266",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3267",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3267",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3267",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3268",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3268",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3268",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3269",
      "language": "de",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "3269",
      "language": "fr",
      "shortcut": "1FH10",
      "description": "HypothÃ¨que fixe 1er rang plus de 10 ans",
      "sortNr": 3205
    },
    {
      "code": "3269",
      "language": "en",
      "shortcut": "1FH10",
      "description": "1. Festhypothek Ã¼ber 10 Jahre",
      "sortNr": 3205
    },
    {
      "code": "4000",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4000",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4000",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4001",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4001",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4001",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4002",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4002",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4002",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4003",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kautionen",
      "sortNr": 1700
    },
    {
      "code": "4003",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Cautions",
      "sortNr": 1700
    },
    {
      "code": "4003",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kautionen",
      "sortNr": 1700
    },
    {
      "code": "4004",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel kurant",
      "sortNr": 1910
    },
    {
      "code": "4004",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt variable courant",
      "sortNr": 1910
    },
    {
      "code": "4004",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel kurant",
      "sortNr": 1910
    },
    {
      "code": "4005",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek fest 1 Jahr",
      "sortNr": 3850
    },
    {
      "code": "4005",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale fixe 1er rang 1 an",
      "sortNr": 3850
    },
    {
      "code": "4005",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek fest 1 Jahr",
      "sortNr": 3850
    },
    {
      "code": "4006",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel",
      "sortNr": 8050
    },
    {
      "code": "4006",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt variable",
      "sortNr": 8050
    },
    {
      "code": "4006",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel",
      "sortNr": 8050
    },
    {
      "code": "4007",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Akkreditivlimite",
      "sortNr": 1750
    },
    {
      "code": "4007",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Limite accrÃ©ditif",
      "sortNr": 1750
    },
    {
      "code": "4007",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Akkreditivlimite",
      "sortNr": 1750
    },
    {
      "code": "4008",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4008",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4008",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4009",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4009",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4009",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4010",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4010",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4010",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4011",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4011",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4011",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4012",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Personalkredit unkurant",
      "sortNr": 1630
    },
    {
      "code": "4012",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit personnel, non courant",
      "sortNr": 1630
    },
    {
      "code": "4012",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Personalkredit unkurant",
      "sortNr": 1630
    },
    {
      "code": "4013",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4013",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4013",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4014",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Einsteiger-Hypothek",
      "sortNr": 8120
    },
    {
      "code": "4014",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que Promotion",
      "sortNr": 8120
    },
    {
      "code": "4014",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Einsteiger-Hypothek",
      "sortNr": 8120
    },
    {
      "code": "4015",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "4015",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que Flex 1er rang (Libor 3M) avec cap 3 ans V1",
      "sortNr": 3410
    },
    {
      "code": "4015",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Flexhypothek (Libor 3M) mit Cap 3 Jahre V1",
      "sortNr": 3410
    },
    {
      "code": "4016",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Terminkredit OERK",
      "sortNr": 1470
    },
    {
      "code": "4016",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit Ã  terme collectivitÃ© publique",
      "sortNr": 1470
    },
    {
      "code": "4016",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Terminkredit OERK",
      "sortNr": 1470
    },
    {
      "code": "4017",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel unkurant",
      "sortNr": 1930
    },
    {
      "code": "4017",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt variable non courant",
      "sortNr": 1930
    },
    {
      "code": "4017",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel unkurant",
      "sortNr": 1930
    },
    {
      "code": "4018",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit USD unkurant",
      "sortNr": 1230
    },
    {
      "code": "4018",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit USD non courant",
      "sortNr": 1230
    },
    {
      "code": "4018",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit USD unkurant",
      "sortNr": 1230
    },
    {
      "code": "4019",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF OERK",
      "sortNr": 1070
    },
    {
      "code": "4019",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit CHF CDDP",
      "sortNr": 1070
    },
    {
      "code": "4019",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF OERK",
      "sortNr": 1070
    },
    {
      "code": "4020",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4020",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4020",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4021",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Personalkredit blanko",
      "sortNr": 1650
    },
    {
      "code": "4021",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit personnel, en blanc",
      "sortNr": 1650
    },
    {
      "code": "4021",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Personalkredit blanko",
      "sortNr": 1650
    },
    {
      "code": "4022",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Festhypothek",
      "sortNr": 8080
    },
    {
      "code": "4022",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Hypo taux fixe",
      "sortNr": 8080
    },
    {
      "code": "4022",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Festhypothek",
      "sortNr": 8080
    },
    {
      "code": "4023",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4023",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4023",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4024",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "4024",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypoTenplus 1er rang 1 an",
      "sortNr": 4110
    },
    {
      "code": "4024",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. HypoTenplus 1 Jahr",
      "sortNr": 4110
    },
    {
      "code": "4025",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4025",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4025",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4026",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit EUR unkurant",
      "sortNr": 1130
    },
    {
      "code": "4026",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit EUR non courant",
      "sortNr": 1130
    },
    {
      "code": "4026",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit EUR unkurant",
      "sortNr": 1130
    },
    {
      "code": "4027",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4027",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4027",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4028",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel WEG",
      "sortNr": 4730
    },
    {
      "code": "4028",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang LCAP",
      "sortNr": 4730
    },
    {
      "code": "4028",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel WEG",
      "sortNr": 4730
    },
    {
      "code": "4029",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4029",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4029",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4030",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 8040
    },
    {
      "code": "4030",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 8040
    },
    {
      "code": "4030",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 8040
    },
    {
      "code": "4031",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4031",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4031",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4032",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4032",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4032",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4033",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Familienhypothek fest",
      "sortNr": 8100
    },
    {
      "code": "4033",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale fixe",
      "sortNr": 8100
    },
    {
      "code": "4033",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Familienhypothek fest",
      "sortNr": 8100
    },
    {
      "code": "4034",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4034",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4034",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4035",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4035",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4035",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4036",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4036",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4036",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4037",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4037",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4037",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4038",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Festdarlehen",
      "sortNr": 8060
    },
    {
      "code": "4038",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt fixe",
      "sortNr": 8060
    },
    {
      "code": "4038",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Festdarlehen",
      "sortNr": 8060
    },
    {
      "code": "4039",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4039",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4039",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4040",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel WEG",
      "sortNr": 4710
    },
    {
      "code": "4040",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang LCAP",
      "sortNr": 4710
    },
    {
      "code": "4040",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel WEG",
      "sortNr": 4710
    },
    {
      "code": "4041",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4041",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4041",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4042",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4042",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4042",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4043",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit EUR blanko",
      "sortNr": 1150
    },
    {
      "code": "4043",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit EUR en blanc",
      "sortNr": 1150
    },
    {
      "code": "4043",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit EUR blanko",
      "sortNr": 1150
    },
    {
      "code": "4044",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4044",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4044",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4045",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4045",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4045",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4046",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Lombardkredit",
      "sortNr": 8030
    },
    {
      "code": "4046",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit lombard",
      "sortNr": 8030
    },
    {
      "code": "4046",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Lombardkredit",
      "sortNr": 8030
    },
    {
      "code": "4047",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Festdarlehen kurant 1 Jahr",
      "sortNr": 2040
    },
    {
      "code": "4047",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt fixe courant 1 an",
      "sortNr": 2040
    },
    {
      "code": "4047",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Festdarlehen kurant 1 Jahr",
      "sortNr": 2040
    },
    {
      "code": "4048",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4048",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4048",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4049",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4049",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4049",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4050",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Personalkredit kurant",
      "sortNr": 1610
    },
    {
      "code": "4050",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit personnel, courant",
      "sortNr": 1610
    },
    {
      "code": "4050",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Personalkredit kurant",
      "sortNr": 1610
    },
    {
      "code": "4051",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4051",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4051",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4052",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit Ã¼brige FW kurant",
      "sortNr": 1350
    },
    {
      "code": "4052",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit Autres ME courant",
      "sortNr": 1350
    },
    {
      "code": "4052",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit Ã¼brige FW kurant",
      "sortNr": 1350
    },
    {
      "code": "4053",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit EUR kurant",
      "sortNr": 1110
    },
    {
      "code": "4053",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit EUR courant",
      "sortNr": 1110
    },
    {
      "code": "4053",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit EUR kurant",
      "sortNr": 1110
    },
    {
      "code": "4054",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4054",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4054",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4055",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Familienhypothek variabel",
      "sortNr": 8090
    },
    {
      "code": "4055",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable",
      "sortNr": 8090
    },
    {
      "code": "4055",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Familienhypothek variabel",
      "sortNr": 8090
    },
    {
      "code": "4056",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit USD kurant",
      "sortNr": 1210
    },
    {
      "code": "4056",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit USD courant",
      "sortNr": 1210
    },
    {
      "code": "4056",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit USD kurant",
      "sortNr": 1210
    },
    {
      "code": "4057",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4057",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4057",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4058",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Festdarlehen OERK 1 Jahr",
      "sortNr": 2690
    },
    {
      "code": "4058",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt fixe CDDP 1 an",
      "sortNr": 2690
    },
    {
      "code": "4058",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Festdarlehen OERK 1 Jahr",
      "sortNr": 2690
    },
    {
      "code": "4059",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4059",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4059",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4060",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF",
      "sortNr": 8010
    },
    {
      "code": "4060",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit CHF",
      "sortNr": 8010
    },
    {
      "code": "4060",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF",
      "sortNr": 8010
    },
    {
      "code": "4061",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4061",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4061",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4062",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "4062",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que fixe 1er rang 1 an",
      "sortNr": 3210
    },
    {
      "code": "4062",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Festhypothek 1 Jahr",
      "sortNr": 3210
    },
    {
      "code": "4063",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Terminkredit kurant",
      "sortNr": 1410
    },
    {
      "code": "4063",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit Ã  terme courant",
      "sortNr": 1410
    },
    {
      "code": "4063",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Terminkredit kurant",
      "sortNr": 1410
    },
    {
      "code": "4064",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF unkurant",
      "sortNr": 1030
    },
    {
      "code": "4064",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit CHF non courant",
      "sortNr": 1030
    },
    {
      "code": "4064",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF unkurant",
      "sortNr": 1030
    },
    {
      "code": "4065",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kaufpreisrestanz",
      "sortNr": 2800
    },
    {
      "code": "4065",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Prix d'achat rÃ©siduel",
      "sortNr": 2800
    },
    {
      "code": "4065",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kaufpreisrestanz",
      "sortNr": 2800
    },
    {
      "code": "4066",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4066",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4066",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4067",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4067",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4067",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4068",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel OERK",
      "sortNr": 1970
    },
    {
      "code": "4068",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt variable CDDP",
      "sortNr": 1970
    },
    {
      "code": "4068",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel OERK",
      "sortNr": 1970
    },
    {
      "code": "4069",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4069",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4069",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4070",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4070",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4070",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4071",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Hypothek variabel",
      "sortNr": 8070
    },
    {
      "code": "4071",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable",
      "sortNr": 8070
    },
    {
      "code": "4071",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Hypothek variabel",
      "sortNr": 8070
    },
    {
      "code": "4072",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4072",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4072",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4073",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4073",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4073",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4074",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF blanko",
      "sortNr": 1050
    },
    {
      "code": "4074",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant crÃ©dit CHF en blanc",
      "sortNr": 1050
    },
    {
      "code": "4074",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF blanko",
      "sortNr": 1050
    },
    {
      "code": "4075",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel",
      "sortNr": 8050
    },
    {
      "code": "4075",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt variable",
      "sortNr": 8050
    },
    {
      "code": "4075",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel",
      "sortNr": 8050
    },
    {
      "code": "4076",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4076",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4076",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4077",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kaufpreisgarantie",
      "sortNr": 3000
    },
    {
      "code": "4077",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Garantie du prix d'achat",
      "sortNr": 3000
    },
    {
      "code": "4077",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kaufpreisgarantie",
      "sortNr": 3000
    },
    {
      "code": "4078",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4078",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4078",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4079",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4079",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4079",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4080",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4080",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 2e rang",
      "sortNr": 3030
    },
    {
      "code": "4080",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Hypothek variabel",
      "sortNr": 3030
    },
    {
      "code": "4081",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Lombardkredit",
      "sortNr": 1500
    },
    {
      "code": "4081",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit lombard",
      "sortNr": 1500
    },
    {
      "code": "4081",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Lombardkredit",
      "sortNr": 1500
    },
    {
      "code": "4082",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus HypoTenplus",
      "sortNr": 8110
    },
    {
      "code": "4082",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypoTenplus",
      "sortNr": 8110
    },
    {
      "code": "4082",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus HypoTenplus",
      "sortNr": 8110
    },
    {
      "code": "4083",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4083",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4083",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4084",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit USD blanko",
      "sortNr": 1250
    },
    {
      "code": "4084",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant crÃ©dit USD en blanc",
      "sortNr": 1250
    },
    {
      "code": "4084",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit USD blanko",
      "sortNr": 1250
    },
    {
      "code": "4085",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4085",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 1er rang",
      "sortNr": 3710
    },
    {
      "code": "4085",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Familienhypothek variabel",
      "sortNr": 3710
    },
    {
      "code": "4086",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4420
    },
    {
      "code": "4086",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que Promotion 1er rang 1 an",
      "sortNr": 4420
    },
    {
      "code": "4086",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Einsteiger-Hypothek 1 Jahr",
      "sortNr": 4420
    },
    {
      "code": "4087",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4087",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4087",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4088",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4088",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4088",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4089",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4089",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que variable 1er rang",
      "sortNr": 3010
    },
    {
      "code": "4089",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Hypothek variabel",
      "sortNr": 3010
    },
    {
      "code": "4090",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4090",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4090",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4091",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 1. Festhypothek WEG 1 Jahr",
      "sortNr": 4850
    },
    {
      "code": "4091",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que fixe 1er rang LCAP 1 an",
      "sortNr": 4850
    },
    {
      "code": "4091",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 1. Festhypothek WEG 1 Jahr",
      "sortNr": 4850
    },
    {
      "code": "4092",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4092",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4092",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4093",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4093",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus HypothÃ¨que familiale variable 2e rang",
      "sortNr": 3730
    },
    {
      "code": "4093",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus 2. Familienhypothek variabel",
      "sortNr": 3730
    },
    {
      "code": "4094",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Terminkredit",
      "sortNr": 8020
    },
    {
      "code": "4094",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit Ã  terme",
      "sortNr": 8020
    },
    {
      "code": "4094",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Terminkredit",
      "sortNr": 8020
    },
    {
      "code": "4095",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4095",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus CrÃ©dit de construction",
      "sortNr": 1800
    },
    {
      "code": "4095",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Baukredit",
      "sortNr": 1800
    },
    {
      "code": "4096",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF kurant",
      "sortNr": 1010
    },
    {
      "code": "4096",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Compte courant CrÃ©dit CHF courant",
      "sortNr": 1010
    },
    {
      "code": "4096",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Kontokorrent Kredit CHF kurant",
      "sortNr": 1010
    },
    {
      "code": "4097",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 3M-LIBOR Mar/Jun/Sep/Dez mit Cap",
      "sortNr": 9999
    },
    {
      "code": "4097",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 3M-LIBOR Mar/Jun/Sep/Dez mit Cap",
      "sortNr": 9999
    },
    {
      "code": "4097",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 3M-LIBOR Mar/Jun/Sep/Dez mit Cap",
      "sortNr": 9999
    },
    {
      "code": "4098",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ausleihung zinslos 0%",
      "sortNr": 9999
    },
    {
      "code": "4098",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ausleihung zinslos 0%",
      "sortNr": 9999
    },
    {
      "code": "4098",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ausleihung zinslos 0%",
      "sortNr": 9999
    },
    {
      "code": "4099",
      "language": "de",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY kurant",
      "sortNr": 9999
    },
    {
      "code": "4099",
      "language": "fr",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY kurant",
      "sortNr": 9999
    },
    {
      "code": "4099",
      "language": "en",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY kurant",
      "sortNr": 9999
    },
    {
      "code": "4100",
      "language": "de",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY unkurant",
      "sortNr": 9999
    },
    {
      "code": "4100",
      "language": "fr",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY unkurant",
      "sortNr": 9999
    },
    {
      "code": "4100",
      "language": "en",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY unkurant",
      "sortNr": 9999
    },
    {
      "code": "4101",
      "language": "de",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY blanko",
      "sortNr": 9999
    },
    {
      "code": "4101",
      "language": "fr",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY blanko",
      "sortNr": 9999
    },
    {
      "code": "4101",
      "language": "en",
      "shortcut": "D",
      "description": "Kontokorrent Kredit JPY blanko",
      "sortNr": 9999
    },
    {
      "code": "4102",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 14%",
      "sortNr": 9999
    },
    {
      "code": "4102",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 14%",
      "sortNr": 9999
    },
    {
      "code": "4102",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 14%",
      "sortNr": 9999
    },
    {
      "code": "4103",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ausleihung spezial 0%",
      "sortNr": 9999
    },
    {
      "code": "4103",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ausleihung spezial 0%",
      "sortNr": 9999
    },
    {
      "code": "4103",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ausleihung spezial 0%",
      "sortNr": 9999
    },
    {
      "code": "4104",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 3M-LIBOR Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4104",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 3M-LIBOR Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4104",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 3M-LIBOR Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4105",
      "language": "de",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD unkurant",
      "sortNr": 9999
    },
    {
      "code": "4105",
      "language": "fr",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD unkurant",
      "sortNr": 9999
    },
    {
      "code": "4105",
      "language": "en",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD unkurant",
      "sortNr": 9999
    },
    {
      "code": "4106",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 12%",
      "sortNr": 9999
    },
    {
      "code": "4106",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 12%",
      "sortNr": 9999
    },
    {
      "code": "4106",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 12%",
      "sortNr": 9999
    },
    {
      "code": "4107",
      "language": "de",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD kurant",
      "sortNr": 9999
    },
    {
      "code": "4107",
      "language": "fr",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD kurant",
      "sortNr": 9999
    },
    {
      "code": "4107",
      "language": "en",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD kurant",
      "sortNr": 9999
    },
    {
      "code": "4108",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 6M-LIBOR Jun/Dez",
      "sortNr": 9999
    },
    {
      "code": "4108",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 6M-LIBOR Jun/Dez",
      "sortNr": 9999
    },
    {
      "code": "4108",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Flexhypothek 6M-LIBOR Jun/Dez",
      "sortNr": 9999
    },
    {
      "code": "4109",
      "language": "de",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD blanko",
      "sortNr": 9999
    },
    {
      "code": "4109",
      "language": "fr",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD blanko",
      "sortNr": 9999
    },
    {
      "code": "4109",
      "language": "en",
      "shortcut": "D",
      "description": "Kontokorrent Kredit AUD blanko",
      "sortNr": 9999
    },
    {
      "code": "4110",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 11%",
      "sortNr": 9999
    },
    {
      "code": "4110",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 11%",
      "sortNr": 9999
    },
    {
      "code": "4110",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 11%",
      "sortNr": 9999
    },
    {
      "code": "4111",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Devisenterminlimite",
      "sortNr": 1690
    },
    {
      "code": "4111",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Limite de devises Ã  terme",
      "sortNr": 1690
    },
    {
      "code": "4111",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Devisenterminlimite",
      "sortNr": 1690
    },
    {
      "code": "4112",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Kombihypothek 0%",
      "sortNr": 9999
    },
    {
      "code": "4112",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Kombihypothek 0%",
      "sortNr": 9999
    },
    {
      "code": "4112",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Kombihypothek 0%",
      "sortNr": 9999
    },
    {
      "code": "4113",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif UB federfÃ¼hrend 0%",
      "sortNr": 9999
    },
    {
      "code": "4113",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif UB federfÃ¼hrend 0%",
      "sortNr": 9999
    },
    {
      "code": "4113",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif UB federfÃ¼hrend 0%",
      "sortNr": 9999
    },
    {
      "code": "4114",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Privatkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4114",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Privatkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4114",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Privatkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4115",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel blanko",
      "sortNr": 1950
    },
    {
      "code": "4115",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus PrÃªt variable en blanc",
      "sortNr": 1950
    },
    {
      "code": "4115",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Darlehen variabel blanko",
      "sortNr": 1950
    },
    {
      "code": "4116",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Personalkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4116",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Personalkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4116",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Personalkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4117",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Standard ZISO Kondition",
      "sortNr": 9999
    },
    {
      "code": "4117",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Standard ZISO Kondition",
      "sortNr": 9999
    },
    {
      "code": "4117",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Standard ZISO Kondition",
      "sortNr": 9999
    },
    {
      "code": "4118",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Universalkonto Sollzins (Standard) ",
      "sortNr": 9999
    },
    {
      "code": "4118",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Universalkonto Sollzins (Standard) ",
      "sortNr": 9999
    },
    {
      "code": "4118",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Universalkonto Sollzins (Standard) ",
      "sortNr": 9999
    },
    {
      "code": "4119",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Privatkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4119",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Privatkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4119",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Privatkonto Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4120",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 6%",
      "sortNr": 9999
    },
    {
      "code": "4120",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 6%",
      "sortNr": 9999
    },
    {
      "code": "4120",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 6%",
      "sortNr": 9999
    },
    {
      "code": "4121",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Kontokorrent Kredit Ã¼FW 0% blanko (Dummy)",
      "sortNr": 9999
    },
    {
      "code": "4121",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Kontokorrent Kredit Ã¼FW 0% blanko (Dummy)",
      "sortNr": 9999
    },
    {
      "code": "4121",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Kontokorrent Kredit Ã¼FW 0% blanko (Dummy)",
      "sortNr": 9999
    },
    {
      "code": "4122",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy aus Toff-Margenlimite",
      "sortNr": 1691
    },
    {
      "code": "4122",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy aus Toff-Margenlimite",
      "sortNr": 1691
    },
    {
      "code": "4122",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy aus Toff-Margenlimite",
      "sortNr": 1691
    },
    {
      "code": "4123",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 11.5%",
      "sortNr": 9999
    },
    {
      "code": "4123",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 11.5%",
      "sortNr": 9999
    },
    {
      "code": "4123",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Ãberzugszinssatz 11.5%",
      "sortNr": 9999
    },
    {
      "code": "4124",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Jugend-Privatkonto (bis 14 J.) Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4124",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Jugend-Privatkonto (bis 14 J.) Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4124",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Jugend-Privatkonto (bis 14 J.) Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4125",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Konto Diverse Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4125",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Konto Diverse Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4125",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Konto Diverse Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4126",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Kautionen Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4126",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Kautionen Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4126",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Kautionen Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4127",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Banken Sicht Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4127",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Banken Sicht Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4127",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Banken Sicht Sollzins (Standard)",
      "sortNr": 9999
    },
    {
      "code": "4128",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Lombardkredit EUR",
      "sortNr": 9999
    },
    {
      "code": "4128",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Lombardkredit EUR",
      "sortNr": 9999
    },
    {
      "code": "4128",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Lombardkredit EUR",
      "sortNr": 9999
    },
    {
      "code": "4129",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR kurant",
      "sortNr": 9999
    },
    {
      "code": "4129",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR kurant",
      "sortNr": 9999
    },
    {
      "code": "4129",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR kurant",
      "sortNr": 9999
    },
    {
      "code": "4130",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR unkurant",
      "sortNr": 9999
    },
    {
      "code": "4130",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR unkurant",
      "sortNr": 9999
    },
    {
      "code": "4130",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR unkurant",
      "sortNr": 9999
    },
    {
      "code": "4131",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR blanko",
      "sortNr": 9999
    },
    {
      "code": "4131",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR blanko",
      "sortNr": 9999
    },
    {
      "code": "4131",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Personalkredit EUR blanko",
      "sortNr": 9999
    },
    {
      "code": "4132",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Terminkredit EUR 0%",
      "sortNr": 9999
    },
    {
      "code": "4132",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Terminkredit EUR 0%",
      "sortNr": 9999
    },
    {
      "code": "4132",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Terminkredit EUR 0%",
      "sortNr": 9999
    },
    {
      "code": "4133",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR kurant",
      "sortNr": 9999
    },
    {
      "code": "4133",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR kurant",
      "sortNr": 9999
    },
    {
      "code": "4133",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR kurant",
      "sortNr": 9999
    },
    {
      "code": "4134",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR unkurant",
      "sortNr": 9999
    },
    {
      "code": "4134",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR unkurant",
      "sortNr": 9999
    },
    {
      "code": "4134",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR unkurant",
      "sortNr": 9999
    },
    {
      "code": "4135",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR blanko",
      "sortNr": 9999
    },
    {
      "code": "4135",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR blanko",
      "sortNr": 9999
    },
    {
      "code": "4135",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Darlehen variabel EUR blanko",
      "sortNr": 9999
    },
    {
      "code": "4136",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Festdarlehen EUR 0%",
      "sortNr": 9999
    },
    {
      "code": "4136",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Festdarlehen EUR 0%",
      "sortNr": 9999
    },
    {
      "code": "4136",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif Festdarlehen EUR 0%",
      "sortNr": 9999
    },
    {
      "code": "4137",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 3M-LIBOR Mar/Jun/Sep/Dez (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4137",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 3M-LIBOR Mar/Jun/Sep/Dez (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4137",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 3M-LIBOR Mar/Jun/Sep/Dez (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4138",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 3M-LIBOR Mar/Jun/Sep/Dez mit Cap (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4138",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 3M-LIBOR Mar/Jun/Sep/Dez mit Cap (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4138",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 3M-LIBOR Mar/Jun/Sep/Dez mit Cap (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4139",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 6M-LIBOR Jun/Dez (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4139",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 6M-LIBOR Jun/Dez (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4139",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 6M-LIBOR Jun/Dez (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4140",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 6M-LIBOR Jun/Dez mit Cap (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4140",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 6M-LIBOR Jun/Dez mit Cap (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4140",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif 6M-LIBOR Jun/Dez mit Cap (Sondermod.5)",
      "sortNr": 9999
    },
    {
      "code": "4141",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Basis Festdarlehen) 0%",
      "sortNr": 9999
    },
    {
      "code": "4141",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Basis Festdarlehen) 0%",
      "sortNr": 9999
    },
    {
      "code": "4141",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Basis Festdarlehen) 0%",
      "sortNr": 9999
    },
    {
      "code": "4142",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) kurant",
      "sortNr": 9999
    },
    {
      "code": "4142",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) kurant",
      "sortNr": 9999
    },
    {
      "code": "4142",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) kurant",
      "sortNr": 9999
    },
    {
      "code": "4143",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) unkurant",
      "sortNr": 9999
    },
    {
      "code": "4143",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) unkurant",
      "sortNr": 9999
    },
    {
      "code": "4143",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) unkurant",
      "sortNr": 9999
    },
    {
      "code": "4144",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) blanko",
      "sortNr": 9999
    },
    {
      "code": "4144",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) blanko",
      "sortNr": 9999
    },
    {
      "code": "4144",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fÃ¼r Basistarif (Sondermodell 6, Darlehen variabel) blanko",
      "sortNr": 9999
    },
    {
      "code": "4146",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif Kontokorrent Kredit Ã¼FW 0% unkurant (Dummy)",
      "sortNr": 9999
    },
    {
      "code": "4146",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif Kontokorrent Kredit Ã¼FW 0% unkurant (Dummy)",
      "sortNr": 9999
    },
    {
      "code": "4146",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif Kontokorrent Kredit Ã¼FW 0% unkurant (Dummy)",
      "sortNr": 9999
    },
    {
      "code": "4147",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif 3M-LIBOR Postfinance Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4147",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif 3M-LIBOR Postfinance Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4147",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif 3M-LIBOR Postfinance Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4148",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif 3M-LIBOR Postfinance Mar/Jun/Sep/Dez mit Cap",
      "sortNr": 9999
    },
    {
      "code": "4148",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif 3M-LIBOR Postfinance Mar/Jun/Sep/Dez mit Cap",
      "sortNr": 9999
    },
    {
      "code": "4148",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif 3M-LIBOR Postfinance Mar/Jun/Sep/Dez mit Cap",
      "sortNr": 9999
    },
    {
      "code": "4149",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif Ãberzugszinssatz 0%",
      "sortNr": 9999
    },
    {
      "code": "4149",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif Ãberzugszinssatz 0%",
      "sortNr": 9999
    },
    {
      "code": "4149",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fuer Basistarif Ãberzugszinssatz 0%",
      "sortNr": 9999
    },
    {
      "code": "4150",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fuer Flexhypothek 3M Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4150",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fuer Flexhypothek 3M Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4150",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fuer Flexhypothek 3M Mar/Jun/Sep/Dez",
      "sortNr": 9999
    },
    {
      "code": "4151",
      "language": "de",
      "shortcut": "D",
      "description": "Dummy fuer Hypothek variabel 1. Wohnen / Luxus",
      "sortNr": 9999
    },
    {
      "code": "4151",
      "language": "fr",
      "shortcut": "D",
      "description": "Dummy fuer Hypothek variabel 1. Wohnen / Luxus",
      "sortNr": 9999
    },
    {
      "code": "4151",
      "language": "en",
      "shortcut": "D",
      "description": "Dummy fuer Hypothek variabel 1. Wohnen / Luxus",
      "sortNr": 9999
    }
  ]
