var src = src || {}
  src.periodUnits = [ {
    "code" : "1",
    "language" : "de",
    "shortcut" : "tägli",
    "description" : "täglich",
    "sortNr" : 1
  }, {
    "code" : "1",
    "language" : "fr",
    "shortcut" : "journ",
    "description" : "journalière",
    "sortNr" : 1
  }, {
    "code" : "1",
    "language" : "en",
    "shortcut" : "daily",
    "description" : "daily",
    "sortNr" : 1
  }, {
    "code" : "2",
    "language" : "de",
    "shortcut" : "wöche",
    "description" : "wöchentlich",
    "sortNr" : 2
  }, {
    "code" : "2",
    "language" : "fr",
    "shortcut" : "hebdo",
    "description" : "hebdomadaire",
    "sortNr" : 2
  }, {
    "code" : "2",
    "language" : "en",
    "shortcut" : "week",
    "description" : "weekly",
    "sortNr" : 2
  }, {
    "code" : "3",
    "language" : "de",
    "shortcut" : "monat",
    "description" : "monatlich",
    "sortNr" : 3
  }, {
    "code" : "3",
    "language" : "fr",
    "shortcut" : "mensu",
    "description" : "mensuelle",
    "sortNr" : 3
  }, {
    "code" : "3",
    "language" : "en",
    "shortcut" : "month",
    "description" : "monthly",
    "sortNr" : 3
  }, {
    "code" : "4",
    "language" : "de",
    "shortcut" : "jährl",
    "description" : "jährlich",
    "sortNr" : 6
  }, {
    "code" : "4",
    "language" : "fr",
    "shortcut" : "annue",
    "description" : "annuelle",
    "sortNr" : 6
  }, {
    "code" : "4",
    "language" : "en",
    "shortcut" : "annua",
    "description" : "annual",
    "sortNr" : 6
  }, {
    "code" : "5",
    "language" : "de",
    "shortcut" : "URM",
    "description" : "unregelmässig",
    "sortNr" : 7
  }, {
    "code" : "5",
    "language" : "fr",
    "shortcut" : "IRRE",
    "description" : "irrégulier",
    "sortNr" : 7
  }, {
    "code" : "5",
    "language" : "en",
    "shortcut" : "IRRE",
    "description" : "irregularly",
    "sortNr" : 7
  }, {
    "code" : "6",
    "language" : "de",
    "shortcut" : "viert",
    "description" : "vierteljährlich",
    "sortNr" : 4
  }, {
    "code" : "6",
    "language" : "fr",
    "shortcut" : "trime",
    "description" : "trimestrielle",
    "sortNr" : 4
  }, {
    "code" : "6",
    "language" : "en",
    "shortcut" : "quart",
    "description" : "quarterly",
    "sortNr" : 4
  }, {
    "code" : "7",
    "language" : "de",
    "shortcut" : "halbj",
    "description" : "halbjährlich",
    "sortNr" : 5
  }, {
    "code" : "7",
    "language" : "fr",
    "shortcut" : "semes",
    "description" : "semestrielle",
    "sortNr" : 5
  }, {
    "code" : "7",
    "language" : "en",
    "shortcut" : "semiA",
    "description" : "semi-annually",
    "sortNr" : 5
  } ]
