var src = src || {}
src.orderCollateral = [
  {
    "orderKey": "54530902270136",
    "itemKey": "54540111548069",
    "securityKey": "40913549568564",
    "propertyKey": "40913296211527",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 1000000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "4.26 - 39.72",
    "totalLending": {
      "amount": 67.23,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 2256000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 1000000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "54530902270136",
    "itemKey": "54540111548069",
    "securityKey": "40913549568565",
    "propertyKey": "40913296211527",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 280000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "39.72 - 49.65",
    "totalLending": {
      "amount": 67.23,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 2256000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 280000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "54530902270136",
    "itemKey": "54540111548069",
    "securityKey": "40913549568566",
    "propertyKey": "40913296211527",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "49.65 - 53.19",
    "totalLending": {
      "amount": 67.23,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 2256000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "54530902270136",
    "itemKey": "54540111548069",
    "securityKey": "40913549568567",
    "propertyKey": "40913296211527",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "53.19 - 56.74",
    "totalLending": {
      "amount": 67.23,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 2256000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "54530902270136",
    "itemKey": "54540111548069",
    "securityKey": "40913549568568",
    "propertyKey": "40913296211527",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "56.74 - 60.28",
    "totalLending": {
      "amount": 67.23,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 2256000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "54530902270136",
    "itemKey": "54540111548069",
    "securityKey": "40913549568569",
    "propertyKey": "40913296211527",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "60.28 - 63.83",
    "totalLending": {
      "amount": 67.23,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 2256000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "54530902270136",
    "itemKey": "54540111548069",
    "securityKey": "40913549568643",
    "propertyKey": "40913296211527",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 96000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "63.83 - 67.23",
    "totalLending": {
      "amount": 67.23,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 2256000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 96000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 4000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "54530902270136",
    "itemKey": "54540111548069",
    "securityKey": "40913551429310",
    "propertyKey": "40913296211527",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 120000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "0.00 - 4.26",
    "totalLending": {
      "amount": 67.23,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 2256000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 120000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "62964341203191",
    "itemKey": "62971461171013",
    "securityKey": "40913548534551",
    "propertyKey": "40913296212852",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 40000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "0.00 - 17.32",
    "totalLending": {
      "amount": 60.61,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 173250,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 40000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 1
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "62964341203191",
    "itemKey": "62971461171013",
    "securityKey": "40913548534553",
    "propertyKey": "40913296212852",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "17.32 - 60.61",
    "totalLending": {
      "amount": 60.61,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 173250,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 100000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 1
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59560732583955",
    "itemKey": "59569625732456",
    "securityKey": "40913548740726",
    "propertyKey": "40913282011500",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 210000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "0.00 - 57.91",
    "totalLending": {
      "amount": 57.91,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 566400,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 410000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 1
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59560732583955",
    "itemKey": "59569625732458",
    "securityKey": "40913548740726",
    "propertyKey": "40913282011500",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 200000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "29.66 - 87.57",
    "totalLending": {
      "amount": 57.91,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 566400,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 410000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 1
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "40913548430076",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 50000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "12.54 - 18.19",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 50000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "40913548430077",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 189000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "18.19 - 40.79",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 200000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "40913551222766",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 8000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "0.00 - 0.9",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 8000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "40913551222767",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 13000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "0.9 - 2.37",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 13000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "40913551222768",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 40000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "2.37 - 6.89",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 40000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "40913551222858",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 10000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "6.89 - 8.02",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 10000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "40913551222861",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 20000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "8.02 - 10.28",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 20000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "40913551222863",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 20000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "10.28 - 12.54",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 20000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799952",
    "securityKey": "43309914554979",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 257750,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 89250,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "40913548430076",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 50000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "40913548430077",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 11000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "39.55 - 62.15",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 200000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "40913551222766",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 8000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "40913551222767",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 13000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "40913551222768",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 40000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "40913551222858",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 10000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "40913551222861",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 20000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "40913551222863",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 20000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "59093316108491",
    "itemKey": "59145084799954",
    "securityKey": "43309914554979",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 257750,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "40.79 - 69.92",
    "totalLending": {
      "amount": 69.92,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 708000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 257750,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 89250,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 3
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "63915860156330",
    "itemKey": "63923974505035",
    "securityKey": "40913553869606",
    "propertyKey": null,
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 150000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 74.59,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 180994.37,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 150000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 30994.37,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 5,
    "numberLiabilities": 1,
    "CollateralTypes:type": {
      "href": 1400
    },
    "CollateralSubtypes:subType": {
      "href": 1403
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "52665579170713",
    "itemKey": "52675498960509",
    "securityKey": "40913550392568",
    "propertyKey": "40913297033235",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 229000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "31.46 - 103.09",
    "totalLending": {
      "amount": 71.63,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 456000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 458000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 2
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "52665579170713",
    "itemKey": "52675498960509",
    "securityKey": "40913553558430",
    "propertyKey": null,
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": "2020-12-01",
    "collateralValue": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1400
    },
    "CollateralSubtypes:subType": {
      "href": 1401
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "52665579170713",
    "itemKey": "52675498960509",
    "securityKey": "40913553558652",
    "propertyKey": null,
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": "40909244808718",
    "accountCustodyAccountNumber": "42 8.266.788.08",
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 96.09,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 51720.75,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 49697.6,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 2023.15,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1100
    },
    "CollateralSubtypes:subType": {
      "href": 1105
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "52665579170713",
    "itemKey": "52675498960519",
    "securityKey": "40913550392568",
    "propertyKey": "40913297033235",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 179302.4,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "0.00 - 71.63",
    "totalLending": {
      "amount": 71.63,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 456000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 458000,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1000
    },
    "CollateralSubtypes:subType": {
      "href": 2
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "52665579170713",
    "itemKey": "52675498960519",
    "securityKey": "40913553558430",
    "propertyKey": "40913322583453",
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": null,
    "accountCustodyAccountNumber": null,
    "collateralLimit": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": "2020-12-01",
    "collateralValue": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 0,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1400
    },
    "CollateralSubtypes:subType": {
      "href": 1401
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "orderKey": "52665579170713",
    "itemKey": "52675498960519",
    "securityKey": "40913553558652",
    "propertyKey": null,
    "portfolioKey": null,
    "portfolioNumber": null,
    "accountCustodyAccountKey": "40909244808718",
    "accountCustodyAccountNumber": "42 8.266.788.08",
    "collateralLimit": {
      "amount": 49697.6,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "lendingFromTo": "---",
    "totalLending": {
      "amount": 96.09,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "expiry": null,
    "collateralValue": {
      "amount": 51720.75,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "claimedLending": {
      "amount": 49697.6,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "availableLending": {
      "amount": 2023.15,
      "currency:currency": {
        "href": "CHF"
      },
      "_links": {
        "curies": [
          {
            "name": "currency",
            "href": "/v2/banks/6300/codes/Currencies/{rel}",
            "templated": true
          }
        ]
      }
    },
    "collateralOrderSecurities": 0,
    "orderWithinCollateral": 1,
    "numberLiabilities": 2,
    "CollateralTypes:type": {
      "href": 1100
    },
    "CollateralSubtypes:subType": {
      "href": 1105
    },
    "_links": {
      "curies": [
        {
          "name": "CollateralTypes",
          "href": "/v2/banks/6300/codes/CollateralTypes/{rel}",
          "templated": true
        },
        {
          "name": "CollateralSubtypes",
          "href": "/v2/banks/6300/codes/CollateralSubtypes/{rel}",
          "templated": true
        }
      ]
    }
  }
]
