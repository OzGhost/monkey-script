var src = src || {}
src.clientStatuses = [
    {
      "code": "0",
      "language": "de",
      "shortcut": "Aktiv",
      "description": "Aktiv",
      "sortNr": 10
    },
    {
      "code": "0",
      "language": "fr",
      "shortcut": "Actif",
      "description": "Actif",
      "sortNr": 10
    },
    {
      "code": "0",
      "language": "en",
      "shortcut": "Activ",
      "description": "Active",
      "sortNr": 10
    },
    {
      "code": "1",
      "language": "de",
      "shortcut": "Inakt",
      "description": "Inaktiv",
      "sortNr": 20
    },
    {
      "code": "1",
      "language": "fr",
      "shortcut": "Inact",
      "description": "Inactif",
      "sortNr": 20
    },
    {
      "code": "1",
      "language": "en",
      "shortcut": "Inact",
      "description": "Inactive",
      "sortNr": 20
    },
    {
      "code": "200",
      "language": "de",
      "shortcut": "NNK",
      "description": "Noch nicht Kunde",
      "sortNr": 9999
    },
    {
      "code": "200",
      "language": "fr",
      "shortcut": "NNK",
      "description": "Pas encore client",
      "sortNr": 9999
    },
    {
      "code": "200",
      "language": "en",
      "shortcut": "Offer",
      "description": "Request for offer",
      "sortNr": 9999
    },
    {
      "code": "910",
      "language": "de",
      "shortcut": "Unerw",
      "description": "Unerwuenschter Kunde",
      "sortNr": 70
    },
    {
      "code": "910",
      "language": "fr",
      "shortcut": "ACi",
      "description": "Client indesirable",
      "sortNr": 70
    },
    {
      "code": "910",
      "language": "en",
      "shortcut": "OiC",
      "description": "Other inactive client",
      "sortNr": 70
    },
    {
      "code": "950",
      "language": "de",
      "shortcut": "Oe",
      "description": "Organisationseinheit",
      "sortNr": 80
    },
    {
      "code": "950",
      "language": "fr",
      "shortcut": "UO",
      "description": "Unite d'organisation",
      "sortNr": 80
    },
    {
      "code": "950",
      "language": "en",
      "shortcut": "Ou",
      "description": "Unit of organisation",
      "sortNr": 80
    }
  ]

