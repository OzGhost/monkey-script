var src = src || {}
src.orders = [
	{
		"clientKey": "40907937079144",
		"orders": [
			{
				"key": "54530902270136",
				"id": "13986226/001/0004",
				"clientKey": "40907937079144",
				"creditLineDesignation": null,
				"use": "2015-04-13",
				"overallLimit": {
					"amount": 1896000,
					"currency:currency": {
						"href": "CHF"
					},
					"_links": {
						"curies": [
							{
								"name": "currency",
								"href": "/v2/banks/6300/codes/Currencies/{rel}",
								"templated": true
							}
						]
					}
				},
				"resubmission": "2030-02-01",
				"BusinessCases:businessCase": {
					"href": 941
				},
				"LoanRequestReason:reasonForApplication": {
					"href": 1040
				},
				"_links": {
					"curies": [
						{
							"name": "loanRequestReason",
							"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
							"templated": true
						},
						{
							"name": "businessCase",
							"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
							"templated": true
						}
					]
				}
			},
			{
				"key": "62057340725463",
				"id": "13986226/002/0007",
				"clientKey": "40907937079144",
				"creditLineDesignation": null,
				"use": "2017-08-31",
				"overallLimit": {
					"amount": 2000000,
					"currency:currency": {
						"href": "CHF"
					},
					"_links": {
						"curies": [
							{
								"name": "currency",
								"href": "/v2/banks/6300/codes/Currencies/{rel}",
								"templated": true
							}
						]
					}
				},
				"resubmission": "2030-02-01",
				"BusinessCases:businessCase": {
					"href": 910
				},
				"LoanRequestReason:reasonForApplication": {
					"href": 1001
				},
				"_links": {
					"curies": [
						{
							"name": "loanRequestReason",
							"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
							"templated": true
						}
					]
				}
			}
		]
	},
	{
		"clientKey": "16066502",
		"orders": "This use should produces server error"
	},
	{
		"clientKey": "40907908177191",
		"orders": [
			{
				"key": "62964341203191",
				"id": "14012023/001/0004",
				"clientKey": "40907908177191",
				"creditLineDesignation": null,
				"use": "2017-12-14",
				"overallLimit": {
					"amount": 140000,
					"currency:currency": {
						"href": "CHF"
					},
					"_links": {
						"curies": [
							{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
							}
						]
					}
				},
				"resubmission": "2299-12-31",
				"BusinessCases:businessCase": {
					"href": 941
				},
				"LoanRequestReason:reasonForApplication": {
					"href": 1040
				},
				"_links": {
					"curies": [
						{
							"name": "loanRequestReason",
							"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
							"templated": true
						},
						{
							"name": "businessCase",
							"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
							"templated": true
						}
					]
				}
			}
		]
	},
	{
		"clientKey": "40907883083914",
		"orders": [
			{
				"key": "59560732583955",
				"id": "13157779/001/0005",
				"clientKey": "40907883083914",
				"creditLineDesignation": null,
				"use": "2016-11-15",
				"overallLimit": {
					"amount": 410000,
					"currency:currency": {
						"href": "CHF"
					},
					"_links": {
						"curies": [
							{
								"name": "currency",
								"href": "/v2/banks/6300/codes/Currencies/{rel}",
								"templated": true
							}
						]
					}
				},
				"resubmission": "2299-12-31",
				"BusinessCases:businessCase": {
					"href": 965
				},
				"LoanRequestReason:reasonForApplication": {
					"href": 1140
				},
				"_links": {
					"curies": [
						{
							"name": "loanRequestReason",
							"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
							"templated": true
						},
						{
							"name": "businessCase",
							"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
							"templated": true
						}
					]
				}
			},
			{
				"key": "59460742583945",
				"id": "13157779/002/0007",
				"clientKey": "40907883083914",
				"creditLineDesignation": null,
				"use": "2017-08-31",
				"overallLimit": {
					"amount": 2000000,
					"currency:currency": {
					"href": "CHF"
					},
					"_links": {
						"curies": [
							{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
							}
						]
					}
				},  
				"resubmission": "2030-02-01",
				"BusinessCases:businessCase": {
					"href": 910
				},
				"LoanRequestReason:reasonForApplication": {
					"href": 1001
				},
				"_links": {
					"curies": [
						{
							"name": "loanRequestReason",
							"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
							"templated": true
						}
					]
				}
			}
		]
	},
	{
		"clientKey": "40907944905943",
		"orders": [
			{
				"key": "59093316108491",
				"id": "13156728/001/0006",
				"clientKey": "40907944905943",
				"creditLineDesignation": null,
				"use": "2016-09-22",
				"overallLimit": {
					"amount": 620000,
					"currency:currency": {
						"href": "CHF"
					},
					"_links": {
						"curies": [
							{
								"name": "currency",
								"href": "/v2/banks/6300/codes/Currencies/{rel}",
								"templated": true
							}
						]
					}
				},
				"resubmission": "2026-10-31",
				"BusinessCases:businessCase": {
					"href": 941
				},
				"LoanRequestReason:reasonForApplication": {
					"href": 1040
				},
				"_links": {
					"curies": [
						{
							"name": "loanRequestReason",
							"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
							"templated": true
						},
						{
							"name": "businessCase",
							"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
							"templated": true
						}
					]
				}
			}
		]
	},
	{
		"clientKey": "40907948419302",
		"orders": [
			{
				"key": "63915860156330",
				"id": "13152782/001/0024",
				"clientKey": "40907948419302",
				"creditLineDesignation": null,
				"use": "2018-04-03",
				"overallLimit": {
					"amount": 150000,
					"currency:currency": {
						"href": "CHF"
					},
					"_links": {
						"curies": [
							{
								"name": "currency",
								"href": "/v2/banks/6300/codes/Currencies/{rel}",
								"templated": true
							}
						]
					}
				},
				"resubmission": "2018-09-30",
				"BusinessCases:businessCase": {
					"href": 920
				},
				"LoanRequestReason:reasonForApplication": {
					"href": 1080
				},
				"_links": {
					"curies": [
						{
							"name": "loanRequestReason",
							"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
							"templated": true
						},
						{
							"name": "businessCase",
							"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
							"templated": true
						}
					]
				}
			}
		]
	},
	{
		"clientKey": "40907915403472",
		"orders": [
			{
				"key": "52665579170713",
				"id": "13183671/001/0003",
				"clientKey": "40907915403472",
				"creditLineDesignation": null,
				"use": "2014-09-09",
				"overallLimit": {
					"amount": 458000,
					"currency:currency": {
						"href": "CHF"
					},
					"_links": {
						"curies": [
							{
								"name": "currency",
								"href": "/v2/banks/6300/codes/Currencies/{rel}",
								"templated": true
							}
						]
					}
				},
				"resubmission": "2299-12-31",
				"BusinessCases:businessCase": {
					"href": 941
				},
				"LoanRequestReason:reasonForApplication": {
					"href": 1040
				},
				"_links": {
					"curies": [
						{
							"name": "loanRequestReason",
							"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
							"templated": true
						},
						{
							"name": "businessCase",
							"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
							"templated": true
						}
					]
				}
			}
		]
	}
]
