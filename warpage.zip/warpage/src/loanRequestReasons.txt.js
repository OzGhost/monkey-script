var src = src || {}
  src.loanRequestReasons = [ {
    "code" : "1000",
    "language" : "de",
    "shortcut" : "Immob",
    "description" : "Immobilienkauf",
    "sortNr" : 9999
  }, {
    "code" : "1000",
    "language" : "fr",
    "shortcut" : "Immob",
    "description" : "Achat immobilier",
    "sortNr" : 9999
  }, {
    "code" : "1000",
    "language" : "en",
    "shortcut" : "Immob",
    "description" : "Immobilienkauf",
    "sortNr" : 9999
  }, {
    "code" : "1001",
    "language" : "de",
    "shortcut" : "Immob",
    "description" : "Immobilienbau / -umbau",
    "sortNr" : 9999
  }, {
    "code" : "1001",
    "language" : "fr",
    "shortcut" : "Immob",
    "description" : "Construction/transformation d'immeubles",
    "sortNr" : 9999
  }, {
    "code" : "1001",
    "language" : "en",
    "shortcut" : "Immob",
    "description" : "Immobilienbau / -umbau",
    "sortNr" : 9999
  }, {
    "code" : "1002",
    "language" : "de",
    "shortcut" : "Immob",
    "description" : "Immobilienneubau",
    "sortNr" : 9999
  }, {
    "code" : "1002",
    "language" : "fr",
    "shortcut" : "Immob",
    "description" : "Construction d'immeubles",
    "sortNr" : 9999
  }, {
    "code" : "1002",
    "language" : "en",
    "shortcut" : "Immob",
    "description" : "Immobilienneubau",
    "sortNr" : 9999
  }, {
    "code" : "1003",
    "language" : "de",
    "shortcut" : "Immob",
    "description" : "Immobilienumbau",
    "sortNr" : 9999
  }, {
    "code" : "1003",
    "language" : "fr",
    "shortcut" : "Immob",
    "description" : "Transformation d'immeubles",
    "sortNr" : 9999
  }, {
    "code" : "1003",
    "language" : "en",
    "shortcut" : "Immob",
    "description" : "Immobilienumbau",
    "sortNr" : 9999
  }, {
    "code" : "1010",
    "language" : "de",
    "shortcut" : "Betri",
    "description" : "Betriebsmittelfinanzierung",
    "sortNr" : 9999
  }, {
    "code" : "1010",
    "language" : "fr",
    "shortcut" : "Betri",
    "description" : "Financement du fonds de roulement",
    "sortNr" : 9999
  }, {
    "code" : "1010",
    "language" : "en",
    "shortcut" : "Betri",
    "description" : "Betriebsmittelfinanzierung",
    "sortNr" : 9999
  }, {
    "code" : "1020",
    "language" : "de",
    "shortcut" : "üFina",
    "description" : "übrige Finanzierung",
    "sortNr" : 9999
  }, {
    "code" : "1020",
    "language" : "fr",
    "shortcut" : "Finre",
    "description" : "Financements restant",
    "sortNr" : 9999
  }, {
    "code" : "1020",
    "language" : "en",
    "shortcut" : "üFina",
    "description" : "übrige Finanzierung",
    "sortNr" : 9999
  }, {
    "code" : "1030",
    "language" : "de",
    "shortcut" : "Inves",
    "description" : "Investitionsgüterfinanzierung",
    "sortNr" : 9999
  }, {
    "code" : "1030",
    "language" : "fr",
    "shortcut" : "Inves",
    "description" : "Financement des biens d'équipement",
    "sortNr" : 9999
  }, {
    "code" : "1030",
    "language" : "en",
    "shortcut" : "Inves",
    "description" : "Investitionsgüterfinanzierung",
    "sortNr" : 9999
  }, {
    "code" : "1035",
    "language" : "de",
    "shortcut" : "WSFin",
    "description" : "Wertschriftenfinanzierung",
    "sortNr" : 9999
  }, {
    "code" : "1035",
    "language" : "fr",
    "shortcut" : "WSFin",
    "description" : "Financement de titres",
    "sortNr" : 9999
  }, {
    "code" : "1035",
    "language" : "en",
    "shortcut" : "WSFin",
    "description" : "Wertschriftenfinanzierung",
    "sortNr" : 9999
  }, {
    "code" : "1040",
    "language" : "de",
    "shortcut" : "Aende",
    "description" : "Aenderung an bestehendem Kreditvertrag",
    "sortNr" : 9999
  }, {
    "code" : "1040",
    "language" : "fr",
    "shortcut" : "Aende",
    "description" : "Modification du contrat de crédit existant",
    "sortNr" : 9999
  }, {
    "code" : "1040",
    "language" : "en",
    "shortcut" : "Aende",
    "description" : "Aenderung an bestehendem Kreditvertrag",
    "sortNr" : 9999
  }, {
    "code" : "1041",
    "language" : "de",
    "shortcut" : "AblbI",
    "description" : "Ablösung bei anderem Institut mit Hypothekarerhöhung",
    "sortNr" : 9999
  }, {
    "code" : "1041",
    "language" : "fr",
    "shortcut" : "AblbI",
    "description" : "Rachat auprès d'un autre établissement avec augmentation",
    "sortNr" : 9999
  }, {
    "code" : "1041",
    "language" : "en",
    "shortcut" : "AblbI",
    "description" : "Ablösung bei anderem Institut mit Hypothekarerhöhung",
    "sortNr" : 9999
  }, {
    "code" : "1042",
    "language" : "de",
    "shortcut" : "AbldI",
    "description" : "Ablösung durch anderes Institut",
    "sortNr" : 9999
  }, {
    "code" : "1042",
    "language" : "fr",
    "shortcut" : "AbldI",
    "description" : "Rachat par un autre établissement",
    "sortNr" : 9999
  }, {
    "code" : "1042",
    "language" : "en",
    "shortcut" : "AbldI",
    "description" : "Ablösung durch anderes Institut",
    "sortNr" : 9999
  }, {
    "code" : "1043",
    "language" : "de",
    "shortcut" : "Krisk",
    "description" : "Konsolidierung mit Erhöhung/Anpassung Basiswert",
    "sortNr" : 9999
  }, {
    "code" : "1043",
    "language" : "fr",
    "shortcut" : "Krisk",
    "description" : "Consolidation avec augmentation/adaptation de la valeur de base",
    "sortNr" : 9999
  }, {
    "code" : "1043",
    "language" : "en",
    "shortcut" : "Krisk",
    "description" : "Konsolidierung mit Erhöhung/Anpassung Basiswert",
    "sortNr" : 9999
  }, {
    "code" : "1044",
    "language" : "de",
    "shortcut" : "Kneut",
    "description" : "Konsolidierung ohne Erhöhung u.o. Anpassung Basiswert",
    "sortNr" : 9999
  }, {
    "code" : "1044",
    "language" : "fr",
    "shortcut" : "Kneut",
    "description" : "Consolidation sans augmentation/adaptation de la valeur de base",
    "sortNr" : 9999
  }, {
    "code" : "1044",
    "language" : "en",
    "shortcut" : "Kneut",
    "description" : "Konsolidierung ohne Erhöhung u.o. Anpassung Basiswert",
    "sortNr" : 9999
  }, {
    "code" : "1045",
    "language" : "de",
    "shortcut" : "AblbI",
    "description" : "Ablösung bei anderem Institut ohne Hypothekarerhöhung",
    "sortNr" : 9999
  }, {
    "code" : "1045",
    "language" : "fr",
    "shortcut" : "AblbI",
    "description" : "Rachat auprès d'un autre établissement sans augmentation",
    "sortNr" : 9999
  }, {
    "code" : "1045",
    "language" : "en",
    "shortcut" : "AblbI",
    "description" : "Ablösung bei anderem Institut ohne Hypothekarerhöhung",
    "sortNr" : 9999
  }, {
    "code" : "1060",
    "language" : "de",
    "shortcut" : "EvEng",
    "description" : "Eventualengagement (Kaution)",
    "sortNr" : 9999
  }, {
    "code" : "1060",
    "language" : "fr",
    "shortcut" : "EvEng",
    "description" : "Engagement conditionnel (caution)",
    "sortNr" : 9999
  }, {
    "code" : "1060",
    "language" : "en",
    "shortcut" : "EvEng",
    "description" : "Eventualengagement (Kaution)",
    "sortNr" : 9999
  }, {
    "code" : "1070",
    "language" : "de",
    "shortcut" : "WDeck",
    "description" : "Wegfall Deckung",
    "sortNr" : 9999
  }, {
    "code" : "1070",
    "language" : "fr",
    "shortcut" : "WDeck",
    "description" : "Suppression de couverture",
    "sortNr" : 9999
  }, {
    "code" : "1070",
    "language" : "en",
    "shortcut" : "WDeck",
    "description" : "Wegfall Deckung",
    "sortNr" : 9999
  }, {
    "code" : "1071",
    "language" : "de",
    "shortcut" : "WBeda",
    "description" : "Wegfall Bedarf",
    "sortNr" : 9999
  }, {
    "code" : "1071",
    "language" : "fr",
    "shortcut" : "WBeda",
    "description" : "Suppression du besoin",
    "sortNr" : 9999
  }, {
    "code" : "1071",
    "language" : "en",
    "shortcut" : "WBeda",
    "description" : "Wegfall Bedarf",
    "sortNr" : 9999
  }, {
    "code" : "1080",
    "language" : "de",
    "shortcut" : "ABefr",
    "description" : "Ablauf Befristung",
    "sortNr" : 9999
  }, {
    "code" : "1080",
    "language" : "fr",
    "shortcut" : "ABefr",
    "description" : "Expiration du délai",
    "sortNr" : 9999
  }, {
    "code" : "1080",
    "language" : "en",
    "shortcut" : "ABefr",
    "description" : "Ablauf Befristung",
    "sortNr" : 9999
  }, {
    "code" : "1090",
    "language" : "de",
    "shortcut" : "VzNeu",
    "description" : "Vorzeitige Neuordnung",
    "sortNr" : 9999
  }, {
    "code" : "1090",
    "language" : "fr",
    "shortcut" : "VzNeu",
    "description" : "Réorganisation anticipée",
    "sortNr" : 9999
  }, {
    "code" : "1090",
    "language" : "en",
    "shortcut" : "VzNeu",
    "description" : "Vorzeitige Neuordnung",
    "sortNr" : 9999
  }, {
    "code" : "1100",
    "language" : "de",
    "shortcut" : "VPriv",
    "description" : "Verlängerung (Privat)",
    "sortNr" : 9999
  }, {
    "code" : "1100",
    "language" : "fr",
    "shortcut" : "VPriv",
    "description" : "Prolongation (privé)",
    "sortNr" : 9999
  }, {
    "code" : "1100",
    "language" : "en",
    "shortcut" : "VPriv",
    "description" : "Verlängerung (Privat)",
    "sortNr" : 9999
  }, {
    "code" : "1101",
    "language" : "de",
    "shortcut" : "VKomm",
    "description" : "Verlängerung (Kommerz)",
    "sortNr" : 9999
  }, {
    "code" : "1101",
    "language" : "fr",
    "shortcut" : "VKomm",
    "description" : "Prolongation (commerce)",
    "sortNr" : 9999
  }, {
    "code" : "1101",
    "language" : "en",
    "shortcut" : "VKomm",
    "description" : "Verlängerung (Kommerz)",
    "sortNr" : 9999
  }, {
    "code" : "1110",
    "language" : "de",
    "shortcut" : "SchUe",
    "description" : "Schuldübernahme",
    "sortNr" : 9999
  }, {
    "code" : "1110",
    "language" : "fr",
    "shortcut" : "SchUe",
    "description" : "Reprise de dette",
    "sortNr" : 9999
  }, {
    "code" : "1110",
    "language" : "en",
    "shortcut" : "SchUe",
    "description" : "Schuldübernahme",
    "sortNr" : 9999
  }, {
    "code" : "1140",
    "language" : "de",
    "shortcut" : "inMut",
    "description" : "Interne Mutation",
    "sortNr" : 9999
  }, {
    "code" : "1140",
    "language" : "fr",
    "shortcut" : "inMut",
    "description" : "Mutation interne",
    "sortNr" : 9999
  }, {
    "code" : "1140",
    "language" : "en",
    "shortcut" : "inMut",
    "description" : "Interne Mutation",
    "sortNr" : 9999
  } ]
