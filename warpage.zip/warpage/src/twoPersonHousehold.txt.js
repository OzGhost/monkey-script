var src = src || {}
src.twoPersonHousehold = [
  {
    "clientKey": "40907908177191",
    "twoPersonHousehold": {
      "master": {
        "clientNumber": "14012023",
        "editClientNumber": "14.012.023",
        "openingDate": "2001-08-20",
        "closureDate": null,
        "mainAdvisor": {
          "key": 51292110377631,
          "lastNameFirstName": "Muster Heinz",
          "telephoneNo": "+41 31 311 11 00",
          "email": "Heinz.Muster@valiant.ch"
        },
        "securityAbroad": false,
        "clientDesignation": "Frau Beatrice Egli / Herr Theo M�ller, Mittelhäusern",
        "domicileAddress": {
          "address": "Haupstrasse 999",
          "postcode": "3147",
          "placeDes": "Mittelhäusern",
          "country": "CH",
          "_links": {
            "country": {
              "href": "/v1/banks/6300/codes/Countries/CH"
            }
          }
        },
        "relevantTelNo": {
          "tel": "+41 79 123 45 67",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "TP1",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/TP1"
            }
          }
        },
        "relevantEmail": null,
        "nogaCode": "970000",
        "identityChecked": true,
        "activeBlock": true,
        "blocks": [
          {
            "blockingCode": "93",
            "comment": null,
            "_links": {
              "blockingCodes": {
                "href": "/v1/banks/6300/codes/BlockingCodes/93"
              }
            }
          }
        ],
        "occupationalPension": false,
        "clientMainType": "2",
        "branch": "2086",
        "clientLanguage": "de",
        "clientStatus": "0",
        "legalForm": "14",
        "legalStatus": "51",
        "characteristic1": "",
        "characteristic2": "",
        "category": "10",
        "vsbStatus": "4",
        "riskClass": "",
        "riskCategory": "1",
        "groupType": "5",
        "clientSegment": "11",
        "isOccupationalPension": false,
        "_links": {
          "nogaCode": {
            "href": "/v1/banks/6300/codes/NogaCodes/970000"
          },
          "clientMainType": {
            "href": "/v1/banks/6300/codes/ClientMainTypes/2"
          },
          "branch": {
            "href": "/v1/banks/6300/codes/Offices/2086"
          },
          "clientLanguage": {
            "href": "/v1/banks/6300/codes/Languages/de"
          },
          "clientStatus": {
            "href": "/v1/banks/6300/codes/ClientStatus/0"
          },
          "legalForm": {
            "href": "/v1/banks/6300/codes/LegalForms/14"
          },
          "legalStatus": {
            "href": "/v1/banks/6300/codes/LegalStatus/51"
          },
          "characteristic1": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "characteristic2": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "category": {
            "href": "/v1/banks/6300/codes/ClientCategories/10"
          },
          "vsbStatus": {
            "href": "/v1/banks/6300/codes/VsbStatus/4"
          },
          "riskClass": {
            "href": "/v1/banks/6300/codes/Mandates/"
          },
          "riskCategory": {
            "href": "/v1/banks/6300/codes/RiskCategories/1"
          },
          "groupType": {
            "href": "/v1/banks/6300/codes/ClientGroups/5"
          },
          "clientSegment": {
            "href": "/v1/banks/6300/codes/ClientSegments/11"
          }
        }
      },
      "person": {
        "firstName": "Beatrice",
        "officialFirstName": null,
        "lastName": "Egli",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 1,
        "dateOfBirth": "1988-01-01",
        "dateOfDeath": null,
        "formOfAddress": "1",
        "title": "",
        "maritalStatus": "0",
        "matrimonialPropertyRegime": "0",
        "countryOfBirth": "",
        "nationality": "CH",
        "nationality2": "",
        "profession": "44",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/1"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/0"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/0"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/44"
          }
        }
      },
      "personPartner": {
        "firstName": "Theo",
        "officialFirstName": null,
        "lastName": "M�ller",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 2,
        "dateOfBirth": "1965-05-22",
        "dateOfDeath": null,
        "formOfAddress": "2",
        "title": "",
        "maritalStatus": "0",
        "matrimonialPropertyRegime": "",
        "countryOfBirth": "",
        "nationality": "CH",
        "nationality2": "",
        "profession": "",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/2"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/0"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/"
          }
        }
      }
    }
  },
  {
    "clientKey": "40907944905943",
    "twoPersonHousehold": {
      "master": {
        "clientNumber": "13156728",
        "editClientNumber": "13.156.728",
        "openingDate": "2001-08-20",
        "closureDate": null,
        "mainAdvisor": {
          "key": 51292110377631,
          "lastNameFirstName": "Muster Heinz",
          "telephoneNo": "+41 31 311 11 00",
          "email": "Heinz.Muster@valiant.ch"
        },
        "securityAbroad": false,
        "clientDesignation": "Frau Beatrice Egli / Herr Theo M�ller, Mittelhäusern",
        "domicileAddress": {
          "address": "Haupstrasse 999",
          "postcode": "3147",
          "placeDes": "Mittelhäusern",
          "country": "CH",
          "_links": {
            "country": {
              "href": "/v1/banks/6300/codes/Countries/CH"
            }
          }
        },
        "relevantTelNo": {
          "tel": "+41 79 123 45 67",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "TP1",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/TP1"
            }
          }
        },
        "relevantEmail": null,
        "nogaCode": "970000",
        "identityChecked": true,
        "activeBlock": true,
        "blocks": [
          {
            "blockingCode": "93",
            "comment": null,
            "_links": {
              "blockingCodes": {
                "href": "/v1/banks/6300/codes/BlockingCodes/93"
              }
            }
          }
        ],
        "occupationalPension": false,
        "clientMainType": "2",
        "branch": "2086",
        "clientLanguage": "de",
        "clientStatus": "0",
        "legalForm": "14",
        "legalStatus": "51",
        "characteristic1": "",
        "characteristic2": "",
        "category": "10",
        "vsbStatus": "4",
        "riskClass": "",
        "riskCategory": "1",
        "groupType": "5",
        "clientSegment": "11",
        "isOccupationalPension": false,
        "_links": {
          "nogaCode": {
            "href": "/v1/banks/6300/codes/NogaCodes/970000"
          },
          "clientMainType": {
            "href": "/v1/banks/6300/codes/ClientMainTypes/2"
          },
          "branch": {
            "href": "/v1/banks/6300/codes/Offices/2086"
          },
          "clientLanguage": {
            "href": "/v1/banks/6300/codes/Languages/de"
          },
          "clientStatus": {
            "href": "/v1/banks/6300/codes/ClientStatus/0"
          },
          "legalForm": {
            "href": "/v1/banks/6300/codes/LegalForms/14"
          },
          "legalStatus": {
            "href": "/v1/banks/6300/codes/LegalStatus/51"
          },
          "characteristic1": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "characteristic2": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "category": {
            "href": "/v1/banks/6300/codes/ClientCategories/10"
          },
          "vsbStatus": {
            "href": "/v1/banks/6300/codes/VsbStatus/4"
          },
          "riskClass": {
            "href": "/v1/banks/6300/codes/Mandates/"
          },
          "riskCategory": {
            "href": "/v1/banks/6300/codes/RiskCategories/1"
          },
          "groupType": {
            "href": "/v1/banks/6300/codes/ClientGroups/5"
          },
          "clientSegment": {
            "href": "/v1/banks/6300/codes/ClientSegments/11"
          }
        }
      },
      "person": {
        "firstName": "Beatrice",
        "officialFirstName": null,
        "lastName": "Egli",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 1,
        "dateOfBirth": "1988-01-01",
        "dateOfDeath": null,
        "formOfAddress": "1",
        "title": "",
        "maritalStatus": "0",
        "matrimonialPropertyRegime": "0",
        "countryOfBirth": "",
        "nationality": "CH",
        "nationality2": "",
        "profession": "44",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/1"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/0"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/0"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/44"
          }
        }
      },
      "personPartner": {
        "firstName": "Theo",
        "officialFirstName": null,
        "lastName": "M�ller",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 2,
        "dateOfBirth": "1965-05-22",
        "dateOfDeath": null,
        "formOfAddress": "2",
        "title": "",
        "maritalStatus": "0",
        "matrimonialPropertyRegime": "",
        "countryOfBirth": "",
        "nationality": "CH",
        "nationality2": "",
        "profession": "",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/2"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/0"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/"
          }
        }
      }
    }
  },
  {
    "clientKey": "40907915403472",
    "twoPersonHousehold": {
      "master": {
        "clientNumber": "13183671",
        "editClientNumber": "13.183.671",
        "openingDate": "2001-08-20",
        "closureDate": null,
        "mainAdvisor": {
          "key": 51292110377631,
          "lastNameFirstName": "Muster Heinz",
          "telephoneNo": "+41 31 311 11 00",
          "email": "Heinz.Muster@valiant.ch"
        },
        "securityAbroad": false,
        "clientDesignation": "Frau Beatrice Egli / Herr Theo M�ller, Mittelhäusern",
        "domicileAddress": {
          "address": "Haupstrasse 999",
          "postcode": "3147",
          "placeDes": "Mittelhäusern",
          "country": "CH",
          "_links": {
            "country": {
              "href": "/v1/banks/6300/codes/Countries/CH"
            }
          }
        },
        "relevantTelNo": {
          "tel": "+41 79 123 45 67",
          "relevantEntry": true,
          "comment": null,
          "marketing": false,
          "masked": false,
          "reachableFrom": "",
          "reachableUntil": "",
          "type": "TP1",
          "_links": {
            "type": {
              "href": "/v1/banks/6300/codes/TypesOfCommunication/TP1"
            }
          }
        },
        "relevantEmail": null,
        "nogaCode": "970000",
        "identityChecked": true,
        "activeBlock": true,
        "blocks": [
          {
            "blockingCode": "93",
            "comment": null,
            "_links": {
              "blockingCodes": {
                "href": "/v1/banks/6300/codes/BlockingCodes/93"
              }
            }
          }
        ],
        "occupationalPension": false,
        "clientMainType": "2",
        "branch": "2086",
        "clientLanguage": "de",
        "clientStatus": "0",
        "legalForm": "14",
        "legalStatus": "51",
        "characteristic1": "",
        "characteristic2": "",
        "category": "10",
        "vsbStatus": "4",
        "riskClass": "",
        "riskCategory": "1",
        "groupType": "5",
        "clientSegment": "11",
        "isOccupationalPension": false,
        "_links": {
          "nogaCode": {
            "href": "/v1/banks/6300/codes/NogaCodes/970000"
          },
          "clientMainType": {
            "href": "/v1/banks/6300/codes/ClientMainTypes/2"
          },
          "branch": {
            "href": "/v1/banks/6300/codes/Offices/2086"
          },
          "clientLanguage": {
            "href": "/v1/banks/6300/codes/Languages/de"
          },
          "clientStatus": {
            "href": "/v1/banks/6300/codes/ClientStatus/0"
          },
          "legalForm": {
            "href": "/v1/banks/6300/codes/LegalForms/14"
          },
          "legalStatus": {
            "href": "/v1/banks/6300/codes/LegalStatus/51"
          },
          "characteristic1": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "characteristic2": {
            "href": "/v1/banks/6300/codes/LegalStatusCharacteristics/"
          },
          "category": {
            "href": "/v1/banks/6300/codes/ClientCategories/10"
          },
          "vsbStatus": {
            "href": "/v1/banks/6300/codes/VsbStatus/4"
          },
          "riskClass": {
            "href": "/v1/banks/6300/codes/Mandates/"
          },
          "riskCategory": {
            "href": "/v1/banks/6300/codes/RiskCategories/1"
          },
          "groupType": {
            "href": "/v1/banks/6300/codes/ClientGroups/5"
          },
          "clientSegment": {
            "href": "/v1/banks/6300/codes/ClientSegments/11"
          }
        }
      },
      "person": {
        "firstName": "Beatrice",
        "officialFirstName": null,
        "lastName": "Egli",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 1,
        "dateOfBirth": "1988-01-01",
        "dateOfDeath": null,
        "formOfAddress": "1",
        "title": "",
        "maritalStatus": "0",
        "matrimonialPropertyRegime": "0",
        "countryOfBirth": "",
        "nationality": "CH",
        "nationality2": "",
        "profession": "44",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/1"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/0"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/0"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/44"
          }
        }
      },
      "personPartner": {
        "firstName": "Theo",
        "officialFirstName": null,
        "lastName": "M�ller",
        "officialLastName": null,
        "lastNameBeforeMarriage": null,
        "officialLastNameBeforeMarriage": null,
        "lastNameIsPrefixed": false,
        "gender": 2,
        "dateOfBirth": "1965-05-22",
        "dateOfDeath": null,
        "formOfAddress": "2",
        "title": "",
        "maritalStatus": "0",
        "matrimonialPropertyRegime": "",
        "countryOfBirth": "",
        "nationality": "CH",
        "nationality2": "",
        "profession": "",
        "_links": {
          "formOfAddress": {
            "href": "/v1/banks/6300/codes/ClientSalutations/2"
          },
          "title": {
            "href": "/v1/banks/6300/codes/AcademicTitles/"
          },
          "maritalStatus": {
            "href": "/v1/banks/6300/codes/MaritalStatus/0"
          },
          "matrimonialPropertyRegime": {
            "href": "/v1/banks/6300/codes/PropertyRegimes/"
          },
          "countryOfBirth": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "nationality": {
            "href": "/v1/banks/6300/codes/Countries/CH"
          },
          "nationality2": {
            "href": "/v1/banks/6300/codes/Countries/"
          },
          "profession": {
            "href": "/v1/banks/6300/codes/Professions/"
          }
        }
      }
    }
  }
]
