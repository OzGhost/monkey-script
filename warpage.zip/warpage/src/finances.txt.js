var src = src || {}
src.finances = [
  {
    "clientKey": "40907937079144",
    "finances": {
      "financesPrivate": {
        "revenue": [],
        "liabilities": [
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 3816000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4934",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4934"
              }
            }
          },
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 3816000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4939",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4939"
              }
            }
          }
        ],
        "assets": [
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 63792,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4930",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4930"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 17432,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4931",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4931"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 81224,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4939",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4939"
              }
            }
          }
        ],
        "ratings": []
      },
      "financesCommerce": {
        "financialStatements": [
          {
            "inactive": false,
            "financialStatementDate": "2018-01-13",
            "periodInMonths": 1,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [],
            "ratings": [
              {
                "recognised": false,
                "percentage": null,
                "sfbcClass": null,
                "relevantRating": "RAIP05",
                "rating": -2026832379,
                "internalRatingNo": 51,
                "approvalDate": "2018-01-13",
                "creationDate": "2018-01-12",
                "untilDate": "2299-12-31",
                "ratingAgency": "35",
                "ratingStatus": "1",
                "_links": {
                  "ratingAgency": {
                    "href": "/v1/banks/6300/codes/RatingAgencies/35"
                  },
                  "ratingStatus": {
                    "href": "/v1/banks/6300/codes/RatingStatus/1"
                  }
                }
              }
            ],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "99",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/99"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          },
          {
            "inactive": false,
            "financialStatementDate": "2017-08-04",
            "periodInMonths": 1,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [],
            "ratings": [],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "99",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/99"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          },
          {
            "inactive": false,
            "financialStatementDate": "2014-08-19",
            "periodInMonths": 1,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [],
            "ratings": [],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "99",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/99"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          },
          {
            "inactive": false,
            "financialStatementDate": "2011-06-16",
            "periodInMonths": 1,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [],
            "ratings": [],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "99",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/99"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          }
        ]
      },
      "information": {
        "debtEnforcements": [
          {
            "inactive": false,
            "informationDate": "2014-08-18",
            "numberOfDebtEnforcements": null,
            "amount": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validFrom": null,
            "validUntil": null,
            "informationComment": null,
            "statusAsAt": "2014-08-18",
            "sourceOfInformation": "7",
            "debtEnforcementAssessment": "100",
            "_links": {
              "sourceOfInformation": {
                "href": "/v1/banks/6300/codes/MeansOfInformations/7"
              },
              "debtEnforcementAssessment": {
                "href": "/v1/banks/6300/codes/DebtEnforcementAssessments/100"
              }
            }
          },
          {
            "inactive": false,
            "informationDate": "2011-06-09",
            "numberOfDebtEnforcements": null,
            "amount": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validFrom": null,
            "validUntil": null,
            "informationComment": null,
            "statusAsAt": "2011-06-09",
            "sourceOfInformation": "7",
            "debtEnforcementAssessment": "100",
            "_links": {
              "sourceOfInformation": {
                "href": "/v1/banks/6300/codes/MeansOfInformations/7"
              },
              "debtEnforcementAssessment": {
                "href": "/v1/banks/6300/codes/DebtEnforcementAssessments/100"
              }
            }
          }
        ],
        "tax": []
      },
      "tradeReferences": []
    }
  },
  {
    "clientKey": "40907908177191",
    "finances": {
      "financesPrivate": {
        "revenue": [],
        "liabilities": [
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 140000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4934",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4934"
              }
            }
          },
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 140000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4939",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4939"
              }
            }
          }
        ],
        "assets": [
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 7823.58,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4930",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4930"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 21316.41,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4931",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4931"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 29139.99,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4939",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4939"
              }
            }
          }
        ],
        "ratings": []
      },
      "financesCommerce": {
        "financialStatements": []
      },
      "information": {
        "debtEnforcements": [
          {
            "inactive": false,
            "informationDate": "2013-01-30",
            "numberOfDebtEnforcements": null,
            "amount": {
              "amount": null,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validFrom": null,
            "validUntil": null,
            "informationComment": "kein BA eingeholt",
            "statusAsAt": "2013-01-30",
            "sourceOfInformation": "",
            "debtEnforcementAssessment": "100",
            "_links": {
              "sourceOfInformation": {
                "href": "/v1/banks/6300/codes/MeansOfInformations/"
              },
              "debtEnforcementAssessment": {
                "href": "/v1/banks/6300/codes/DebtEnforcementAssessments/100"
              }
            }
          }
        ],
        "tax": []
      },
      "tradeReferences": []
    }
  },
  {
    "clientKey": "40907883083914",
    "finances": {
      "financesPrivate": {
        "revenue": [],
        "liabilities": [
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 410000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4934",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4934"
              }
            }
          },
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 410000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4939",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4939"
              }
            }
          }
        ],
        "assets": [
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 7152.55,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4930",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4930"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 7152.55,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4939",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4939"
              }
            }
          }
        ],
        "ratings": []
      },
      "financesCommerce": {
        "financialStatements": []
      },
      "information": {
        "debtEnforcements": [],
        "tax": []
      },
      "tradeReferences": []
    }
  },
  {
    "clientKey": "40907944905943",
    "finances": {
      "financesPrivate": {
        "revenue": [
          {
            "relevant": false,
            "manual": true,
            "employer": "Müller Martini Versandsysteme AG",
            "profession": null,
            "activity": null,
            "amountPerYear": {
              "amount": 90872,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2011-09-21",
            "validUntil": "2110-12-31",
            "statusAsAt": "2011-09-22",
            "revenueType": "1",
            "employmentType": "13",
            "occupationalStatus": "",
            "_links": {
              "revenueType": {
                "href": "/v1/banks/6300/codes/IncomeTypes/1"
              },
              "employmentType": {
                "href": "/v1/banks/6300/codes/EmploymentTypes/13"
              },
              "occupationalStatus": {
                "href": "/v1/banks/6300/codes/OccupationalStatus/"
              }
            }
          }
        ],
        "liabilities": [
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 618750,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4934",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4934"
              }
            }
          },
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 618750,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4939",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4939"
              }
            }
          }
        ],
        "assets": [
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 102980.2,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4930",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4930"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 41635.2,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4931",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4931"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 69873,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4933",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4933"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 214488.4,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4939",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4939"
              }
            }
          }
        ],
        "ratings": []
      },
      "financesCommerce": {
        "financialStatements": [
          {
            "inactive": false,
            "financialStatementDate": "2018-01-13",
            "periodInMonths": 1,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [],
            "ratings": [
              {
                "recognised": false,
                "percentage": null,
                "sfbcClass": null,
                "relevantRating": "RANP06",
                "rating": -983504007,
                "internalRatingNo": 60,
                "approvalDate": "2018-01-13",
                "creationDate": "2018-01-12",
                "untilDate": "2299-12-31",
                "ratingAgency": "47",
                "ratingStatus": "1",
                "_links": {
                  "ratingAgency": {
                    "href": "/v1/banks/6300/codes/RatingAgencies/47"
                  },
                  "ratingStatus": {
                    "href": "/v1/banks/6300/codes/RatingStatus/1"
                  }
                }
              }
            ],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "99",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/99"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          },
          {
            "inactive": false,
            "financialStatementDate": "2011-11-04",
            "periodInMonths": 1,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [],
            "ratings": [],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "99",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/99"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          }
        ]
      },
      "information": {
        "debtEnforcements": [
          {
            "inactive": false,
            "informationDate": "2011-09-22",
            "numberOfDebtEnforcements": null,
            "amount": {
              "amount": null,
              "currency": "",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/"
                }
              }
            },
            "validFrom": null,
            "validUntil": null,
            "informationComment": null,
            "statusAsAt": "2011-09-22",
            "sourceOfInformation": "",
            "debtEnforcementAssessment": "100",
            "_links": {
              "sourceOfInformation": {
                "href": "/v1/banks/6300/codes/MeansOfInformations/"
              },
              "debtEnforcementAssessment": {
                "href": "/v1/banks/6300/codes/DebtEnforcementAssessments/100"
              }
            }
          }
        ],
        "tax": []
      },
      "tradeReferences": []
    }
  },
  {
    "clientKey": "40907948419302",
    "finances": {
      "financesPrivate": {
        "revenue": [],
        "liabilities": [
          {
            "manual": true,
            "liabilityWith": "UBS (EFH Küttigkofen",
            "remainingDebt": {
              "amount": 300000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 300000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2014-03-27",
            "liabilityEnd": null,
            "statusAsAt": "2013-01-01",
            "liabilityType": "5005",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/5005"
              }
            }
          },
          {
            "manual": true,
            "liabilityWith": "UBS (MFH Steffisburg)",
            "remainingDebt": {
              "amount": 985000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 985000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2014-03-27",
            "liabilityEnd": null,
            "statusAsAt": "2013-01-01",
            "liabilityType": "5005",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/5005"
              }
            }
          }
        ],
        "assets": [
          {
            "manual": true,
            "assetsWith": "UBS, BEKB",
            "amountTotal": {
              "amount": 232000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2014-03-27",
            "validUntil": "2299-12-31",
            "statusAsAt": "2013-01-01",
            "assetType": "900",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/900"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 650000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2010-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2010-03-01",
            "assetType": "5004",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/5004"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 16739.56,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4930",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4930"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 21253.6,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4931",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4931"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 37993.16,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4939",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4939"
              }
            }
          }
        ],
        "ratings": []
      },
      "financesCommerce": {
        "financialStatements": [
          {
            "inactive": false,
            "financialStatementDate": "2013-12-31",
            "periodInMonths": 12,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [],
            "ratings": [
              {
                "recognised": false,
                "percentage": null,
                "sfbcClass": null,
                "relevantRating": "RAUK07",
                "rating": -942549761,
                "internalRatingNo": 61,
                "approvalDate": "2018-01-13",
                "creationDate": "2018-01-12",
                "untilDate": "2299-12-31",
                "ratingAgency": "31",
                "ratingStatus": "1",
                "_links": {
                  "ratingAgency": {
                    "href": "/v1/banks/6300/codes/RatingAgencies/31"
                  },
                  "ratingStatus": {
                    "href": "/v1/banks/6300/codes/RatingStatus/1"
                  }
                }
              }
            ],
            "financialStatementTypeClient": "2",
            "financialStatementDescription": "1",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/2"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/1"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          },
          {
            "inactive": false,
            "financialStatementDate": "2013-12-31",
            "periodInMonths": 12,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [
              {
                "value": 925000,
                "designation": "301",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/301"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 20000,
                "designation": "397",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/397"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 34000,
                "designation": "366",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/366"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": -152000,
                "designation": "264",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/264"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 865000,
                "designation": "131",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/131"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 2100,
                "designation": "602",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/602"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 2,
                "designation": "622",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/622"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 0,
                "designation": "620",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/620"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": -17,
                "designation": "609",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/609"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 33,
                "designation": "618",
                "type": "6",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/618"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/6"
                  }
                }
              }
            ],
            "ratings": [],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "102",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/102"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          },
          {
            "inactive": false,
            "financialStatementDate": "2012-12-31",
            "periodInMonths": 12,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [
              {
                "value": 1168000,
                "designation": "301",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/301"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 161000,
                "designation": "397",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/397"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": -89000,
                "designation": "366",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/366"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": -32000,
                "designation": "264",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/264"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 993000,
                "designation": "131",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/131"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 2268,
                "designation": "602",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/602"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 13,
                "designation": "622",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/622"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": -129,
                "designation": "620",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/620"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": -3,
                "designation": "609",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/609"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 2,
                "designation": "618",
                "type": "6",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/618"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/6"
                  }
                }
              }
            ],
            "ratings": [],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "102",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/102"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          },
          {
            "inactive": false,
            "financialStatementDate": "2011-12-31",
            "periodInMonths": 12,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [
              {
                "value": 985000,
                "designation": "301",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/301"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 136000,
                "designation": "397",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/397"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": -76000,
                "designation": "366",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/366"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 218000,
                "designation": "264",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/264"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 1324000,
                "designation": "131",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/131"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 947,
                "designation": "602",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/602"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 13,
                "designation": "622",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/622"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": -32,
                "designation": "620",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/620"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 16,
                "designation": "609",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/609"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 6,
                "designation": "618",
                "type": "6",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/618"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/6"
                  }
                }
              }
            ],
            "ratings": [],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "102",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/102"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          },
          {
            "inactive": false,
            "financialStatementDate": "2010-12-31",
            "periodInMonths": 12,
            "auditingBody": null,
            "clientNumberAudit": null,
            "financialFigures": [
              {
                "value": 679000,
                "designation": "301",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/301"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 94000,
                "designation": "397",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/397"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": -5000,
                "designation": "366",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/366"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 455000,
                "designation": "264",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/264"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 1642000,
                "designation": "131",
                "type": "2",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/131"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/2"
                  }
                }
              },
              {
                "value": 165,
                "designation": "602",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/602"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 13,
                "designation": "622",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/622"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": -7,
                "designation": "620",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/620"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 27,
                "designation": "609",
                "type": "1",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/609"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/1"
                  }
                }
              },
              {
                "value": 10,
                "designation": "618",
                "type": "6",
                "_links": {
                  "designation": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigures/618"
                  },
                  "type": {
                    "href": "/v1/banks/6300/codes/FinancialKeyFigureTypes/6"
                  }
                }
              }
            ],
            "ratings": [],
            "financialStatementTypeClient": "0",
            "financialStatementDescription": "102",
            "financialStatementStatus": "1",
            "currency": "CHF",
            "_links": {
              "financialStatementTypeClient": {
                "href": "/v1/banks/6300/codes/FinancialStatementTypes/0"
              },
              "financialStatementDescription": {
                "href": "/v1/banks/6300/codes/FinancialStatementDescriptions/102"
              },
              "financialStatementStatus": {
                "href": "/v1/banks/6300/codes/FinancialStatementStatus/1"
              },
              "currency": {
                "href": "/v1/banks/6300/codes/Currencies/CHF"
              }
            }
          }
        ]
      },
      "information": {
        "debtEnforcements": [
          {
            "inactive": false,
            "informationDate": "2015-01-14",
            "numberOfDebtEnforcements": null,
            "amount": {
              "amount": null,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validFrom": null,
            "validUntil": null,
            "informationComment": null,
            "statusAsAt": "2015-01-15",
            "sourceOfInformation": "2",
            "debtEnforcementAssessment": "0",
            "_links": {
              "sourceOfInformation": {
                "href": "/v1/banks/6300/codes/MeansOfInformations/2"
              },
              "debtEnforcementAssessment": {
                "href": "/v1/banks/6300/codes/DebtEnforcementAssessments/0"
              }
            }
          },
          {
            "inactive": false,
            "informationDate": "2009-11-02",
            "numberOfDebtEnforcements": null,
            "amount": {
              "amount": null,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validFrom": null,
            "validUntil": null,
            "informationComment": null,
            "statusAsAt": "2011-08-04",
            "sourceOfInformation": "",
            "debtEnforcementAssessment": "0",
            "_links": {
              "sourceOfInformation": {
                "href": "/v1/banks/6300/codes/MeansOfInformations/"
              },
              "debtEnforcementAssessment": {
                "href": "/v1/banks/6300/codes/DebtEnforcementAssessments/0"
              }
            }
          },
          {
            "inactive": false,
            "informationDate": "2010-01-21",
            "numberOfDebtEnforcements": null,
            "amount": {
              "amount": null,
              "currency": "",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/"
                }
              }
            },
            "validFrom": null,
            "validUntil": null,
            "informationComment": "Keine Betreibung",
            "statusAsAt": "2010-01-21",
            "sourceOfInformation": "",
            "debtEnforcementAssessment": "0",
            "_links": {
              "sourceOfInformation": {
                "href": "/v1/banks/6300/codes/MeansOfInformations/"
              },
              "debtEnforcementAssessment": {
                "href": "/v1/banks/6300/codes/DebtEnforcementAssessments/0"
              }
            }
          }
        ],
        "tax": []
      },
      "tradeReferences": []
    }
  },
  {
    "clientKey": "40907915403472",
    "finances": {
      "financesPrivate": {
        "revenue": [],
        "liabilities": [
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 458000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4934",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4934"
              }
            }
          },
          {
            "manual": false,
            "liabilityWith": null,
            "remainingDebt": {
              "amount": 0,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "amountPerYear": {
              "amount": 458000,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "liabilityBeginning": "2000-01-01",
            "liabilityEnd": null,
            "statusAsAt": "2018-04-25",
            "liabilityType": "4939",
            "_links": {
              "liabilityType": {
                "href": "/v1/banks/6300/codes/LiabilityTypes/4939"
              }
            }
          }
        ],
        "assets": [
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 14376.32,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4930",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4930"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 51720.75,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4933",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4933"
              }
            }
          },
          {
            "manual": false,
            "assetsWith": null,
            "amountTotal": {
              "amount": 66097.07,
              "currency": "CHF",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/CHF"
                }
              }
            },
            "validAfter": "2000-01-01",
            "validUntil": "2299-12-31",
            "statusAsAt": "2018-04-25",
            "assetType": "4939",
            "_links": {
              "assetType": {
                "href": "/v1/banks/6300/codes/AssetTypes/4939"
              }
            }
          }
        ],
        "ratings": []
      },
      "financesCommerce": {
        "financialStatements": []
      },
      "information": {
        "debtEnforcements": [
          {
            "inactive": false,
            "informationDate": "2010-09-07",
            "numberOfDebtEnforcements": null,
            "amount": {
              "amount": null,
              "currency": "",
              "_links": {
                "currency": {
                  "href": "/v1/banks/6300/codes/Currencies/"
                }
              }
            },
            "validFrom": null,
            "validUntil": null,
            "informationComment": "Keine Betreibung",
            "statusAsAt": "2010-09-07",
            "sourceOfInformation": "",
            "debtEnforcementAssessment": "0",
            "_links": {
              "sourceOfInformation": {
                "href": "/v1/banks/6300/codes/MeansOfInformations/"
              },
              "debtEnforcementAssessment": {
                "href": "/v1/banks/6300/codes/DebtEnforcementAssessments/0"
              }
            }
          }
        ],
        "tax": []
      },
      "tradeReferences": []
    }
  }
]
