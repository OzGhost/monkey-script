var src = src || {}
src.pricings = [
  {
    "orderKey": "54530902270136",
    "pricings": [
      {
        "extPricing": false,
        "modificationKey": 3,
        "tranchesModificationCode": "original",
        "product": 2362,
        "tariffCode": 9013010120971,
        "floating": null,
        "position": 1,
        "term": 6,
        "rating": null,
        "validAfter": "2014-04-01",
        "termFrom": "2014-04-01",
        "termUntil": "2020-03-31",
        "amount": {
          "currency": null,
          "amount": 1896000
        },
        "tariffRate": 1.74,
        "baseRate": 0,
        "maximumRate": null,
        "minimumRate": null,
        "fixingDate": "2015-09-05",
        "deviations": {
          "reason1": null,
          "value1": null,
          "reason2": 2011,
          "value2": 1.74,
          "reason3": null,
          "value3": null,
          "reason4": null,
          "value4": null,
          "forwardSurchargeCode": null,
          "forwardSurchargeRate": null
        },
        "account": {
          "key": 40909253081087,
          "number": null,
          "currency": "CHF",
          "type": 3810,
          "interestPaymentDate": "2018-06-30",
          "periodicity": 6,
          "dayCountConvention": 1,
          "interestAccountNumber": null,
          "interestAccountKey": 40909188749290,
          "_links": {
            "type": {
              "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
            },
            "dayCountConvention": {
              "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
            }
          }
        },
        "oneOffCostsProduct": [],
        "amortisationProduct": [],
        "_links": {
          "product": {
            "href": "/api/v1/banks/6300/codes/ProductTariffs/2362"
          },
          "rating": {
            "href": "/api/v1/banks/6300/codes/ExternalRatings/"
          }
        }
      }
    ]
  },
  {
    "orderKey": "62057340725463",
    "pricings": [
      {
        "extPricing": false,
        "modificationKey": 3,
        "tranchesModificationCode": "original",
        "product": 3211,
        "tariffCode": 9013010120971,
        "floating": null,
        "position": 1,
        "term": 3,
        "rating": null,
        "validAfter": "2015-03-31",
        "termFrom": "2015-04-01",
        "termUntil": "2018-03-31",
        "amount": {
          "currency": null,
          "amount": 1905000
        },
        "tariffRate": 2.94,
        "baseRate": 0,
        "maximumRate": null,
        "minimumRate": null,
        "fixingDate": "2015-09-05",
        "deviations": {
          "reason1": null,
          "value1": null,
          "reason2": 2011,
          "value2": 1.88,
          "reason3": null,
          "value3": null,
          "reason4": null,
          "value4": null,
          "forwardSurchargeCode": null,
          "forwardSurchargeRate": null
        },
        "account": {
          "key": 40909253081087,
          "number": null,
          "currency": "CHF",
          "type": 3810,
          "interestPaymentDate": "2018-06-30",
          "periodicity": 6,
          "dayCountConvention": 1,
          "interestAccountNumber": null,
          "interestAccountKey": 40909188749290,
          "_links": {
            "type": {
              "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
            },
            "dayCountConvention": {
              "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
            }
          }
        },
        "oneOffCostsProduct": [],
        "amortisationProduct": [],
        "_links": {
          "product": {
            "href": "/api/v1/banks/6300/codes/ProductTariffs/2362"
          },
          "rating": {
            "href": "/api/v1/banks/6300/codes/ExternalRatings/"
          }
        }
      },
      {
        "extPricing": false,
        "modificationKey": 3,
        "tranchesModificationCode": "original",
        "product": 3211,
        "tariffCode": 9013010120971,
        "floating": null,
        "position": 1,
        "term": 1,
        "rating": null,
        "validAfter": "2015-03-31",
        "termFrom": "2018-01-01",
        "termUntil": "2018-12-31",
        "amount": {
          "currency": null,
          "amount": 95000
        },
        "tariffRate": 1.88,
        "baseRate": 0,
        "maximumRate": null,
        "minimumRate": null,
        "fixingDate": "2015-09-05",
        "deviations": {
          "reason1": null,
          "value1": null,
          "reason2": 2011,
          "value2": 1.88,
          "reason3": null,
          "value3": null,
          "reason4": null,
          "value4": null,
          "forwardSurchargeCode": null,
          "forwardSurchargeRate": null
        },
        "account": {
          "key": 40909253081087,
          "number": null,
          "currency": "CHF",
          "type": 3810,
          "interestPaymentDate": "2018-06-30",
          "periodicity": 6,
          "dayCountConvention": 1,
          "interestAccountNumber": null,
          "interestAccountKey": 40909188749290,
          "_links": {
            "type": {
              "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
            },
            "dayCountConvention": {
              "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
            }
          }
        },
        "oneOffCostsProduct": [],
        "amortisationProduct": [],
        "_links": {
          "product": {
            "href": "/api/v1/banks/6300/codes/ProductTariffs/2362"
          },
          "rating": {
            "href": "/api/v1/banks/6300/codes/ExternalRatings/"
          }
        }
      }
    ]
  },
  {
    "orderKey": "62964341203191",
    "pricings": [
      {
        "extPricing": false,
        "modificationKey": 3,
        "tranchesModificationCode": "original",
        "product": 3211,
        "tariffCode": 9013010120971,
        "floating": null,
        "position": 1,
        "term": 1,
        "rating": null,
        "validAfter": "2018-02-01",
        "termFrom": "2019-01-31",
        "termUntil": "2019-03-31",
        "amount": {
          "currency": null,
          "amount": 140000
        },
        "tariffRate": 4.02,
        "baseRate": 0,
        "maximumRate": null,
        "minimumRate": null,
        "fixingDate": "2015-09-05",
        "deviations": {
          "reason1": null,
          "value1": null,
          "reason2": 2011,
          "value2": 4.02,
          "reason3": null,
          "value3": null,
          "reason4": null,
          "value4": null,
          "forwardSurchargeCode": null,
          "forwardSurchargeRate": null
        },
        "account": {
          "key": 40909253081087,
          "number": null,
          "currency": "CHF",
          "type": 3810,
          "interestPaymentDate": "2018-06-30",
          "periodicity": 6,
          "dayCountConvention": 1,
          "interestAccountNumber": null,
          "interestAccountKey": 40909188749290,
          "_links": {
            "type": {
              "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
            },
            "dayCountConvention": {
              "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
            }
          }
        },
        "oneOffCostsProduct": [],
        "amortisationProduct": [],
        "_links": {
          "product": {
            "href": "/api/v1/banks/6300/codes/ProductTariffs/2362"
          },
          "rating": {
            "href": "/api/v1/banks/6300/codes/ExternalRatings/"
          }
        }
      }
    ]
  },
  {
    "orderKey": "59560732583955",
    "pricings": [
      {
        "extPricing": false,
        "modificationKey": 3,
        "tranchesModificationCode": "original",
        "product": 3211,
        "tariffCode": 9013010120971,
        "floating": null,
        "position": 1,
        "term": 6,
        "rating": null,
        "validAfter": "2013-04-01",
        "termFrom": "2013-04-01",
        "termUntil": "2019-03-31",
        "amount": {
          "currency": null,
          "amount": 210000
        },
        "tariffRate": 1.03,
        "baseRate": 0,
        "maximumRate": null,
        "minimumRate": null,
        "fixingDate": "2015-09-05",
        "deviations": {
          "reason1": null,
          "value1": null,
          "reason2": 2011,
          "value2": 1.03,
          "reason3": null,
          "value3": null,
          "reason4": null,
          "value4": null,
          "forwardSurchargeCode": null,
          "forwardSurchargeRate": null
        },
        "account": {
          "key": 40909253081087,
          "number": null,
          "currency": "CHF",
          "type": 3810,
          "interestPaymentDate": "2018-06-30",
          "periodicity": 6,
          "dayCountConvention": 1,
          "interestAccountNumber": null,
          "interestAccountKey": 40909188749290,
          "_links": {
            "type": {
              "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
            },
            "dayCountConvention": {
              "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
            }
          }
        },
        "oneOffCostsProduct": [],
        "amortisationProduct": [],
        "_links": {
          "product": {
            "href": "/api/v1/banks/6300/codes/ProductTariffs/2362"
          },
          "rating": {
            "href": "/api/v1/banks/6300/codes/ExternalRatings/"
          }
        }
      }
    ]
  },
  {
    "orderKey": "59093316108491",
    "pricings": [
      {
        "extPricing": false,
        "modificationKey": 3,
        "tranchesModificationCode": "original",
        "product": 3211,
        "tariffCode": 9013010120971,
        "floating": null,
        "position": 1,
        "term": 10,
        "rating": null,
        "validAfter": "2008-08-01",
        "termFrom": "2009-08-01",
        "termUntil": "2019-07-31",
        "amount": {
          "currency": null,
          "amount": 350000
        },
        "tariffRate": 1,
        "baseRate": 0,
        "maximumRate": null,
        "minimumRate": null,
        "fixingDate": "2015-09-05",
        "deviations": {
          "reason1": null,
          "value1": null,
          "reason2": 2011,
          "value2": 1,
          "reason3": null,
          "value3": null,
          "reason4": null,
          "value4": null,
          "forwardSurchargeCode": null,
          "forwardSurchargeRate": null
        },
        "account": {
          "key": 40909253081087,
          "number": null,
          "currency": "CHF",
          "type": 3810,
          "interestPaymentDate": "2018-06-30",
          "periodicity": 6,
          "dayCountConvention": 1,
          "interestAccountNumber": null,
          "interestAccountKey": 40909188749290,
          "_links": {
            "type": {
              "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
            },
            "dayCountConvention": {
              "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
            }
          }
        },
        "oneOffCostsProduct": [],
        "amortisationProduct": [],
        "_links": {
          "product": {
            "href": "/api/v1/banks/6300/codes/ProductTariffs/2362"
          },
          "rating": {
            "href": "/api/v1/banks/6300/codes/ExternalRatings/"
          }
        }
      },
	  {
		"extPricing": false,
		"modificationKey": 14,
		"tranchesModificationCode": "original",
		"product": 2791,
		"tariffCode": 9013010145529,
		"floating": null,
		"position": 1,
		"term": 5,
		"rating": null,
		"validAfter": "2016-06-30",
		"termFrom": "2015-08-01",
		"termUntil": "2020-07-31",
		"amount": {
		  "currency": null,
		  "amount": 350000
		},
		"tariffRate": 1.3,
		"baseRate": 0,
		"maximumRate": null,
		"minimumRate": null,
		"fixingDate": "2015-09-02",
		"deviations": {
		  "reason1": 5009,
		  "value1": -0.07,
		  "reason2": null,
		  "value2": null,
		  "reason3": 5117,
		  "value3": 1.37,
		  "reason4": null,
		  "value4": null,
		  "forwardSurchargeCode": null,
		  "forwardSurchargeRate": null
		},
		"account": {
		  "key": 40909254398411,
		  "number": null,
		  "currency": "CHF",
		  "type": 3810,
		  "interestPaymentDate": "2018-06-30",
		  "periodicity": 6,
		  "dayCountConvention": 1,
		  "interestAccountNumber": null,
		  "interestAccountKey": 40909193582547,
		  "_links": {
			"type": {
			  "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
			},
			"dayCountConvention": {
			  "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
			}
		  }
		},
		"oneOffCostsProduct": [],
		"amortisationProduct": [],
		"_links": {
		  "product": {
			"href": "/api/v1/banks/6300/codes/ProductTariffs/2791"
		  },
		  "rating": {
			"href": "/api/v1/banks/6300/codes/ExternalRatings/"
		  }
		}
	  },
	  {
		"extPricing": false,
		"modificationKey": 13,
		"tranchesModificationCode": "original",
		"product": 2039,
		"tariffCode": 901100002416800,
		"floating": null,
		"position": 2,
		"term": 5,
		"rating": null,
		"validAfter": "2016-10-31",
		"termFrom": "2016-11-01",
		"termUntil": "2021-10-31",
		"amount": {
		  "currency": null,
		  "amount": 268750
		},
		"tariffRate": 1,
		"baseRate": 0,
		"maximumRate": null,
		"minimumRate": null,
		"fixingDate": "2016-09-21",
		"deviations": {
		  "reason1": null,
		  "value1": null,
		  "reason2": null,
		  "value2": null,
		  "reason3": 5117,
		  "value3": 1,
		  "reason4": null,
		  "value4": null,
		  "forwardSurchargeCode": null,
		  "forwardSurchargeRate": null
		},
		"account": {
		  "key": 43378056355490,
		  "number": null,
		  "currency": "CHF",
		  "type": 3860,
		  "interestPaymentDate": "2018-06-30",
		  "periodicity": 6,
		  "dayCountConvention": 1,
		  "interestAccountNumber": null,
		  "interestAccountKey": 40909193582547,
		  "_links": {
			"type": {
			  "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3860"
			},
			"dayCountConvention": {
			  "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
			}
		  }
		},
		"oneOffCostsProduct": [],
		"amortisationProduct": [],
		"_links": {
		  "product": {
			"href": "/api/v1/banks/6300/codes/ProductTariffs/2039"
		  },
		  "rating": {
			"href": "/api/v1/banks/6300/codes/ExternalRatings/"
		  }
		}
	  }
    ]
  },
  {
    "orderKey": "63915860156330",
    "pricings": [
      {
        "extPricing": false,
        "modificationKey": 3,
        "tranchesModificationCode": "original",
        "product": 3211,
        "tariffCode": 9013010120971,
        "floating": null,
        "position": 1,
        "term": 10,
        "rating": null,
        "validAfter": "2008-08-01",
        "termFrom": "2009-08-01",
        "termUntil": "2019-07-31",
        "amount": {
          "currency": null,
          "amount": 150000
        },
        "tariffRate": 2.99,
        "baseRate": 0,
        "maximumRate": null,
        "minimumRate": null,
        "fixingDate": "2015-09-05",
        "deviations": {
          "reason1": null,
          "value1": null,
          "reason2": 2011,
          "value2": 2.99,
          "reason3": null,
          "value3": null,
          "reason4": null,
          "value4": null,
          "forwardSurchargeCode": null,
          "forwardSurchargeRate": null
        },
        "account": {
          "key": 40909253081087,
          "number": null,
          "currency": "CHF",
          "type": 3810,
          "interestPaymentDate": "2018-06-30",
          "periodicity": 6,
          "dayCountConvention": 1,
          "interestAccountNumber": null,
          "interestAccountKey": 40909188749290,
          "_links": {
            "type": {
              "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
            },
            "dayCountConvention": {
              "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
            }
          }
        },
        "oneOffCostsProduct": [],
        "amortisationProduct": [],
        "_links": {
          "product": {
            "href": "/api/v1/banks/6300/codes/ProductTariffs/2362"
          },
          "rating": {
            "href": "/api/v1/banks/6300/codes/ExternalRatings/"
          }
        }
      }
    ]
  },
  {
    "orderKey": "52665579170713",
    "pricings": [
      {
        "extPricing": false,
        "modificationKey": 3,
        "tranchesModificationCode": "original",
        "product": 3211,
        "tariffCode": 9013010120971,
        "floating": null,
        "position": 1,
        "term": 8,
        "rating": null,
        "validAfter": "2010-11-30",
        "termFrom": "2011-11-30",
        "termUntil": "2019-11-30",
        "amount": {
          "currency": null,
          "amount": 229000
        },
        "tariffRate": 3.88,
        "baseRate": 0,
        "maximumRate": null,
        "minimumRate": null,
        "fixingDate": "2015-09-05",
        "deviations": {
          "reason1": null,
          "value1": null,
          "reason2": 2011,
          "value2": 3.88,
          "reason3": null,
          "value3": null,
          "reason4": null,
          "value4": null,
          "forwardSurchargeCode": null,
          "forwardSurchargeRate": null
        },
        "account": {
          "key": 40909253081087,
          "number": null,
          "currency": "CHF",
          "type": 3810,
          "interestPaymentDate": "2018-06-30",
          "periodicity": 6,
          "dayCountConvention": 1,
          "interestAccountNumber": null,
          "interestAccountKey": 40909188749290,
          "_links": {
            "type": {
              "href": "/api/v1/banks/6300/codes/FormsOfAccountUse/3810"
            },
            "dayCountConvention": {
              "href": "/api/v1/banks/6300/codes/DayCountConventions/1"
            }
          }
        },
        "oneOffCostsProduct": [],
        "amortisationProduct": [],
        "_links": {
          "product": {
            "href": "/api/v1/banks/6300/codes/ProductTariffs/2362"
          },
          "rating": {
            "href": "/api/v1/banks/6300/codes/ExternalRatings/"
          }
        }
      }
    ]
  }
]
