var src = src || {}
src.properties = [
  {
    "key": "40913296211527",
    "designation": "10-Familienhaus mit Garage",
    "address": {
      "street": "Wassermattweg 7",
      "postcode": "3176",
      "place": "Neuenegg",
      "country:country": {
        "href": "CH"
      },
      "_links": {
        "curies": [
          {
            "name": "country",
            "href": "/v1/banks/6300/codes/Countries/{rel}",
            "templated": true
          }
        ]
      }
    },
    "landRegisterNumber": {
      "number1": "1959",
      "number2": null,
      "number3": null
    },
    "landRegistryLocation": "Neuenegg",
    "landRegisterOffice": "Neuenegg",
    "taxMunicipality": null,
    "egrid": null,
    "loanToValueRatio": 67,
    "residentialSpaceRate": 100,
    "masterPlot": {
      "landRegNumber1": null,
      "landRegNumber2": null,
      "landRegNumber3": null
    },
    "valueOfShareNumerator": null,
    "valueOfShareDenominator": null,
    "owners": [
      {
        "clientKey": "40907958352288",
        "designation": "xyz",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40907925137831",
        "designation": "Lastname Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40907850256954",
        "designation": "Lastname Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      }
    ],
    "propertyType:propertyType": {
      "href": 3
    },
    "propertyTypeOfUse:usageType": {
      "href": 1
    },
    "buildingType:buildingType": {
      "href": 2
    },
    "typeOfConstruction:typeOfConstruction": {
      "href": 1
    },
    "buildingResidenceType:buildingResidenceType": {
      "href": 0
    },
    "_links": {
      "curies": [
        {
          "name": "buildingType",
          "href": "/v1/banks/6300/codes/BuildingTypes/{rel}",
          "templated": true
        },
        {
          "name": "propertyTypeOfUse",
          "href": "/v1/banks/6300/codes/PropertyTypesOfUse/{rel}",
          "templated": true
        },
        {
          "name": "buildingResidenceType",
          "href": "/v1/banks/6300/codes/BuildingResidenceTypes/{rel}",
          "templated": true
        },
        {
          "name": "typeOfConstruction",
          "href": "/v1/banks/6300/codes/TypesOfConstruction/{rel}",
          "templated": true
        },
        {
          "name": "propertyType",
          "href": "/v1/banks/6300/codes/PropertyTypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "key": "40913324985400",
    "designation": "11-Familienhaus mit Garage",
    "address": {
      "street": "Wassermattweg 9",
      "postcode": "3176",
      "place": "Neuenegg",
      "country:country": {
        "href": "CH"
      },
      "_links": {
        "curies": [
          {
            "name": "country",
            "href": "/v1/banks/6300/codes/Countries/{rel}",
            "templated": true
          }
        ]
      }
    },
    "landRegisterNumber": {
      "number1": "1976",
      "number2": null,
      "number3": null
    },
    "landRegistryLocation": "Neuenegg",
    "landRegisterOffice": "Neuenegg",
    "taxMunicipality": null,
    "egrid": null,
    "loanToValueRatio": 67,
    "residentialSpaceRate": 100,
    "masterPlot": {
      "landRegNumber1": null,
      "landRegNumber2": null,
      "landRegNumber3": null
    },
    "valueOfShareNumerator": null,
    "valueOfShareDenominator": null,
    "owners": [
      {
        "clientKey": "40907925137831",
        "designation": "Gasser Klaus",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40907850256954",
        "designation": "Name Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "57434035980260",
        "designation": "Lastname Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      }
    ],
    "propertyType:propertyType": {
      "href": 3
    },
    "propertyTypeOfUse:usageType": {
      "href": 1
    },
    "buildingType:buildingType": {
      "href": 2
    },
    "typeOfConstruction:typeOfConstruction": {
      "href": 1
    },
    "buildingResidenceType:buildingResidenceType": {
      "href": 0
    },
    "_links": {
      "curies": [
        {
          "name": "buildingType",
          "href": "/v1/banks/6300/codes/BuildingTypes/{rel}",
          "templated": true
        },
        {
          "name": "propertyTypeOfUse",
          "href": "/v1/banks/6300/codes/PropertyTypesOfUse/{rel}",
          "templated": true
        },
        {
          "name": "buildingResidenceType",
          "href": "/v1/banks/6300/codes/BuildingResidenceTypes/{rel}",
          "templated": true
        },
        {
          "name": "typeOfConstruction",
          "href": "/v1/banks/6300/codes/TypesOfConstruction/{rel}",
          "templated": true
        },
        {
          "name": "propertyType",
          "href": "/v1/banks/6300/codes/PropertyTypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "key": "40913296212852",
    "designation": "Chalet RÃ¤gÃ¤pÃ¶li",
    "address": {
      "street": "Wanneggweg 12",
      "postcode": "3715",
      "place": "Adelboden",
      "country:country": {
        "href": "CH"
      },
      "_links": {
        "curies": [
          {
            "name": "country",
            "href": "/v1/banks/6300/codes/Countries/{rel}",
            "templated": true
          }
        ]
      }
    },
    "landRegisterNumber": {
      "number1": "3060",
      "number2": null,
      "number3": null
    },
    "landRegistryLocation": "Adelboden",
    "landRegisterOffice": "Adelboden",
    "taxMunicipality": null,
    "egrid": null,
    "loanToValueRatio": 67,
    "residentialSpaceRate": 100,
    "masterPlot": {
      "landRegNumber1": null,
      "landRegNumber2": null,
      "landRegNumber3": null
    },
    "valueOfShareNumerator": null,
    "valueOfShareDenominator": null,
    "owners": [
      {
        "clientKey": "40907999585179",
        "designation": "Lastname Ã¤r Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40907905065848",
        "designation": "Lastname Ã¤r Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40907957649692",
        "designation": "Lastname Ã¤r Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40907988649713",
        "designation": "Lastname Ã¤r Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40908012142433",
        "designation": "Lastname Ã¤r Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40907865415580",
        "designation": "Lastname Ã¤r Firstnames",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "47880546637174",
        "designation": "Lastname Ã¤r Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      }
    ],
    "propertyType:propertyType": {
      "href": 1
    },
    "propertyTypeOfUse:usageType": {
      "href": 172
    },
    "buildingType:buildingType": {
      "href": 1
    },
    "typeOfConstruction:typeOfConstruction": {
      "href": 1
    },
    "buildingResidenceType:buildingResidenceType": {
      "href": 0
    },
    "_links": {
      "curies": [
        {
          "name": "buildingType",
          "href": "/v1/banks/6300/codes/BuildingTypes/{rel}",
          "templated": true
        },
        {
          "name": "propertyTypeOfUse",
          "href": "/v1/banks/6300/codes/PropertyTypesOfUse/{rel}",
          "templated": true
        },
        {
          "name": "buildingResidenceType",
          "href": "/v1/banks/6300/codes/BuildingResidenceTypes/{rel}",
          "templated": true
        },
        {
          "name": "typeOfConstruction",
          "href": "/v1/banks/6300/codes/TypesOfConstruction/{rel}",
          "templated": true
        },
        {
          "name": "propertyType",
          "href": "/v1/banks/6300/codes/PropertyTypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "key": "40913282011500",
    "designation": "Eckhaus Strassweid",
    "address": {
      "street": "HubelhÃ¼sistrasse 22",
      "postcode": "3147",
      "place": "MittelhÃ¤usern",
      "country:country": {
        "href": "CH"
      },
      "_links": {
        "curies": [
          {
            "name": "country",
            "href": "/v1/banks/6300/codes/Countries/{rel}",
            "templated": true
          }
        ]
      }
    },
    "landRegisterNumber": {
      "number1": "9930",
      "number2": null,
      "number3": null
    },
    "landRegistryLocation": "KÃ¶niz",
    "landRegisterOffice": "KÃ¶niz",
    "taxMunicipality": null,
    "egrid": null,
    "loanToValueRatio": 67,
    "residentialSpaceRate": 100,
    "masterPlot": {
      "landRegNumber1": null,
      "landRegNumber2": null,
      "landRegNumber3": null
    },
    "valueOfShareNumerator": null,
    "valueOfShareDenominator": null,
    "owners": [
      {
        "clientKey": "40907901653439",
        "designation": "Firstname Lastname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      },
      {
        "clientKey": "40907901653438",
        "designation": "Firstname Lastname",
        "ownershipRelationship:ownershipStructure": {
          "href": 3
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      }
    ],
    "propertyType:propertyType": {
      "href": 1
    },
    "propertyTypeOfUse:usageType": {
      "href": 160
    },
    "buildingType:buildingType": {
      "href": 1
    },
    "typeOfConstruction:typeOfConstruction": {
      "href": 2
    },
    "buildingResidenceType:buildingResidenceType": {
      "href": 0
    },
    "_links": {
      "curies": [
        {
          "name": "buildingType",
          "href": "/v1/banks/6300/codes/BuildingTypes/{rel}",
          "templated": true
        },
        {
          "name": "propertyTypeOfUse",
          "href": "/v1/banks/6300/codes/PropertyTypesOfUse/{rel}",
          "templated": true
        },
        {
          "name": "buildingResidenceType",
          "href": "/v1/banks/6300/codes/BuildingResidenceTypes/{rel}",
          "templated": true
        },
        {
          "name": "typeOfConstruction",
          "href": "/v1/banks/6300/codes/TypesOfConstruction/{rel}",
          "templated": true
        },
        {
          "name": "propertyType",
          "href": "/v1/banks/6300/codes/PropertyTypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "key": "40913322583453",
    "designation": "3-Familienhaus",
    "address": {
      "street": "Uettligenstrasse 14",
      "postcode": "3033",
      "place": "Wohlen b. Bern",
      "country:country": {
        "href": "CH"
      },
      "_links": {
        "curies": [
          {
            "name": "country",
            "href": "/v1/banks/6300/codes/Countries/{rel}",
            "templated": true
          }
        ]
      }
    },
    "landRegisterNumber": {
      "number1": "3251",
      "number2": null,
      "number3": null
    },
    "landRegistryLocation": "Wohlen b. Bern",
    "landRegisterOffice": "Wohlen b. Bern",
    "taxMunicipality": null,
    "egrid": null,
    "loanToValueRatio": 67,
    "residentialSpaceRate": 100,
    "masterPlot": {
      "landRegNumber1": null,
      "landRegNumber2": null,
      "landRegNumber3": null
    },
    "valueOfShareNumerator": null,
    "valueOfShareDenominator": null,
    "owners": [
      {
        "clientKey": "40907944905943",
        "designation": "Ackermann Daniel",
        "ownershipRelationship:ownershipStructure": {
          "href": 1
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      }
    ],
    "propertyType:propertyType": {
      "href": 3
    },
    "propertyTypeOfUse:usageType": {
      "href": 1
    },
    "buildingType:buildingType": {
      "href": 2
    },
    "typeOfConstruction:typeOfConstruction": {
      "href": 1
    },
    "buildingResidenceType:buildingResidenceType": {
      "href": 0
    },
    "_links": {
      "curies": [
        {
          "name": "buildingType",
          "href": "/v1/banks/6300/codes/BuildingTypes/{rel}",
          "templated": true
        },
        {
          "name": "propertyTypeOfUse",
          "href": "/v1/banks/6300/codes/PropertyTypesOfUse/{rel}",
          "templated": true
        },
        {
          "name": "buildingResidenceType",
          "href": "/v1/banks/6300/codes/BuildingResidenceTypes/{rel}",
          "templated": true
        },
        {
          "name": "typeOfConstruction",
          "href": "/v1/banks/6300/codes/TypesOfConstruction/{rel}",
          "templated": true
        },
        {
          "name": "propertyType",
          "href": "/v1/banks/6300/codes/PropertyTypes/{rel}",
          "templated": true
        }
      ]
    }
  },
  {
    "key": "40913297033235",
    "designation": "4.5-Zi-ETW mit Garage",
    "address": {
      "street": "Ulmenweg 52",
      "postcode": "3176",
      "place": "Neuenegg",
      "country:country": {
        "href": "CH"
      },
      "_links": {
        "curies": [
          {
            "name": "country",
            "href": "/v1/banks/6300/codes/Countries/{rel}",
            "templated": true
          }
        ]
      }
    },
    "landRegisterNumber": {
      "number1": "1918-2",
      "number2": null,
      "number3": null
    },
    "landRegistryLocation": "Neuenegg",
    "landRegisterOffice": "Neuenegg",
    "taxMunicipality": null,
    "egrid": null,
    "loanToValueRatio": 67,
    "residentialSpaceRate": 100,
    "masterPlot": {
      "landRegNumber1": null,
      "landRegNumber2": null,
      "landRegNumber3": null
    },
    "valueOfShareNumerator": null,
    "valueOfShareDenominator": null,
    "owners": [
      {
        "clientKey": "40907915403472",
        "designation": "Lastname Firstname",
        "ownershipRelationship:ownershipStructure": {
          "href": 1
        },
        "_links": {
          "curies": [
            {
              "name": "ownershipRelationship",
              "href": "/v1/banks/6300/codes/OwnershipRelationships/{rel}",
              "templated": true
            }
          ]
        }
      }
    ],
    "propertyType:propertyType": {
      "href": 2
    },
    "propertyTypeOfUse:usageType": {
      "href": 160
    },
    "buildingType:buildingType": {
      "href": 3
    },
    "typeOfConstruction:typeOfConstruction": {
      "href": 0
    },
    "buildingResidenceType:buildingResidenceType": {
      "href": 6
    },
    "_links": {
      "curies": [
        {
          "name": "buildingType",
          "href": "/v1/banks/6300/codes/BuildingTypes/{rel}",
          "templated": true
        },
        {
          "name": "propertyTypeOfUse",
          "href": "/v1/banks/6300/codes/PropertyTypesOfUse/{rel}",
          "templated": true
        },
        {
          "name": "buildingResidenceType",
          "href": "/v1/banks/6300/codes/BuildingResidenceTypes/{rel}",
          "templated": true
        },
        {
          "name": "typeOfConstruction",
          "href": "/v1/banks/6300/codes/TypesOfConstruction/{rel}",
          "templated": true
        },
        {
          "name": "propertyType",
          "href": "/v1/banks/6300/codes/PropertyTypes/{rel}",
          "templated": true
        }
      ]
    }
  }
]
