var src = src || {}
src.clientMainType = [
  {
    "clientKey": "40907937079144",
    "clientMainType": {
      "clientMainType": "1",
      "_links": {
        "clientMainType": {
          "href": "/v1/banks/6300/codes/ClientMainTypes/1"
        }
      }
    }
  },
  {
    "clientKey": "40907908177191",
    "clientMainType": {
      "clientMainType": "2",
      "_links": {
        "clientMainType": {
          "href": "/v1/banks/6300/codes/ClientMainTypes/1"
        }
      }
    }
  },
  {
    "clientKey": "40907883083914",
    "clientMainType": {
      "clientMainType": "1",
      "_links": {
        "clientMainType": {
          "href": "/v1/banks/6300/codes/ClientMainTypes/1"
        }
      }
    }
  },
  {
    "clientKey": "40907944905943",
    "clientMainType": {
      "clientMainType": "2",
      "_links": {
        "clientMainType": {
          "href": "/v1/banks/6300/codes/ClientMainTypes/1"
        }
      }
    }
  },
  {
    "clientKey": "40907948419302",
    "clientMainType": {
      "clientMainType": "1",
      "_links": {
        "clientMainType": {
          "href": "/v1/banks/6300/codes/ClientMainTypes/1"
        }
      }
    }
  },
  {
    "clientKey": "40907915403472",
    "clientMainType": {
      "clientMainType": "2",
      "_links": {
        "clientMainType": {
          "href": "/v1/banks/6300/codes/ClientMainTypes/1"
        }
      }
    }
  }
]
