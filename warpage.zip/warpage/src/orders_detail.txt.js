var src = src || {}
src.ordersDetail = [
	{
		"orderKey": "54530902270136",
		"orderDetail": {
			"key": "54530902270136",
			"id": "13986226/001/0004",
			"clientKey": "40907937079144",
			"creditLineDesignation": null,
			"purpose": "Vorzeitige Verlängerung der per 31.03.2015 auslaufenden Festhypothek unter Zusammenlegung mit der kleinen variablen Tranche.\nGemäss Besprechung zwischen Klaus Gasser und HMC vom 02.09.2014 (Offerte) resp. 05.09.2014 (Zusage).\n\nSOKO-Mail direkt an LST geschickt. Es folgen keine weiteren Unterlagen.\n\nDie korrekte Abbildung des Partners wird noch verlangt - bei Fragen HMC anrufen.",
			"use": "2015-04-13",
			"overallLimit": {
				"amount": 1896000,
				"currency:currency": {
					"href": "CHF"
				},
				"_links": {
					"curies": [
						{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
						}
					]
				}
			},
			"resubmission": "2030-02-01",
			"BusinessCases:businessCase": {
				"href": 941
			},
			"LoanRequestReason:reasonForApplication": {
				"href": 1040
			},
			"_links": {
				"curies": [
					{
						"name": "LoanRequestReason",
						"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
						"templated": true
					},
					{
						"name": "businessCase",
						"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
						"templated": true
					}
				]
			}
		}
	},
	{
		"orderKey": "62057340725463",
		"orderDetail": {
			"key": "62057340725463",
			"id": "13986226/002/0007",
			"clientKey": "40907937079144",
			"creditLineDesignation": null,
			"purpose": "ErhÃ¶hung um CHF 95'000.00 und Errichtung einer neuen FZH Nr. 13.986.226.190.6 mit Laufzeit bis 31.12.2022 zu 1.20%.\n\nGrund der ErhÃ¶hung: LiquiditÃ¤tsbedarf.\n\nAuszahlung in 5 Tranchen auf Valiant Konto Nr 13.986.226.454.9 ltd. auf xyz.\n\nValuta Auszahlung 1. Tranche 03. Januar 2018, danach jÃ¤hrlich am 3.1.\n\nBearbeitungsgebÃ¼hr: CHF 250.00\n\nRisikoprofil: Orange (Einkommen, ErtrÃ¤ge & Ã¼brige Engagements)\n\nxyz ist verstorben. Sein Miteigentumsanteil von 1/3 ist an abc Ã¼bergegangen (gem. GB-Auszug).",
			"use": "2017-08-31",
			"overallLimit": {
				"amount": 2000000,
				"currency:currency": {
					"href": "CHF"
				},
				"_links": {
					"curies": [
						{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
						}
					]
				}
			},
			"resubmission": "2030-02-01",
			"BusinessCases:businessCase": {
				"href": 910
			},
			"LoanRequestReason:reasonForApplication": {
				"href": 1001
			},
			"_links": {
				"curies": [
					{
						"name": "LoanRequestReason",
						"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
						"templated": true
					},
					{
						"name": "businessCase",
						"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
						"templated": true
					}
				]
			}
		}
	},
	{
		"orderKey": "62964341203191",
		"orderDetail": {
			"key": "62964341203191",
			"id": "14012023/001/0004",
			"clientKey": "40907908177191",
			"creditLineDesignation": null,
			"purpose": "Umwandlung / Verlängerung\n\n>>>Bearbeitungsgebühren CHF 150.00",
			"use": "2017-12-14",
			"overallLimit": {
				"amount": 140000,
				"currency:currency": {
					"href": "CHF"
				},
				"_links": {
					"curies": [
						{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
						}
					]
				}
			},
			"resubmission": "2299-12-31",
			"BusinessCases:businessCase": {
				"href": 941
			},
			"LoanRequestReason:reasonForApplication": {
				"href": 1040
			},
			"_links": {
				"curies": [
					{
						"name": "LoanRequestReason",
						"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
						"templated": true
					},
					{
						"name": "businessCase",
						"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
						"templated": true
					}
				]
			}
		}
	},
	{
		"orderKey": "59560732583955",
		"orderDetail": {
			"key": "59560732583955",
			"id": "13157779/001/0005",
			"clientKey": "40907883083914",
			"creditLineDesignation": null,
			"purpose": "Korrektur Produkt gem. Mail E. Zimmermann",
			"use": "2016-11-15",
			"overallLimit": {
				"amount": 410000,
				"currency:currency": {
					"href": "CHF"
				},
				"_links": {
					"curies": [
						{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
						}
					]
				}
			},
			"resubmission": "2299-12-31",
			"BusinessCases:businessCase": {
				"href": 965
			},
			"LoanRequestReason:reasonForApplication": {
				"href": 1140
			},
			"_links": {
				"curies": [
					{
						"name": "LoanRequestReason",
						"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
						"templated": true
					},
					{
						"name": "businessCase",
						"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
						"templated": true
					}
				]
			}
		}
	},
	{
		"orderKey": "59460742583945",
		"orderDetail": {
			"key": "59460742583945",
			"id": "13157779/001/0005",
			"clientKey": "40907883083914",
			"creditLineDesignation": null,
			"purpose": "Korrektur Produkt gem. Mail E. Zimmermann",
			"use": "2016-11-15",
			"overallLimit": {
				"amount": 410000,
				"currency:currency": {
					"href": "CHF"
				},
				"_links": {
					"curies": [
						{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
						}
					]
				}
			},
			"resubmission": "2299-12-31",
			"BusinessCases:businessCase": {
				"href": 965
			},
			"LoanRequestReason:reasonForApplication": {
				"href": 1140
			},
			"_links": {
				"curies": [
					{
						"name": "LoanRequestReason",
						"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
						"templated": true
					},
					{
						"name": "businessCase",
						"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
						"templated": true
					}
				]
			}
		}
	},
	{
		"orderKey": "59093316108491",
		"orderDetail": {
			"key": "59093316108491",
			"id": "13156728/001/0006",
			"clientKey": "40907944905943",
			"creditLineDesignation": null,
			"purpose": "Verlängerung der per 31.10.2016 fällig werdenden FZH-Tranche als Familienhypothek.\n\nBeibehaltung der aktuellen Amortisationen (CHF 1'250.00 p.Q.).\n\nBelastung Bearbeitungskommission CHF 250.00 i.O.",
			"use": "2016-09-22",
			"overallLimit": {
				"amount": 620000,
				"currency:currency": {
					"href": "CHF"
				},
				"_links": {
					"curies": [
						{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
						}
					]
				}
			},
			"resubmission": "2026-10-31",
			"BusinessCases:businessCase": {
				"href": 941
			},
			"LoanRequestReason:reasonForApplication": {
				"href": 1040
			},
			"_links": {
				"curies": [
					{
						"name": "LoanRequestReason",
						"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
						"templated": true
					},
					{
						"name": "businessCase",
						"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
						"templated": true
					}
				]
			}
		}
	},
	{
		"orderKey": "63915860156330",
		"orderDetail": {
			"key": "63915860156330",
			"id": "13152782/001/0024",
			"clientKey": "40907948419302",
			"creditLineDesignation": null,
			"purpose": "RÃ¼ckzahlung Darlehen Nr. 18 9.363.824.08 von CHF 500'000.00 per 31.03.2018, z.L. Sparkonto 13.152.782.512.4 ltd. auf Firstname Lastname (Betrag bereits gekÃ¼ndigt). Alsdann das Sparkonto aus der Pfandhaft entlassen. \n\nKK-Limite von CHF 150'000.00 bleibt weiterhin bestehend.	Nach Erhalten des def. Jahresabschlusses 2017 wird die Limite an die neu gegrÃ¼ndete ABC AG (PN: 50.395.8939) Ã¼bertragen.\nAlsdann wird die Saldierungs-KB Rahmen 1 erstellt. \n\nDurch den erhÃ¶hten RKW der ZÃ¼rich-Police 7.442.145 ltd. auf Firstname Lastname entfÃ¤llt die Blanko-Deckung.",
			"use": "2018-04-03",
			"overallLimit": {
				"amount": 150000,
				"currency:currency": {
					"href": "CHF"
				},
				"_links": {
					"curies": [
						{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
						}
					]
				}
			},
			"resubmission": "2018-09-30",
			"BusinessCases:businessCase": {
				"href": 920
			},
			"LoanRequestReason:reasonForApplication": {
				"href": 1080
			},
			"_links": {
				"curies": [
					{
						"name": "LoanRequestReason",
						"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
						"templated": true
					},
					{
						"name": "businessCase",
						"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
						"templated": true
					}
				]
			}
		}
	},
	{
		"orderKey": "52665579170713",
		"orderDetail": {
			"key": "52665579170713",
			"id": "13183671/001/0003",
			"clientKey": "40907915403472",
			"creditLineDesignation": null,
			"purpose": "Umwandlung / Verlängerung gemäss Mailverkehr zwischen Beat Aeschlimann und HMC vom 08.09.2014\n\nEs folgen keine weiteren Unterlagen.",
			"use": "2014-09-09",
			"overallLimit": {
				"amount": 458000,
				"currency:currency": {
					"href": "CHF"
				},
				"_links": {
					"curies": [
						{
							"name": "currency",
							"href": "/v2/banks/6300/codes/Currencies/{rel}",
							"templated": true
						}
					]
				}
			},
			"resubmission": "2299-12-31",
			"BusinessCases:businessCase": {
				"href": 941
			},
			"LoanRequestReason:reasonForApplication": {
				"href": 1040
			},
			"_links": {
				"curies": [
					{
						"name": "LoanRequestReason",
						"href": "/v2/banks/6300/codes/LoanRequestReasons/{rel}",
						"templated": true
					},
					{
						"name": "businessCase",
						"href": "/v2/banks/6300/codes/BusinessCases/{rel}",
						"templated": true
					}
				]
			}
		}
	}
]
