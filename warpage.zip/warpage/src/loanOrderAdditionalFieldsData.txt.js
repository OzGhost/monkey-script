var src = src || {}
src.loadOrderAdditionalFieldsData = [	
	{	
		"orderKey":"54530902270136",
		"loanOrderAdditionalFieldsData":[
			{
				"designation": "Securisation",
				"value": "1"
			},
			{
				"designation": "Securisation",
				"value": "1"
			},
			{
				"designation": "Securisation",
				"value": "1"
			}
		]
	},
	{	
		"orderKey":"62064579096058",
		"loanOrderAdditionalFieldsData":[
			{
				"designation": "Securisation",
				"value": "1"
			}
		]
	},
	{	
		"orderKey":"62064579096055",
		"loanOrderAdditionalFieldsData":[
			{
				"designation": "Securisation",
				"value": "1"
			}
		]
	},
	{	
		"orderKey":"62964341203191",
		"loanOrderAdditionalFieldsData":[
			{
				"designation": "Securisation",
				"value": "1"
			}
		]
	},
	{	
		"orderKey":"59093316108491",
		"loanOrderAdditionalFieldsData":[
			{
				"designation": "Securisation",
				"value": "1"
			}
		]
	},
	{	
		"orderKey":"59560732583955",
		"loanOrderAdditionalFieldsData":[
			{
				"designation": "Securisation",
				"value": "1"
			}
		]
	},
	{	
		"orderKey":"52665579170713",
		"loanOrderAdditionalFieldsData":[
			{
				"designation": "Securisation",
				"value": "1"
			}
		]
	},
	{	
		"orderKey":"63915860156330",
		"loanOrderAdditionalFieldsData":[
			{
				"designation": "Securisation",
				"value": "0"
			}
		]
	}
]
