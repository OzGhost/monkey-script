var src = src || {}
  src.countries = [ {
    "code" : "488",
    "language" : "de",
    "shortcut" : "WI",
    "description" : "Westindische Staaten",
    "sortNr" : null
  }, {
    "code" : "488",
    "language" : "fr",
    "shortcut" : "WI",
    "description" : "Indes occidentales",
    "sortNr" : null
  }, {
    "code" : "488",
    "language" : "en",
    "shortcut" : "WI",
    "description" : "West Indian States",
    "sortNr" : null
  }, {
    "code" : "66",
    "language" : "de",
    "shortcut" : "FANT",
    "description" : "Französische Antillen",
    "sortNr" : 9999
  }, {
    "code" : "66",
    "language" : "fr",
    "shortcut" : "FANT",
    "description" : "Antilles Françaises",
    "sortNr" : 9999
  }, {
    "code" : "66",
    "language" : "en",
    "shortcut" : "FANT",
    "description" : "French Antilles",
    "sortNr" : 9999
  }, {
    "code" : "AD",
    "language" : "de",
    "shortcut" : "AND",
    "description" : "Andorra",
    "sortNr" : 9999
  }, {
    "code" : "AD",
    "language" : "fr",
    "shortcut" : "AND",
    "description" : "Andorre",
    "sortNr" : 9999
  }, {
    "code" : "AD",
    "language" : "en",
    "shortcut" : "AND",
    "description" : "Andorra",
    "sortNr" : 9999
  }, {
    "code" : "AE",
    "language" : "de",
    "shortcut" : "UAE",
    "description" : "Vereinigte Arabische Emirate",
    "sortNr" : 9999
  }, {
    "code" : "AE",
    "language" : "fr",
    "shortcut" : "UAE",
    "description" : "Emirats Arabes Unis",
    "sortNr" : 9999
  }, {
    "code" : "AE",
    "language" : "en",
    "shortcut" : "UAE",
    "description" : "United Arab Emirates",
    "sortNr" : 9999
  }, {
    "code" : "AF",
    "language" : "de",
    "shortcut" : "AFG",
    "description" : "Afghanistan",
    "sortNr" : 9999
  }, {
    "code" : "AF",
    "language" : "fr",
    "shortcut" : "AFG",
    "description" : "Afghanistan",
    "sortNr" : 9999
  }, {
    "code" : "AF",
    "language" : "en",
    "shortcut" : "AFG",
    "description" : "Afghanistan",
    "sortNr" : 9999
  }, {
    "code" : "AG",
    "language" : "de",
    "shortcut" : "AG",
    "description" : "Antigua und Barbuda",
    "sortNr" : 9999
  }, {
    "code" : "AG",
    "language" : "fr",
    "shortcut" : "AG",
    "description" : "Antigua-et- Barbuda",
    "sortNr" : 9999
  }, {
    "code" : "AG",
    "language" : "en",
    "shortcut" : "AG",
    "description" : "Antigua and Barbuda",
    "sortNr" : 9999
  }, {
    "code" : "AI",
    "language" : "de",
    "shortcut" : "AI",
    "description" : "Anguilla",
    "sortNr" : 9999
  }, {
    "code" : "AI",
    "language" : "fr",
    "shortcut" : "AI",
    "description" : "Anguilla",
    "sortNr" : 9999
  }, {
    "code" : "AI",
    "language" : "en",
    "shortcut" : "AI",
    "description" : "Anguilla",
    "sortNr" : 9999
  }, {
    "code" : "AL",
    "language" : "de",
    "shortcut" : "AL",
    "description" : "Albanien",
    "sortNr" : 9999
  }, {
    "code" : "AL",
    "language" : "fr",
    "shortcut" : "AL",
    "description" : "Albanie",
    "sortNr" : 9999
  }, {
    "code" : "AL",
    "language" : "en",
    "shortcut" : "AL",
    "description" : "Albania",
    "sortNr" : 9999
  }, {
    "code" : "AM",
    "language" : "de",
    "shortcut" : "ARM",
    "description" : "Armenien",
    "sortNr" : 9999
  }, {
    "code" : "AM",
    "language" : "fr",
    "shortcut" : "ARM",
    "description" : "Arménie",
    "sortNr" : 9999
  }, {
    "code" : "AM",
    "language" : "en",
    "shortcut" : "ARM",
    "description" : "Armenia",
    "sortNr" : 9999
  }, {
    "code" : "AN",
    "language" : "de",
    "shortcut" : "NA",
    "description" : "Niederländische Antillen",
    "sortNr" : 9999
  }, {
    "code" : "AN",
    "language" : "fr",
    "shortcut" : "AN",
    "description" : "Antilles néerlandaises",
    "sortNr" : 9999
  }, {
    "code" : "AN",
    "language" : "en",
    "shortcut" : "NA",
    "description" : "Netherlands Antilles",
    "sortNr" : 9999
  }, {
    "code" : "AO",
    "language" : "de",
    "shortcut" : "ANG",
    "description" : "Angola",
    "sortNr" : 9999
  }, {
    "code" : "AO",
    "language" : "fr",
    "shortcut" : "ANG",
    "description" : "Angola",
    "sortNr" : 9999
  }, {
    "code" : "AO",
    "language" : "en",
    "shortcut" : "ANG",
    "description" : "Angola",
    "sortNr" : 9999
  }, {
    "code" : "AQ",
    "language" : "de",
    "shortcut" : "AQ",
    "description" : "Antarktis",
    "sortNr" : 9999
  }, {
    "code" : "AQ",
    "language" : "fr",
    "shortcut" : "AQ",
    "description" : "Antarctique",
    "sortNr" : 9999
  }, {
    "code" : "AQ",
    "language" : "en",
    "shortcut" : "AQ",
    "description" : "Antarctica",
    "sortNr" : 9999
  }, {
    "code" : "AR",
    "language" : "de",
    "shortcut" : "AR",
    "description" : "Argentinien",
    "sortNr" : 9999
  }, {
    "code" : "AR",
    "language" : "fr",
    "shortcut" : "AR",
    "description" : "Argentine",
    "sortNr" : 9999
  }, {
    "code" : "AR",
    "language" : "en",
    "shortcut" : "AR",
    "description" : "Argentina",
    "sortNr" : 9999
  }, {
    "code" : "AS",
    "language" : "de",
    "shortcut" : "AS",
    "description" : "Amerikanisch-Samoa",
    "sortNr" : 9999
  }, {
    "code" : "AS",
    "language" : "fr",
    "shortcut" : "AS",
    "description" : "Samoa américaines",
    "sortNr" : 9999
  }, {
    "code" : "AS",
    "language" : "en",
    "shortcut" : "AS",
    "description" : "American Samoa",
    "sortNr" : 9999
  }, {
    "code" : "AT",
    "language" : "de",
    "shortcut" : "A",
    "description" : "Österreich",
    "sortNr" : 9999
  }, {
    "code" : "AT",
    "language" : "fr",
    "shortcut" : "A",
    "description" : "Autriche",
    "sortNr" : 9999
  }, {
    "code" : "AT",
    "language" : "en",
    "shortcut" : "A",
    "description" : "Austria",
    "sortNr" : 9999
  }, {
    "code" : "AU",
    "language" : "de",
    "shortcut" : "AUS",
    "description" : "Australien",
    "sortNr" : 9999
  }, {
    "code" : "AU",
    "language" : "fr",
    "shortcut" : "AUS",
    "description" : "Australie",
    "sortNr" : 9999
  }, {
    "code" : "AU",
    "language" : "en",
    "shortcut" : "AUS",
    "description" : "Australia",
    "sortNr" : 9999
  }, {
    "code" : "AW",
    "language" : "de",
    "shortcut" : "ARU",
    "description" : "Aruba",
    "sortNr" : 9999
  }, {
    "code" : "AW",
    "language" : "fr",
    "shortcut" : "ARU",
    "description" : "Aruba",
    "sortNr" : 9999
  }, {
    "code" : "AW",
    "language" : "en",
    "shortcut" : "ARU",
    "description" : "Aruba",
    "sortNr" : 9999
  }, {
    "code" : "AX",
    "language" : "de",
    "shortcut" : "AX",
    "description" : "Alandinseln",
    "sortNr" : 9999
  }, {
    "code" : "AX",
    "language" : "fr",
    "shortcut" : "AX",
    "description" : "Aland, Iles",
    "sortNr" : 9999
  }, {
    "code" : "AX",
    "language" : "en",
    "shortcut" : "AX",
    "description" : "Aland Islands",
    "sortNr" : 9999
  }, {
    "code" : "AZ",
    "language" : "de",
    "shortcut" : "ASE",
    "description" : "Aserbaidschan",
    "sortNr" : 9999
  }, {
    "code" : "AZ",
    "language" : "fr",
    "shortcut" : "ASE",
    "description" : "Azerbaïdjan",
    "sortNr" : 9999
  }, {
    "code" : "AZ",
    "language" : "en",
    "shortcut" : "ASE",
    "description" : "Azerbaijan",
    "sortNr" : 9999
  }, {
    "code" : "BA",
    "language" : "de",
    "shortcut" : "BIH",
    "description" : "Bosnien und Herzegowina",
    "sortNr" : 9999
  }, {
    "code" : "BA",
    "language" : "fr",
    "shortcut" : "BosnH",
    "description" : "Bosnie-Herzégovine",
    "sortNr" : 9999
  }, {
    "code" : "BA",
    "language" : "en",
    "shortcut" : "BIH",
    "description" : "Bosnia and Herzegovina",
    "sortNr" : 9999
  }, {
    "code" : "BB",
    "language" : "de",
    "shortcut" : "BDS",
    "description" : "Barbados",
    "sortNr" : 9999
  }, {
    "code" : "BB",
    "language" : "fr",
    "shortcut" : "BDS",
    "description" : "Barbade",
    "sortNr" : 9999
  }, {
    "code" : "BB",
    "language" : "en",
    "shortcut" : "BDS",
    "description" : "Barbados",
    "sortNr" : 9999
  }, {
    "code" : "BD",
    "language" : "de",
    "shortcut" : "BD",
    "description" : "Bangladesch",
    "sortNr" : 9999
  }, {
    "code" : "BD",
    "language" : "fr",
    "shortcut" : "BD",
    "description" : "Bangladesh",
    "sortNr" : 9999
  }, {
    "code" : "BD",
    "language" : "en",
    "shortcut" : "BD",
    "description" : "Bangladesh",
    "sortNr" : 9999
  }, {
    "code" : "BE",
    "language" : "de",
    "shortcut" : "B",
    "description" : "Belgien",
    "sortNr" : 9999
  }, {
    "code" : "BE",
    "language" : "fr",
    "shortcut" : "B",
    "description" : "Belgique",
    "sortNr" : 9999
  }, {
    "code" : "BE",
    "language" : "en",
    "shortcut" : "B",
    "description" : "Belgium",
    "sortNr" : 9999
  }, {
    "code" : "BF",
    "language" : "de",
    "shortcut" : "BF",
    "description" : "Burkina Faso",
    "sortNr" : 9999
  }, {
    "code" : "BF",
    "language" : "fr",
    "shortcut" : "BF",
    "description" : "Burkina Faso",
    "sortNr" : 9999
  }, {
    "code" : "BF",
    "language" : "en",
    "shortcut" : "BF",
    "description" : "Burkina Faso",
    "sortNr" : 9999
  }, {
    "code" : "BG",
    "language" : "de",
    "shortcut" : "BG",
    "description" : "Bulgarien",
    "sortNr" : 9999
  }, {
    "code" : "BG",
    "language" : "fr",
    "shortcut" : "BG",
    "description" : "Bulgarie",
    "sortNr" : 9999
  }, {
    "code" : "BG",
    "language" : "en",
    "shortcut" : "BG",
    "description" : "Bulgaria",
    "sortNr" : 9999
  }, {
    "code" : "BH",
    "language" : "de",
    "shortcut" : "BRN",
    "description" : "Bahrain",
    "sortNr" : 9999
  }, {
    "code" : "BH",
    "language" : "fr",
    "shortcut" : "BRN",
    "description" : "Bahreïn",
    "sortNr" : 9999
  }, {
    "code" : "BH",
    "language" : "en",
    "shortcut" : "BRN",
    "description" : "Bahrain",
    "sortNr" : 9999
  }, {
    "code" : "BI",
    "language" : "de",
    "shortcut" : "RU",
    "description" : "Burundi",
    "sortNr" : 9999
  }, {
    "code" : "BI",
    "language" : "fr",
    "shortcut" : "RU",
    "description" : "Burundi",
    "sortNr" : 9999
  }, {
    "code" : "BI",
    "language" : "en",
    "shortcut" : "RU",
    "description" : "Burundi",
    "sortNr" : 9999
  }, {
    "code" : "BJ",
    "language" : "de",
    "shortcut" : "BJ",
    "description" : "Benin",
    "sortNr" : 9999
  }, {
    "code" : "BJ",
    "language" : "fr",
    "shortcut" : "BJ",
    "description" : "Bénin",
    "sortNr" : 9999
  }, {
    "code" : "BJ",
    "language" : "en",
    "shortcut" : "BJ",
    "description" : "Benin",
    "sortNr" : 9999
  }, {
    "code" : "BL",
    "language" : "de",
    "shortcut" : "BL",
    "description" : "Saint Barthélemy",
    "sortNr" : 9999
  }, {
    "code" : "BL",
    "language" : "fr",
    "shortcut" : "BL",
    "description" : "Saint Barthélemy",
    "sortNr" : 9999
  }, {
    "code" : "BL",
    "language" : "en",
    "shortcut" : "BL",
    "description" : "Saint Barthélemy",
    "sortNr" : 9999
  }, {
    "code" : "BM",
    "language" : "de",
    "shortcut" : "BDA",
    "description" : "Bermuda",
    "sortNr" : 9999
  }, {
    "code" : "BM",
    "language" : "fr",
    "shortcut" : "BDA",
    "description" : "Bermudes",
    "sortNr" : 9999
  }, {
    "code" : "BM",
    "language" : "en",
    "shortcut" : "BDA",
    "description" : "Bermuda",
    "sortNr" : 9999
  }, {
    "code" : "BN",
    "language" : "de",
    "shortcut" : "BRU",
    "description" : "Brunei Darussalam",
    "sortNr" : 9999
  }, {
    "code" : "BN",
    "language" : "fr",
    "shortcut" : "BRU",
    "description" : "Brunei Darussalam",
    "sortNr" : 9999
  }, {
    "code" : "BN",
    "language" : "en",
    "shortcut" : "BRU",
    "description" : "Brunei Darussalam",
    "sortNr" : 9999
  }, {
    "code" : "BO",
    "language" : "de",
    "shortcut" : "BOL",
    "description" : "Bolivien",
    "sortNr" : 9999
  }, {
    "code" : "BO",
    "language" : "fr",
    "shortcut" : "BOL",
    "description" : "Bolivie",
    "sortNr" : 9999
  }, {
    "code" : "BO",
    "language" : "en",
    "shortcut" : "BOL",
    "description" : "Bolivia",
    "sortNr" : 9999
  }, {
    "code" : "BQ",
    "language" : "de",
    "shortcut" : "BQ",
    "description" : "Bonaire, Saint Eustatius and Saba",
    "sortNr" : 9999
  }, {
    "code" : "BQ",
    "language" : "fr",
    "shortcut" : "Bonai",
    "description" : "Bonaire, Saint Eustatius and Saba",
    "sortNr" : 9999
  }, {
    "code" : "BQ",
    "language" : "en",
    "shortcut" : "BQ",
    "description" : "Bonaire, Saint Eustatius and Saba",
    "sortNr" : 9999
  }, {
    "code" : "BR",
    "language" : "de",
    "shortcut" : "BR",
    "description" : "Brasilien",
    "sortNr" : 9999
  }, {
    "code" : "BR",
    "language" : "fr",
    "shortcut" : "BR",
    "description" : "Brésil",
    "sortNr" : 9999
  }, {
    "code" : "BR",
    "language" : "en",
    "shortcut" : "BR",
    "description" : "Brazil",
    "sortNr" : 9999
  }, {
    "code" : "BS",
    "language" : "de",
    "shortcut" : "BS",
    "description" : "Bahamas",
    "sortNr" : 9999
  }, {
    "code" : "BS",
    "language" : "fr",
    "shortcut" : "BS",
    "description" : "Bahamas",
    "sortNr" : 9999
  }, {
    "code" : "BS",
    "language" : "en",
    "shortcut" : "BS",
    "description" : "Bahamas",
    "sortNr" : 9999
  }, {
    "code" : "BT",
    "language" : "de",
    "shortcut" : "BHT",
    "description" : "Bhutan",
    "sortNr" : 9999
  }, {
    "code" : "BT",
    "language" : "fr",
    "shortcut" : "BHT",
    "description" : "Bhoutan",
    "sortNr" : 9999
  }, {
    "code" : "BT",
    "language" : "en",
    "shortcut" : "BHT",
    "description" : "Bhutan",
    "sortNr" : 9999
  }, {
    "code" : "BV",
    "language" : "de",
    "shortcut" : "BOU",
    "description" : "Bouvetinsel",
    "sortNr" : 9999
  }, {
    "code" : "BV",
    "language" : "fr",
    "shortcut" : "BOU",
    "description" : "Bouvet, Île",
    "sortNr" : 9999
  }, {
    "code" : "BV",
    "language" : "en",
    "shortcut" : "BOU",
    "description" : "Bouvet Island",
    "sortNr" : 9999
  }, {
    "code" : "BW",
    "language" : "de",
    "shortcut" : "RB",
    "description" : "Botsuana",
    "sortNr" : 9999
  }, {
    "code" : "BW",
    "language" : "fr",
    "shortcut" : "RB",
    "description" : "Botswana",
    "sortNr" : 9999
  }, {
    "code" : "BW",
    "language" : "en",
    "shortcut" : "RB",
    "description" : "Botswana",
    "sortNr" : 9999
  }, {
    "code" : "BY",
    "language" : "de",
    "shortcut" : "BLR",
    "description" : "Belarus",
    "sortNr" : 9999
  }, {
    "code" : "BY",
    "language" : "fr",
    "shortcut" : "BLR",
    "description" : "Bélarus",
    "sortNr" : 9999
  }, {
    "code" : "BY",
    "language" : "en",
    "shortcut" : "BLR",
    "description" : "Belarus",
    "sortNr" : 9999
  }, {
    "code" : "BZ",
    "language" : "de",
    "shortcut" : "BH",
    "description" : "Belize",
    "sortNr" : 9999
  }, {
    "code" : "BZ",
    "language" : "fr",
    "shortcut" : "BH",
    "description" : "Belize",
    "sortNr" : 9999
  }, {
    "code" : "BZ",
    "language" : "en",
    "shortcut" : "BH",
    "description" : "Belize",
    "sortNr" : 9999
  }, {
    "code" : "CA",
    "language" : "de",
    "shortcut" : "CDN",
    "description" : "Kanada",
    "sortNr" : 9999
  }, {
    "code" : "CA",
    "language" : "fr",
    "shortcut" : "CDN",
    "description" : "Canada",
    "sortNr" : 9999
  }, {
    "code" : "CA",
    "language" : "en",
    "shortcut" : "CDN",
    "description" : "Canada",
    "sortNr" : 9999
  }, {
    "code" : "CC",
    "language" : "de",
    "shortcut" : "CC",
    "description" : "Kokosinseln (Keeling)",
    "sortNr" : 9999
  }, {
    "code" : "CC",
    "language" : "fr",
    "shortcut" : "CC",
    "description" : "Cocos (Keeling), Îles",
    "sortNr" : 9999
  }, {
    "code" : "CC",
    "language" : "en",
    "shortcut" : "CC",
    "description" : "Cocos (Keeling) Islands",
    "sortNr" : 9999
  }, {
    "code" : "CD",
    "language" : "de",
    "shortcut" : "CRD",
    "description" : "Kongo (Kinshasa)",
    "sortNr" : 9999
  }, {
    "code" : "CD",
    "language" : "fr",
    "shortcut" : "CRD",
    "description" : "Congo, République démocratique du",
    "sortNr" : 9999
  }, {
    "code" : "CD",
    "language" : "en",
    "shortcut" : "CRD",
    "description" : "Congo, the Democratic Republic of the",
    "sortNr" : 9999
  }, {
    "code" : "CF",
    "language" : "de",
    "shortcut" : "RCA",
    "description" : "Zentral-Afrikanische Republik",
    "sortNr" : 9999
  }, {
    "code" : "CF",
    "language" : "fr",
    "shortcut" : "RCA",
    "description" : "Centrafricaine, République",
    "sortNr" : 9999
  }, {
    "code" : "CF",
    "language" : "en",
    "shortcut" : "RCA",
    "description" : "Central African Republic",
    "sortNr" : 9999
  }, {
    "code" : "CG",
    "language" : "de",
    "shortcut" : "RCB",
    "description" : "Kongo (Brazzaville)",
    "sortNr" : 9999
  }, {
    "code" : "CG",
    "language" : "fr",
    "shortcut" : "RCB",
    "description" : "Congo",
    "sortNr" : 9999
  }, {
    "code" : "CG",
    "language" : "en",
    "shortcut" : "RCB",
    "description" : "Congo",
    "sortNr" : 9999
  }, {
    "code" : "CH",
    "language" : "de",
    "shortcut" : "CH",
    "description" : "Schweiz",
    "sortNr" : 9999
  }, {
    "code" : "CH",
    "language" : "fr",
    "shortcut" : "CH",
    "description" : "Suisse",
    "sortNr" : 9999
  }, {
    "code" : "CH",
    "language" : "en",
    "shortcut" : "CH",
    "description" : "Switzerland",
    "sortNr" : 9999
  }, {
    "code" : "CI",
    "language" : "de",
    "shortcut" : "CI",
    "description" : "Côte d'Ivoire",
    "sortNr" : 9999
  }, {
    "code" : "CI",
    "language" : "fr",
    "shortcut" : "CI",
    "description" : "Côte d'Ivoire",
    "sortNr" : 9999
  }, {
    "code" : "CI",
    "language" : "en",
    "shortcut" : "CI",
    "description" : "Côte d'Ivoire",
    "sortNr" : 9999
  }, {
    "code" : "CIXL",
    "language" : "de",
    "shortcut" : "CICXL",
    "description" : "Solvency II (CIC-XL)",
    "sortNr" : 9999
  }, {
    "code" : "CIXL",
    "language" : "fr",
    "shortcut" : "CICXL",
    "description" : "Solvency II (CIC-XL)",
    "sortNr" : 9999
  }, {
    "code" : "CIXL",
    "language" : "en",
    "shortcut" : "CICXL",
    "description" : "Solvency II (CIC-XL)",
    "sortNr" : 9999
  }, {
    "code" : "CIXT",
    "language" : "de",
    "shortcut" : "CICXT",
    "description" : "Solvency II (CIC-XT)",
    "sortNr" : 9999
  }, {
    "code" : "CIXT",
    "language" : "fr",
    "shortcut" : "CICXT",
    "description" : "Solvency II (CIC-XT)",
    "sortNr" : 9999
  }, {
    "code" : "CIXT",
    "language" : "en",
    "shortcut" : "CICXT",
    "description" : "Solvency II (CIC-XT)",
    "sortNr" : 9999
  }, {
    "code" : "CK",
    "language" : "de",
    "shortcut" : "CK",
    "description" : "Cookinseln",
    "sortNr" : 9999
  }, {
    "code" : "CK",
    "language" : "fr",
    "shortcut" : "CK",
    "description" : "Cook, Îles",
    "sortNr" : 9999
  }, {
    "code" : "CK",
    "language" : "en",
    "shortcut" : "CK",
    "description" : "Cook Islands",
    "sortNr" : 9999
  }, {
    "code" : "CL",
    "language" : "de",
    "shortcut" : "RCH",
    "description" : "Chile",
    "sortNr" : 9999
  }, {
    "code" : "CL",
    "language" : "fr",
    "shortcut" : "RCH",
    "description" : "Chili",
    "sortNr" : 9999
  }, {
    "code" : "CL",
    "language" : "en",
    "shortcut" : "RCH",
    "description" : "Chile",
    "sortNr" : 9999
  }, {
    "code" : "CM",
    "language" : "de",
    "shortcut" : "CAM",
    "description" : "Kamerun",
    "sortNr" : 9999
  }, {
    "code" : "CM",
    "language" : "fr",
    "shortcut" : "CAM",
    "description" : "Cameroun",
    "sortNr" : 9999
  }, {
    "code" : "CM",
    "language" : "en",
    "shortcut" : "CAM",
    "description" : "Cameroon",
    "sortNr" : 9999
  }, {
    "code" : "CN",
    "language" : "de",
    "shortcut" : "CN",
    "description" : "China",
    "sortNr" : 9999
  }, {
    "code" : "CN",
    "language" : "fr",
    "shortcut" : "CN",
    "description" : "Chine",
    "sortNr" : 9999
  }, {
    "code" : "CN",
    "language" : "en",
    "shortcut" : "CN",
    "description" : "China",
    "sortNr" : 9999
  }, {
    "code" : "CO",
    "language" : "de",
    "shortcut" : "CO",
    "description" : "Kolumbien",
    "sortNr" : 9999
  }, {
    "code" : "CO",
    "language" : "fr",
    "shortcut" : "CO",
    "description" : "Colombie",
    "sortNr" : 9999
  }, {
    "code" : "CO",
    "language" : "en",
    "shortcut" : "CO",
    "description" : "Colombia",
    "sortNr" : 9999
  }, {
    "code" : "CR",
    "language" : "de",
    "shortcut" : "CR",
    "description" : "Costa Rica",
    "sortNr" : 9999
  }, {
    "code" : "CR",
    "language" : "fr",
    "shortcut" : "CR",
    "description" : "Costa Rica",
    "sortNr" : 9999
  }, {
    "code" : "CR",
    "language" : "en",
    "shortcut" : "CR",
    "description" : "Costa Rica",
    "sortNr" : 9999
  }, {
    "code" : "CU",
    "language" : "de",
    "shortcut" : "C",
    "description" : "Kuba",
    "sortNr" : 9999
  }, {
    "code" : "CU",
    "language" : "fr",
    "shortcut" : "C",
    "description" : "Cuba",
    "sortNr" : 9999
  }, {
    "code" : "CU",
    "language" : "en",
    "shortcut" : "C",
    "description" : "Cuba",
    "sortNr" : 9999
  }, {
    "code" : "CV",
    "language" : "de",
    "shortcut" : "CV",
    "description" : "Kap Verde",
    "sortNr" : 9999
  }, {
    "code" : "CV",
    "language" : "fr",
    "shortcut" : "CV",
    "description" : "Cap-Vert",
    "sortNr" : 9999
  }, {
    "code" : "CV",
    "language" : "en",
    "shortcut" : "CV",
    "description" : "Cape Verde",
    "sortNr" : 9999
  }, {
    "code" : "CW",
    "language" : "de",
    "shortcut" : "CW",
    "description" : "Curaçao",
    "sortNr" : 9999
  }, {
    "code" : "CW",
    "language" : "fr",
    "shortcut" : "CW",
    "description" : "Curaçao",
    "sortNr" : 9999
  }, {
    "code" : "CW",
    "language" : "en",
    "shortcut" : "CW",
    "description" : "Curaçao",
    "sortNr" : 9999
  }, {
    "code" : "CX",
    "language" : "de",
    "shortcut" : "CX",
    "description" : "Weihnachtsinsel",
    "sortNr" : 9999
  }, {
    "code" : "CX",
    "language" : "fr",
    "shortcut" : "CX",
    "description" : "Christmas, Île",
    "sortNr" : 9999
  }, {
    "code" : "CX",
    "language" : "en",
    "shortcut" : "CX",
    "description" : "Christmas Island",
    "sortNr" : 9999
  }, {
    "code" : "CY",
    "language" : "de",
    "shortcut" : "CY",
    "description" : "Zypern",
    "sortNr" : 9999
  }, {
    "code" : "CY",
    "language" : "fr",
    "shortcut" : "CY",
    "description" : "Chypre",
    "sortNr" : 9999
  }, {
    "code" : "CY",
    "language" : "en",
    "shortcut" : "CY",
    "description" : "Cyprus",
    "sortNr" : 9999
  }, {
    "code" : "CZ",
    "language" : "de",
    "shortcut" : "CZ",
    "description" : "Tschechische Republik",
    "sortNr" : 9999
  }, {
    "code" : "CZ",
    "language" : "fr",
    "shortcut" : "CZ",
    "description" : "Tchèque, République",
    "sortNr" : 9999
  }, {
    "code" : "CZ",
    "language" : "en",
    "shortcut" : "CZ",
    "description" : "Czech Republic",
    "sortNr" : 9999
  }, {
    "code" : "DE",
    "language" : "de",
    "shortcut" : "D",
    "description" : "Deutschland",
    "sortNr" : 9999
  }, {
    "code" : "DE",
    "language" : "fr",
    "shortcut" : "D",
    "description" : "Allemagne",
    "sortNr" : 9999
  }, {
    "code" : "DE",
    "language" : "en",
    "shortcut" : "D",
    "description" : "Germany",
    "sortNr" : 9999
  }, {
    "code" : "DJ",
    "language" : "de",
    "shortcut" : "DJI",
    "description" : "Dschibuti",
    "sortNr" : 9999
  }, {
    "code" : "DJ",
    "language" : "fr",
    "shortcut" : "DJI",
    "description" : "Djibouti",
    "sortNr" : 9999
  }, {
    "code" : "DJ",
    "language" : "en",
    "shortcut" : "DJI",
    "description" : "Djibouti",
    "sortNr" : 9999
  }, {
    "code" : "DK",
    "language" : "de",
    "shortcut" : "DK",
    "description" : "Dänemark",
    "sortNr" : 9999
  }, {
    "code" : "DK",
    "language" : "fr",
    "shortcut" : "DK",
    "description" : "Danemark",
    "sortNr" : 9999
  }, {
    "code" : "DK",
    "language" : "en",
    "shortcut" : "DK",
    "description" : "Denmark",
    "sortNr" : 9999
  }, {
    "code" : "DM",
    "language" : "de",
    "shortcut" : "WD",
    "description" : "Dominica",
    "sortNr" : 9999
  }, {
    "code" : "DM",
    "language" : "fr",
    "shortcut" : "WD",
    "description" : "Dominique",
    "sortNr" : 9999
  }, {
    "code" : "DM",
    "language" : "en",
    "shortcut" : "WD",
    "description" : "Dominica",
    "sortNr" : 9999
  }, {
    "code" : "DO",
    "language" : "de",
    "shortcut" : "DOM",
    "description" : "Dominikanische Republik",
    "sortNr" : 9999
  }, {
    "code" : "DO",
    "language" : "fr",
    "shortcut" : "DOM",
    "description" : "Dominicaine, République",
    "sortNr" : 9999
  }, {
    "code" : "DO",
    "language" : "en",
    "shortcut" : "DOM",
    "description" : "Dominican Republic",
    "sortNr" : 9999
  }, {
    "code" : "DZ",
    "language" : "de",
    "shortcut" : "DZ",
    "description" : "Algerien",
    "sortNr" : 9999
  }, {
    "code" : "DZ",
    "language" : "fr",
    "shortcut" : "DZ",
    "description" : "Algérie",
    "sortNr" : 9999
  }, {
    "code" : "DZ",
    "language" : "en",
    "shortcut" : "DZ",
    "description" : "Algeria",
    "sortNr" : 9999
  }, {
    "code" : "EC",
    "language" : "de",
    "shortcut" : "EC",
    "description" : "Ecuador",
    "sortNr" : 9999
  }, {
    "code" : "EC",
    "language" : "fr",
    "shortcut" : "EC",
    "description" : "Equateur",
    "sortNr" : 9999
  }, {
    "code" : "EC",
    "language" : "en",
    "shortcut" : "EC",
    "description" : "Ecuador",
    "sortNr" : 9999
  }, {
    "code" : "EE",
    "language" : "de",
    "shortcut" : "EW",
    "description" : "Estland",
    "sortNr" : 9999
  }, {
    "code" : "EE",
    "language" : "fr",
    "shortcut" : "EW",
    "description" : "Estonie",
    "sortNr" : 9999
  }, {
    "code" : "EE",
    "language" : "en",
    "shortcut" : "EW",
    "description" : "Estonia",
    "sortNr" : 9999
  }, {
    "code" : "EG",
    "language" : "de",
    "shortcut" : "ET",
    "description" : "Ägypten",
    "sortNr" : 9999
  }, {
    "code" : "EG",
    "language" : "fr",
    "shortcut" : "ET",
    "description" : "Égypte",
    "sortNr" : 9999
  }, {
    "code" : "EG",
    "language" : "en",
    "shortcut" : "ET",
    "description" : "Egypt",
    "sortNr" : 9999
  }, {
    "code" : "EH",
    "language" : "de",
    "shortcut" : "EH",
    "description" : "Westsahara",
    "sortNr" : 9999
  }, {
    "code" : "EH",
    "language" : "fr",
    "shortcut" : "EH",
    "description" : "Sahara Occidental",
    "sortNr" : 9999
  }, {
    "code" : "EH",
    "language" : "en",
    "shortcut" : "EH",
    "description" : "Western Sahara",
    "sortNr" : 9999
  }, {
    "code" : "ER",
    "language" : "de",
    "shortcut" : "ER",
    "description" : "Eritrea",
    "sortNr" : 9999
  }, {
    "code" : "ER",
    "language" : "fr",
    "shortcut" : "ER",
    "description" : "Érythrée",
    "sortNr" : 9999
  }, {
    "code" : "ER",
    "language" : "en",
    "shortcut" : "ER",
    "description" : "Eritrea",
    "sortNr" : 9999
  }, {
    "code" : "ES",
    "language" : "de",
    "shortcut" : "E",
    "description" : "Spanien",
    "sortNr" : 9999
  }, {
    "code" : "ES",
    "language" : "fr",
    "shortcut" : "E",
    "description" : "Espagne",
    "sortNr" : 9999
  }, {
    "code" : "ES",
    "language" : "en",
    "shortcut" : "E",
    "description" : "Spain",
    "sortNr" : 9999
  }, {
    "code" : "ET",
    "language" : "de",
    "shortcut" : "ETH",
    "description" : "Äthiopien",
    "sortNr" : 9999
  }, {
    "code" : "ET",
    "language" : "fr",
    "shortcut" : "ETH",
    "description" : "Éthiopie",
    "sortNr" : 9999
  }, {
    "code" : "ET",
    "language" : "en",
    "shortcut" : "ETH",
    "description" : "Ethiopia",
    "sortNr" : 9999
  }, {
    "code" : "EU",
    "language" : "de",
    "shortcut" : "EU",
    "description" : "Europäische Union",
    "sortNr" : 9999
  }, {
    "code" : "EU",
    "language" : "fr",
    "shortcut" : "UE",
    "description" : "Union européenne",
    "sortNr" : 9999
  }, {
    "code" : "EU",
    "language" : "en",
    "shortcut" : "EU",
    "description" : "European Union",
    "sortNr" : 9999
  }, {
    "code" : "EU-V",
    "language" : "de",
    "shortcut" : "EUST",
    "description" : "EUSt-Staatsvertrag",
    "sortNr" : null
  }, {
    "code" : "EU-V",
    "language" : "fr",
    "shortcut" : "EUST",
    "description" : "Traité international rel. retenue d'impôt de l'UE sur les intérêts",
    "sortNr" : null
  }, {
    "code" : "EU-V",
    "language" : "en",
    "shortcut" : "EUTX",
    "description" : "EU tax - bilateral agreement",
    "sortNr" : null
  }, {
    "code" : "EWR",
    "language" : "de",
    "shortcut" : "EWR",
    "description" : "Europäischer Wirtschaftsraum",
    "sortNr" : 9999
  }, {
    "code" : "EWR",
    "language" : "fr",
    "shortcut" : "EEE",
    "description" : "Espace économique européen",
    "sortNr" : 9999
  }, {
    "code" : "EWR",
    "language" : "en",
    "shortcut" : "EUTX",
    "description" : "EU tax - bilateral agreement",
    "sortNr" : 9999
  }, {
    "code" : "EXUD",
    "language" : "de",
    "shortcut" : "ExUds",
    "description" : "Ex-UDSSR",
    "sortNr" : 9999
  }, {
    "code" : "EXUD",
    "language" : "fr",
    "shortcut" : "ExUrs",
    "description" : "Ex-URSS",
    "sortNr" : 9999
  }, {
    "code" : "EXUD",
    "language" : "en",
    "shortcut" : "Formr",
    "description" : "Former USSR",
    "sortNr" : 9999
  }, {
    "code" : "FI",
    "language" : "de",
    "shortcut" : "FIN",
    "description" : "Finnland",
    "sortNr" : 9999
  }, {
    "code" : "FI",
    "language" : "fr",
    "shortcut" : "FIN",
    "description" : "Finlande",
    "sortNr" : 9999
  }, {
    "code" : "FI",
    "language" : "en",
    "shortcut" : "FIN",
    "description" : "Finland",
    "sortNr" : 9999
  }, {
    "code" : "FJ",
    "language" : "de",
    "shortcut" : "FJI",
    "description" : "Fidschi-Inseln",
    "sortNr" : 9999
  }, {
    "code" : "FJ",
    "language" : "fr",
    "shortcut" : "FJI",
    "description" : "Iles Fidji",
    "sortNr" : 9999
  }, {
    "code" : "FJ",
    "language" : "en",
    "shortcut" : "FJI",
    "description" : "Fiji",
    "sortNr" : 9999
  }, {
    "code" : "FK",
    "language" : "de",
    "shortcut" : "FK",
    "description" : "Falklandinseln (Malvinen)",
    "sortNr" : 9999
  }, {
    "code" : "FK",
    "language" : "fr",
    "shortcut" : "FK",
    "description" : "Falkland, Îles (Malvinas)",
    "sortNr" : 9999
  }, {
    "code" : "FK",
    "language" : "en",
    "shortcut" : "FK",
    "description" : "Falkland Islands (Malvinas)",
    "sortNr" : 9999
  }, {
    "code" : "FM",
    "language" : "de",
    "shortcut" : "FSM",
    "description" : "Mikronesien, Föderierte Staaten von",
    "sortNr" : 9999
  }, {
    "code" : "FM",
    "language" : "fr",
    "shortcut" : "FSM",
    "description" : "Micronésie, États fédérés de",
    "sortNr" : 9999
  }, {
    "code" : "FM",
    "language" : "en",
    "shortcut" : "FSM",
    "description" : "Micronesia, the Federated States of",
    "sortNr" : 9999
  }, {
    "code" : "FO",
    "language" : "de",
    "shortcut" : "FR",
    "description" : "Färöer",
    "sortNr" : 9999
  }, {
    "code" : "FO",
    "language" : "fr",
    "shortcut" : "FR",
    "description" : "Féroé, Îles",
    "sortNr" : 9999
  }, {
    "code" : "FO",
    "language" : "en",
    "shortcut" : "FR",
    "description" : "Faroe Islands",
    "sortNr" : 9999
  }, {
    "code" : "FR",
    "language" : "de",
    "shortcut" : "F",
    "description" : "Frankreich",
    "sortNr" : 9999
  }, {
    "code" : "FR",
    "language" : "fr",
    "shortcut" : "F",
    "description" : "France",
    "sortNr" : 9999
  }, {
    "code" : "FR",
    "language" : "en",
    "shortcut" : "F",
    "description" : "France",
    "sortNr" : 9999
  }, {
    "code" : "GA",
    "language" : "de",
    "shortcut" : "G",
    "description" : "Gabun",
    "sortNr" : 9999
  }, {
    "code" : "GA",
    "language" : "fr",
    "shortcut" : "G",
    "description" : "Gabon",
    "sortNr" : 9999
  }, {
    "code" : "GA",
    "language" : "en",
    "shortcut" : "G",
    "description" : "Gabon",
    "sortNr" : 9999
  }, {
    "code" : "GB",
    "language" : "de",
    "shortcut" : "GB",
    "description" : "Grossbritannien und Nordirland",
    "sortNr" : 9999
  }, {
    "code" : "GB",
    "language" : "fr",
    "shortcut" : "GB",
    "description" : "Grande-Bretagne et Irlande du Nord",
    "sortNr" : 9999
  }, {
    "code" : "GB",
    "language" : "en",
    "shortcut" : "GB",
    "description" : "United Kingdom",
    "sortNr" : 9999
  }, {
    "code" : "GD",
    "language" : "de",
    "shortcut" : "WG",
    "description" : "Grenada",
    "sortNr" : 9999
  }, {
    "code" : "GD",
    "language" : "fr",
    "shortcut" : "WG",
    "description" : "Grenade",
    "sortNr" : 9999
  }, {
    "code" : "GD",
    "language" : "en",
    "shortcut" : "WG",
    "description" : "Grenada",
    "sortNr" : 9999
  }, {
    "code" : "GE",
    "language" : "de",
    "shortcut" : "GE",
    "description" : "Georgien",
    "sortNr" : 9999
  }, {
    "code" : "GE",
    "language" : "fr",
    "shortcut" : "GE",
    "description" : "Géorgie",
    "sortNr" : 9999
  }, {
    "code" : "GE",
    "language" : "en",
    "shortcut" : "GE",
    "description" : "Georgia",
    "sortNr" : 9999
  }, {
    "code" : "GF",
    "language" : "de",
    "shortcut" : "GF",
    "description" : "Französisch-Guayana",
    "sortNr" : 9999
  }, {
    "code" : "GF",
    "language" : "fr",
    "shortcut" : "GF",
    "description" : "Guyane française",
    "sortNr" : 9999
  }, {
    "code" : "GF",
    "language" : "en",
    "shortcut" : "GF",
    "description" : "French Guiana",
    "sortNr" : 9999
  }, {
    "code" : "GG",
    "language" : "de",
    "shortcut" : "GBG",
    "description" : "Guernsey",
    "sortNr" : 9999
  }, {
    "code" : "GG",
    "language" : "fr",
    "shortcut" : "GBG",
    "description" : "Guernesey",
    "sortNr" : 9999
  }, {
    "code" : "GG",
    "language" : "en",
    "shortcut" : "GBG",
    "description" : "Guernsey",
    "sortNr" : 9999
  }, {
    "code" : "GH",
    "language" : "de",
    "shortcut" : "GH",
    "description" : "Ghana",
    "sortNr" : 9999
  }, {
    "code" : "GH",
    "language" : "fr",
    "shortcut" : "GH",
    "description" : "Ghana",
    "sortNr" : 9999
  }, {
    "code" : "GH",
    "language" : "en",
    "shortcut" : "GH",
    "description" : "Ghana",
    "sortNr" : 9999
  }, {
    "code" : "GI",
    "language" : "de",
    "shortcut" : "GBZ",
    "description" : "Gibraltar",
    "sortNr" : 9999
  }, {
    "code" : "GI",
    "language" : "fr",
    "shortcut" : "GBZ",
    "description" : "Gibraltar",
    "sortNr" : 9999
  }, {
    "code" : "GI",
    "language" : "en",
    "shortcut" : "GBZ",
    "description" : "Gibraltar",
    "sortNr" : 9999
  }, {
    "code" : "GL",
    "language" : "de",
    "shortcut" : "GL",
    "description" : "Grönland",
    "sortNr" : 9999
  }, {
    "code" : "GL",
    "language" : "fr",
    "shortcut" : "GL",
    "description" : "Groenland",
    "sortNr" : 9999
  }, {
    "code" : "GL",
    "language" : "en",
    "shortcut" : "GL",
    "description" : "Greenland",
    "sortNr" : 9999
  }, {
    "code" : "GM",
    "language" : "de",
    "shortcut" : "WAG",
    "description" : "Gambia",
    "sortNr" : 9999
  }, {
    "code" : "GM",
    "language" : "fr",
    "shortcut" : "WAG",
    "description" : "Gambie",
    "sortNr" : 9999
  }, {
    "code" : "GM",
    "language" : "en",
    "shortcut" : "WAG",
    "description" : "Gambia",
    "sortNr" : 9999
  }, {
    "code" : "GN",
    "language" : "de",
    "shortcut" : "RG",
    "description" : "Guinea",
    "sortNr" : 9999
  }, {
    "code" : "GN",
    "language" : "fr",
    "shortcut" : "RG",
    "description" : "Guinée",
    "sortNr" : 9999
  }, {
    "code" : "GN",
    "language" : "en",
    "shortcut" : "RG",
    "description" : "Guinea",
    "sortNr" : 9999
  }, {
    "code" : "GP",
    "language" : "de",
    "shortcut" : "GP",
    "description" : "Guadeloupe",
    "sortNr" : 9999
  }, {
    "code" : "GP",
    "language" : "fr",
    "shortcut" : "GP",
    "description" : "Guadeloupe",
    "sortNr" : 9999
  }, {
    "code" : "GP",
    "language" : "en",
    "shortcut" : "GP",
    "description" : "Guadeloupe",
    "sortNr" : 9999
  }, {
    "code" : "GQ",
    "language" : "de",
    "shortcut" : "GQ",
    "description" : "Äquatorialguinea",
    "sortNr" : 9999
  }, {
    "code" : "GQ",
    "language" : "fr",
    "shortcut" : "GQ",
    "description" : "Guinée équatoriale",
    "sortNr" : 9999
  }, {
    "code" : "GQ",
    "language" : "en",
    "shortcut" : "GQ",
    "description" : "Equatorial Guinea",
    "sortNr" : 9999
  }, {
    "code" : "GR",
    "language" : "de",
    "shortcut" : "GR",
    "description" : "Griechenland",
    "sortNr" : 9999
  }, {
    "code" : "GR",
    "language" : "fr",
    "shortcut" : "GR",
    "description" : "Grèce",
    "sortNr" : 9999
  }, {
    "code" : "GR",
    "language" : "en",
    "shortcut" : "GR",
    "description" : "Greece",
    "sortNr" : 9999
  }, {
    "code" : "GS",
    "language" : "de",
    "shortcut" : "GS",
    "description" : "Südgeorgien und die Südlichen Sandwichinseln",
    "sortNr" : 9999
  }, {
    "code" : "GS",
    "language" : "fr",
    "shortcut" : "GS",
    "description" : "Géorgie du Sud-et-les Îles Sandwich du Sud",
    "sortNr" : 9999
  }, {
    "code" : "GS",
    "language" : "en",
    "shortcut" : "GS",
    "description" : "South Georgia and the south Sandwich Islands",
    "sortNr" : 9999
  }, {
    "code" : "GT",
    "language" : "de",
    "shortcut" : "GCA",
    "description" : "Guatemala",
    "sortNr" : 9999
  }, {
    "code" : "GT",
    "language" : "fr",
    "shortcut" : "GCA",
    "description" : "Guatemala",
    "sortNr" : 9999
  }, {
    "code" : "GT",
    "language" : "en",
    "shortcut" : "GCA",
    "description" : "Guatemala",
    "sortNr" : 9999
  }, {
    "code" : "GU",
    "language" : "de",
    "shortcut" : "GU",
    "description" : "Guam",
    "sortNr" : 9999
  }, {
    "code" : "GU",
    "language" : "fr",
    "shortcut" : "GU",
    "description" : "Guam",
    "sortNr" : 9999
  }, {
    "code" : "GU",
    "language" : "en",
    "shortcut" : "GU",
    "description" : "Guam",
    "sortNr" : 9999
  }, {
    "code" : "GW",
    "language" : "de",
    "shortcut" : "GNB",
    "description" : "Guinea-Bissau",
    "sortNr" : 9999
  }, {
    "code" : "GW",
    "language" : "fr",
    "shortcut" : "GNB",
    "description" : "Guinée-Bissau",
    "sortNr" : 9999
  }, {
    "code" : "GW",
    "language" : "en",
    "shortcut" : "GNB",
    "description" : "Guinea-Bissau",
    "sortNr" : 9999
  }, {
    "code" : "GY",
    "language" : "de",
    "shortcut" : "GUY",
    "description" : "Guyana",
    "sortNr" : 9999
  }, {
    "code" : "GY",
    "language" : "fr",
    "shortcut" : "GUY",
    "description" : "Guyane",
    "sortNr" : 9999
  }, {
    "code" : "GY",
    "language" : "en",
    "shortcut" : "GUY",
    "description" : "Guyana",
    "sortNr" : 9999
  }, {
    "code" : "HK",
    "language" : "de",
    "shortcut" : "HK",
    "description" : "Hongkong",
    "sortNr" : 9999
  }, {
    "code" : "HK",
    "language" : "fr",
    "shortcut" : "HK",
    "description" : "Hong Kong",
    "sortNr" : 9999
  }, {
    "code" : "HK",
    "language" : "en",
    "shortcut" : "HK",
    "description" : "Hong Kong",
    "sortNr" : 9999
  }, {
    "code" : "HM",
    "language" : "de",
    "shortcut" : "HM",
    "description" : "Heard und die McDonaldinseln",
    "sortNr" : 9999
  }, {
    "code" : "HM",
    "language" : "fr",
    "shortcut" : "HM",
    "description" : "Heard-et-Îles MacDonald, Île",
    "sortNr" : 9999
  }, {
    "code" : "HM",
    "language" : "en",
    "shortcut" : "HM",
    "description" : "Heard Island and McDonald Islands",
    "sortNr" : 9999
  }, {
    "code" : "HN",
    "language" : "de",
    "shortcut" : "HCA",
    "description" : "Honduras",
    "sortNr" : 9999
  }, {
    "code" : "HN",
    "language" : "fr",
    "shortcut" : "HCA",
    "description" : "Honduras",
    "sortNr" : 9999
  }, {
    "code" : "HN",
    "language" : "en",
    "shortcut" : "HCA",
    "description" : "Honduras",
    "sortNr" : 9999
  }, {
    "code" : "HR",
    "language" : "de",
    "shortcut" : "HR",
    "description" : "Kroatien",
    "sortNr" : 9999
  }, {
    "code" : "HR",
    "language" : "fr",
    "shortcut" : "HR",
    "description" : "Croatie",
    "sortNr" : 9999
  }, {
    "code" : "HR",
    "language" : "en",
    "shortcut" : "HR",
    "description" : "Croatia",
    "sortNr" : 9999
  }, {
    "code" : "HT",
    "language" : "de",
    "shortcut" : "RH",
    "description" : "Haiti",
    "sortNr" : 9999
  }, {
    "code" : "HT",
    "language" : "fr",
    "shortcut" : "RH",
    "description" : "Haïti",
    "sortNr" : 9999
  }, {
    "code" : "HT",
    "language" : "en",
    "shortcut" : "RH",
    "description" : "Haiti",
    "sortNr" : 9999
  }, {
    "code" : "HU",
    "language" : "de",
    "shortcut" : "H",
    "description" : "Ungarn",
    "sortNr" : 9999
  }, {
    "code" : "HU",
    "language" : "fr",
    "shortcut" : "H",
    "description" : "Hongrie",
    "sortNr" : 9999
  }, {
    "code" : "HU",
    "language" : "en",
    "shortcut" : "H",
    "description" : "Hungary",
    "sortNr" : 9999
  }, {
    "code" : "ID",
    "language" : "de",
    "shortcut" : "RI",
    "description" : "Indonesien",
    "sortNr" : 9999
  }, {
    "code" : "ID",
    "language" : "fr",
    "shortcut" : "ID",
    "description" : "Indonésie",
    "sortNr" : 9999
  }, {
    "code" : "ID",
    "language" : "en",
    "shortcut" : "ID",
    "description" : "Indonesia",
    "sortNr" : 9999
  }, {
    "code" : "IE",
    "language" : "de",
    "shortcut" : "IRL",
    "description" : "Irland",
    "sortNr" : 9999
  }, {
    "code" : "IE",
    "language" : "fr",
    "shortcut" : "IRL",
    "description" : "Irlande",
    "sortNr" : 9999
  }, {
    "code" : "IE",
    "language" : "en",
    "shortcut" : "IRL",
    "description" : "Ireland",
    "sortNr" : 9999
  }, {
    "code" : "IL",
    "language" : "de",
    "shortcut" : "IL",
    "description" : "Israel",
    "sortNr" : 9999
  }, {
    "code" : "IL",
    "language" : "fr",
    "shortcut" : "IL",
    "description" : "Israël",
    "sortNr" : 9999
  }, {
    "code" : "IL",
    "language" : "en",
    "shortcut" : "IL",
    "description" : "Israel",
    "sortNr" : 9999
  }, {
    "code" : "IM",
    "language" : "de",
    "shortcut" : "IOM",
    "description" : "Insel Man",
    "sortNr" : 9999
  }, {
    "code" : "IM",
    "language" : "fr",
    "shortcut" : "IOM",
    "description" : "Île de Man",
    "sortNr" : 9999
  }, {
    "code" : "IM",
    "language" : "en",
    "shortcut" : "IOM",
    "description" : "Isle of Man",
    "sortNr" : 9999
  }, {
    "code" : "IN",
    "language" : "de",
    "shortcut" : "IND",
    "description" : "Indien",
    "sortNr" : 9999
  }, {
    "code" : "IN",
    "language" : "fr",
    "shortcut" : "IND",
    "description" : "Inde",
    "sortNr" : 9999
  }, {
    "code" : "IN",
    "language" : "en",
    "shortcut" : "IND",
    "description" : "India",
    "sortNr" : 9999
  }, {
    "code" : "IO",
    "language" : "de",
    "shortcut" : "IO",
    "description" : "Britisches Territorium im Indischen Ozean",
    "sortNr" : 9999
  }, {
    "code" : "IO",
    "language" : "fr",
    "shortcut" : "IO",
    "description" : "Océan Indien, Territoire britannique de l'océan",
    "sortNr" : 9999
  }, {
    "code" : "IO",
    "language" : "en",
    "shortcut" : "IO",
    "description" : "British Indian Ocean Territory",
    "sortNr" : 9999
  }, {
    "code" : "IQ",
    "language" : "de",
    "shortcut" : "IRQ",
    "description" : "Irak",
    "sortNr" : 9999
  }, {
    "code" : "IQ",
    "language" : "fr",
    "shortcut" : "IRQ",
    "description" : "Iraq",
    "sortNr" : 9999
  }, {
    "code" : "IQ",
    "language" : "en",
    "shortcut" : "IRQ",
    "description" : "Iraq",
    "sortNr" : 9999
  }, {
    "code" : "IR",
    "language" : "de",
    "shortcut" : "IR",
    "description" : "Iran",
    "sortNr" : 9999
  }, {
    "code" : "IR",
    "language" : "fr",
    "shortcut" : "IR",
    "description" : "Iran (République Islamique d')",
    "sortNr" : 9999
  }, {
    "code" : "IR",
    "language" : "en",
    "shortcut" : "IR",
    "description" : "Iran, Islamic Republic of",
    "sortNr" : 9999
  }, {
    "code" : "IS",
    "language" : "de",
    "shortcut" : "IS",
    "description" : "Island",
    "sortNr" : 9999
  }, {
    "code" : "IS",
    "language" : "fr",
    "shortcut" : "IS",
    "description" : "Islande",
    "sortNr" : 9999
  }, {
    "code" : "IS",
    "language" : "en",
    "shortcut" : "IS",
    "description" : "Iceland",
    "sortNr" : 9999
  }, {
    "code" : "IT",
    "language" : "de",
    "shortcut" : "I",
    "description" : "Italien",
    "sortNr" : 9999
  }, {
    "code" : "IT",
    "language" : "fr",
    "shortcut" : "I",
    "description" : "Italie",
    "sortNr" : 9999
  }, {
    "code" : "IT",
    "language" : "en",
    "shortcut" : "I",
    "description" : "Italy",
    "sortNr" : 9999
  }, {
    "code" : "JE",
    "language" : "de",
    "shortcut" : "GBJ",
    "description" : "Jersey",
    "sortNr" : 9999
  }, {
    "code" : "JE",
    "language" : "fr",
    "shortcut" : "GBJ",
    "description" : "Jersey",
    "sortNr" : 9999
  }, {
    "code" : "JE",
    "language" : "en",
    "shortcut" : "GBJ",
    "description" : "Jersey",
    "sortNr" : 9999
  }, {
    "code" : "JM",
    "language" : "de",
    "shortcut" : "JA",
    "description" : "Jamaika",
    "sortNr" : 9999
  }, {
    "code" : "JM",
    "language" : "fr",
    "shortcut" : "JA",
    "description" : "Jamaïque",
    "sortNr" : 9999
  }, {
    "code" : "JM",
    "language" : "en",
    "shortcut" : "JA",
    "description" : "Jamaica",
    "sortNr" : 9999
  }, {
    "code" : "JO",
    "language" : "de",
    "shortcut" : "HKJ",
    "description" : "Jordanien",
    "sortNr" : 9999
  }, {
    "code" : "JO",
    "language" : "fr",
    "shortcut" : "HKJ",
    "description" : "Jordanie",
    "sortNr" : 9999
  }, {
    "code" : "JO",
    "language" : "en",
    "shortcut" : "HKJ",
    "description" : "Jordan",
    "sortNr" : 9999
  }, {
    "code" : "JP",
    "language" : "de",
    "shortcut" : "J",
    "description" : "Japan",
    "sortNr" : 9999
  }, {
    "code" : "JP",
    "language" : "fr",
    "shortcut" : "J",
    "description" : "Japon",
    "sortNr" : 9999
  }, {
    "code" : "JP",
    "language" : "en",
    "shortcut" : "J",
    "description" : "Japan",
    "sortNr" : 9999
  }, {
    "code" : "JUG",
    "language" : "de",
    "shortcut" : "ExJug",
    "description" : "Ex- Jugoslawien",
    "sortNr" : 9999
  }, {
    "code" : "JUG",
    "language" : "fr",
    "shortcut" : "ExYou",
    "description" : "Ex- Yougoslavie",
    "sortNr" : 9999
  }, {
    "code" : "JUG",
    "language" : "en",
    "shortcut" : "FoYug",
    "description" : "Former Yugoslavia",
    "sortNr" : 9999
  }, {
    "code" : "KE",
    "language" : "de",
    "shortcut" : "EAK",
    "description" : "Kenia",
    "sortNr" : 9999
  }, {
    "code" : "KE",
    "language" : "fr",
    "shortcut" : "EAK",
    "description" : "Kenya",
    "sortNr" : 9999
  }, {
    "code" : "KE",
    "language" : "en",
    "shortcut" : "EAK",
    "description" : "Kenya",
    "sortNr" : 9999
  }, {
    "code" : "KEIN",
    "language" : "de",
    "shortcut" : "Kein",
    "description" : "Keinem Domizil zuzuordnen",
    "sortNr" : 9999
  }, {
    "code" : "KEIN",
    "language" : "fr",
    "shortcut" : "Ne pa",
    "description" : "Ne pas affecter de domicile",
    "sortNr" : 9999
  }, {
    "code" : "KEIN",
    "language" : "en",
    "shortcut" : "No",
    "description" : "Do not allocate a domicile",
    "sortNr" : 9999
  }, {
    "code" : "KG",
    "language" : "de",
    "shortcut" : "KGZ",
    "description" : "Kirgisistan",
    "sortNr" : 9999
  }, {
    "code" : "KG",
    "language" : "fr",
    "shortcut" : "KGZ",
    "description" : "Kirghizistan",
    "sortNr" : 9999
  }, {
    "code" : "KG",
    "language" : "en",
    "shortcut" : "KGZ",
    "description" : "Kyrgyzstan",
    "sortNr" : 9999
  }, {
    "code" : "KH",
    "language" : "de",
    "shortcut" : "K",
    "description" : "Kambodscha",
    "sortNr" : 9999
  }, {
    "code" : "KH",
    "language" : "fr",
    "shortcut" : "K",
    "description" : "Cambodge",
    "sortNr" : 9999
  }, {
    "code" : "KH",
    "language" : "en",
    "shortcut" : "K",
    "description" : "Cambodia",
    "sortNr" : 9999
  }, {
    "code" : "KI",
    "language" : "de",
    "shortcut" : "KIR",
    "description" : "Kiribati",
    "sortNr" : 9999
  }, {
    "code" : "KI",
    "language" : "fr",
    "shortcut" : "KIR",
    "description" : "Kiribati",
    "sortNr" : 9999
  }, {
    "code" : "KI",
    "language" : "en",
    "shortcut" : "KIR",
    "description" : "Kiribati",
    "sortNr" : 9999
  }, {
    "code" : "KM",
    "language" : "de",
    "shortcut" : "COM",
    "description" : "Komoren",
    "sortNr" : 9999
  }, {
    "code" : "KM",
    "language" : "fr",
    "shortcut" : "COM",
    "description" : "Comores",
    "sortNr" : 9999
  }, {
    "code" : "KM",
    "language" : "en",
    "shortcut" : "COM",
    "description" : "Comoros",
    "sortNr" : 9999
  }, {
    "code" : "KN",
    "language" : "de",
    "shortcut" : "SCN",
    "description" : "St. Kitts und Nevis",
    "sortNr" : 9999
  }, {
    "code" : "KN",
    "language" : "fr",
    "shortcut" : "SCN",
    "description" : "Saint-Kitts-et- Nevis",
    "sortNr" : 9999
  }, {
    "code" : "KN",
    "language" : "en",
    "shortcut" : "SCN",
    "description" : "Saint Kitts and Nevis",
    "sortNr" : 9999
  }, {
    "code" : "KP",
    "language" : "de",
    "shortcut" : "KP",
    "description" : "Korea, Demokratische Volksrepublik",
    "sortNr" : 9999
  }, {
    "code" : "KP",
    "language" : "fr",
    "shortcut" : "KP",
    "description" : "Corée, République populaire démocratique de",
    "sortNr" : 9999
  }, {
    "code" : "KP",
    "language" : "en",
    "shortcut" : "KP",
    "description" : "Korea, Democratic People's Republic of",
    "sortNr" : 9999
  }, {
    "code" : "KR",
    "language" : "de",
    "shortcut" : "ROK",
    "description" : "Korea, Republik",
    "sortNr" : 9999
  }, {
    "code" : "KR",
    "language" : "fr",
    "shortcut" : "ROK",
    "description" : "Corée, République de",
    "sortNr" : 9999
  }, {
    "code" : "KR",
    "language" : "en",
    "shortcut" : "ROK",
    "description" : "Korea, Republic of",
    "sortNr" : 9999
  }, {
    "code" : "KW",
    "language" : "de",
    "shortcut" : "KWT",
    "description" : "Kuwait",
    "sortNr" : 9999
  }, {
    "code" : "KW",
    "language" : "fr",
    "shortcut" : "KWT",
    "description" : "Koweït",
    "sortNr" : 9999
  }, {
    "code" : "KW",
    "language" : "en",
    "shortcut" : "KWT",
    "description" : "Kuwait",
    "sortNr" : 9999
  }, {
    "code" : "KY",
    "language" : "de",
    "shortcut" : "KY",
    "description" : "Kaimaninseln",
    "sortNr" : 9999
  }, {
    "code" : "KY",
    "language" : "fr",
    "shortcut" : "KY",
    "description" : "Caïmans, Îles",
    "sortNr" : 9999
  }, {
    "code" : "KY",
    "language" : "en",
    "shortcut" : "KY",
    "description" : "Cayman Islands",
    "sortNr" : 9999
  }, {
    "code" : "KZ",
    "language" : "de",
    "shortcut" : "KAS",
    "description" : "Kasachstan",
    "sortNr" : 9999
  }, {
    "code" : "KZ",
    "language" : "fr",
    "shortcut" : "KAS",
    "description" : "Kazakhstan",
    "sortNr" : 9999
  }, {
    "code" : "KZ",
    "language" : "en",
    "shortcut" : "KAS",
    "description" : "Kazakhstan",
    "sortNr" : 9999
  }, {
    "code" : "LA",
    "language" : "de",
    "shortcut" : "LAO",
    "description" : "Laos, Demokratische Volksrepublik",
    "sortNr" : 9999
  }, {
    "code" : "LA",
    "language" : "fr",
    "shortcut" : "LAO",
    "description" : "Lao, République démocratique populaire",
    "sortNr" : 9999
  }, {
    "code" : "LA",
    "language" : "en",
    "shortcut" : "LAO",
    "description" : "Lao People's Democratic Republic",
    "sortNr" : 9999
  }, {
    "code" : "LB",
    "language" : "de",
    "shortcut" : "RL",
    "description" : "Libanon",
    "sortNr" : 9999
  }, {
    "code" : "LB",
    "language" : "fr",
    "shortcut" : "RL",
    "description" : "Liban",
    "sortNr" : 9999
  }, {
    "code" : "LB",
    "language" : "en",
    "shortcut" : "RL",
    "description" : "Lebanon",
    "sortNr" : 9999
  }, {
    "code" : "LC",
    "language" : "de",
    "shortcut" : "WL",
    "description" : "St. Lucia",
    "sortNr" : 9999
  }, {
    "code" : "LC",
    "language" : "fr",
    "shortcut" : "WL",
    "description" : "Sainte-Lucie",
    "sortNr" : 9999
  }, {
    "code" : "LC",
    "language" : "en",
    "shortcut" : "WL",
    "description" : "Saint Lucia",
    "sortNr" : 9999
  }, {
    "code" : "LI",
    "language" : "de",
    "shortcut" : "FL",
    "description" : "Liechtenstein",
    "sortNr" : 9999
  }, {
    "code" : "LI",
    "language" : "fr",
    "shortcut" : "FL",
    "description" : "Liechtenstein",
    "sortNr" : 9999
  }, {
    "code" : "LI",
    "language" : "en",
    "shortcut" : "FL",
    "description" : "Liechtenstein",
    "sortNr" : 9999
  }, {
    "code" : "LK",
    "language" : "de",
    "shortcut" : "CL",
    "description" : "Sri Lanka",
    "sortNr" : 9999
  }, {
    "code" : "LK",
    "language" : "fr",
    "shortcut" : "CL",
    "description" : "Sri Lanka",
    "sortNr" : 9999
  }, {
    "code" : "LK",
    "language" : "en",
    "shortcut" : "CL",
    "description" : "Sri Lanka",
    "sortNr" : 9999
  }, {
    "code" : "LR",
    "language" : "de",
    "shortcut" : "LB",
    "description" : "Liberia",
    "sortNr" : 9999
  }, {
    "code" : "LR",
    "language" : "fr",
    "shortcut" : "LB",
    "description" : "Libéria",
    "sortNr" : 9999
  }, {
    "code" : "LR",
    "language" : "en",
    "shortcut" : "LB",
    "description" : "Liberia",
    "sortNr" : 9999
  }, {
    "code" : "LS",
    "language" : "de",
    "shortcut" : "LS",
    "description" : "Lesotho",
    "sortNr" : 9999
  }, {
    "code" : "LS",
    "language" : "fr",
    "shortcut" : "LS",
    "description" : "Lesotho",
    "sortNr" : 9999
  }, {
    "code" : "LS",
    "language" : "en",
    "shortcut" : "LS",
    "description" : "Lesotho",
    "sortNr" : 9999
  }, {
    "code" : "LT",
    "language" : "de",
    "shortcut" : "LT",
    "description" : "Litauen",
    "sortNr" : 9999
  }, {
    "code" : "LT",
    "language" : "fr",
    "shortcut" : "LT",
    "description" : "Lituanie",
    "sortNr" : 9999
  }, {
    "code" : "LT",
    "language" : "en",
    "shortcut" : "LT",
    "description" : "Lithuania",
    "sortNr" : 9999
  }, {
    "code" : "LU",
    "language" : "de",
    "shortcut" : "L",
    "description" : "Luxemburg",
    "sortNr" : 9999
  }, {
    "code" : "LU",
    "language" : "fr",
    "shortcut" : "L",
    "description" : "Luxembourg",
    "sortNr" : 9999
  }, {
    "code" : "LU",
    "language" : "en",
    "shortcut" : "L",
    "description" : "Luxembourg",
    "sortNr" : 9999
  }, {
    "code" : "LV",
    "language" : "de",
    "shortcut" : "LV",
    "description" : "Lettland",
    "sortNr" : 9999
  }, {
    "code" : "LV",
    "language" : "fr",
    "shortcut" : "LV",
    "description" : "Lettonie",
    "sortNr" : 9999
  }, {
    "code" : "LV",
    "language" : "en",
    "shortcut" : "LV",
    "description" : "Latvia",
    "sortNr" : 9999
  }, {
    "code" : "LY",
    "language" : "de",
    "shortcut" : "LAR",
    "description" : "Libyen",
    "sortNr" : 9999
  }, {
    "code" : "LY",
    "language" : "fr",
    "shortcut" : "LAR",
    "description" : "Libyenne, Jamahiriya arabe",
    "sortNr" : 9999
  }, {
    "code" : "LY",
    "language" : "en",
    "shortcut" : "LAR",
    "description" : "Libyan Arab Jamahiriya",
    "sortNr" : 9999
  }, {
    "code" : "MA",
    "language" : "de",
    "shortcut" : "MA",
    "description" : "Marokko",
    "sortNr" : 9999
  }, {
    "code" : "MA",
    "language" : "fr",
    "shortcut" : "MA",
    "description" : "Maroc",
    "sortNr" : 9999
  }, {
    "code" : "MA",
    "language" : "en",
    "shortcut" : "MA",
    "description" : "Morocco",
    "sortNr" : 9999
  }, {
    "code" : "MC",
    "language" : "de",
    "shortcut" : "MC",
    "description" : "Monaco",
    "sortNr" : 9999
  }, {
    "code" : "MC",
    "language" : "fr",
    "shortcut" : "MC",
    "description" : "Monaco",
    "sortNr" : 9999
  }, {
    "code" : "MC",
    "language" : "en",
    "shortcut" : "MC",
    "description" : "Monaco",
    "sortNr" : 9999
  }, {
    "code" : "MD",
    "language" : "de",
    "shortcut" : "MOL",
    "description" : "Moldova",
    "sortNr" : 9999
  }, {
    "code" : "MD",
    "language" : "fr",
    "shortcut" : "MOL",
    "description" : "Moldava, République de",
    "sortNr" : 9999
  }, {
    "code" : "MD",
    "language" : "en",
    "shortcut" : "MOL",
    "description" : "Moldova, Republic of",
    "sortNr" : 9999
  }, {
    "code" : "ME",
    "language" : "de",
    "shortcut" : "ME",
    "description" : "Montenegro, Republik",
    "sortNr" : 9999
  }, {
    "code" : "ME",
    "language" : "fr",
    "shortcut" : "ME",
    "description" : "Monténégro, République",
    "sortNr" : 9999
  }, {
    "code" : "ME",
    "language" : "en",
    "shortcut" : "ME",
    "description" : "Montenegro",
    "sortNr" : 9999
  }, {
    "code" : "MF",
    "language" : "de",
    "shortcut" : "MF",
    "description" : "Saint Martin",
    "sortNr" : 9999
  }, {
    "code" : "MF",
    "language" : "fr",
    "shortcut" : "MF",
    "description" : "Saint Martin",
    "sortNr" : 9999
  }, {
    "code" : "MF",
    "language" : "en",
    "shortcut" : "MF",
    "description" : "Saint Martin",
    "sortNr" : 9999
  }, {
    "code" : "MG",
    "language" : "de",
    "shortcut" : "RM",
    "description" : "Madagaskar",
    "sortNr" : 9999
  }, {
    "code" : "MG",
    "language" : "fr",
    "shortcut" : "RM",
    "description" : "Madagascar",
    "sortNr" : 9999
  }, {
    "code" : "MG",
    "language" : "en",
    "shortcut" : "RM",
    "description" : "Madagascar",
    "sortNr" : 9999
  }, {
    "code" : "MH",
    "language" : "de",
    "shortcut" : "MH",
    "description" : "Marshallinseln",
    "sortNr" : 9999
  }, {
    "code" : "MH",
    "language" : "fr",
    "shortcut" : "MH",
    "description" : "Marshall, Îles",
    "sortNr" : 9999
  }, {
    "code" : "MH",
    "language" : "en",
    "shortcut" : "MH",
    "description" : "Marshall Islands",
    "sortNr" : 9999
  }, {
    "code" : "MK",
    "language" : "de",
    "shortcut" : "MK",
    "description" : "Mazedonien",
    "sortNr" : 9999
  }, {
    "code" : "MK",
    "language" : "fr",
    "shortcut" : "MK",
    "description" : "Macédoine",
    "sortNr" : 9999
  }, {
    "code" : "MK",
    "language" : "en",
    "shortcut" : "MK",
    "description" : "Macedonia",
    "sortNr" : 9999
  }, {
    "code" : "ML",
    "language" : "de",
    "shortcut" : "RMM",
    "description" : "Mali",
    "sortNr" : 9999
  }, {
    "code" : "ML",
    "language" : "fr",
    "shortcut" : "RMM",
    "description" : "Mali",
    "sortNr" : 9999
  }, {
    "code" : "ML",
    "language" : "en",
    "shortcut" : "RMM",
    "description" : "Mali",
    "sortNr" : 9999
  }, {
    "code" : "MM",
    "language" : "de",
    "shortcut" : "BUR",
    "description" : "Myanmar",
    "sortNr" : 9999
  }, {
    "code" : "MM",
    "language" : "fr",
    "shortcut" : "BUR",
    "description" : "Myanmar",
    "sortNr" : 9999
  }, {
    "code" : "MM",
    "language" : "en",
    "shortcut" : "BUR",
    "description" : "Myanmar",
    "sortNr" : 9999
  }, {
    "code" : "MN",
    "language" : "de",
    "shortcut" : "MNG",
    "description" : "Mongolei",
    "sortNr" : 9999
  }, {
    "code" : "MN",
    "language" : "fr",
    "shortcut" : "MNG",
    "description" : "Mongolie",
    "sortNr" : 9999
  }, {
    "code" : "MN",
    "language" : "en",
    "shortcut" : "MNG",
    "description" : "Mongolia",
    "sortNr" : 9999
  }, {
    "code" : "MO",
    "language" : "de",
    "shortcut" : "MO",
    "description" : "Macao",
    "sortNr" : 9999
  }, {
    "code" : "MO",
    "language" : "fr",
    "shortcut" : "MO",
    "description" : "Macao",
    "sortNr" : 9999
  }, {
    "code" : "MO",
    "language" : "en",
    "shortcut" : "MO",
    "description" : "Macao",
    "sortNr" : 9999
  }, {
    "code" : "MP",
    "language" : "de",
    "shortcut" : "MP",
    "description" : "Marianen, Nördliche",
    "sortNr" : 9999
  }, {
    "code" : "MP",
    "language" : "fr",
    "shortcut" : "MP",
    "description" : "Mariannes du Nord, Îles",
    "sortNr" : 9999
  }, {
    "code" : "MP",
    "language" : "en",
    "shortcut" : "MP",
    "description" : "Northern Mariana Islands",
    "sortNr" : 9999
  }, {
    "code" : "MQ",
    "language" : "de",
    "shortcut" : "MQ",
    "description" : "Martinique",
    "sortNr" : 9999
  }, {
    "code" : "MQ",
    "language" : "fr",
    "shortcut" : "MQ",
    "description" : "Martinique",
    "sortNr" : 9999
  }, {
    "code" : "MQ",
    "language" : "en",
    "shortcut" : "MQ",
    "description" : "Martinique",
    "sortNr" : 9999
  }, {
    "code" : "MR",
    "language" : "de",
    "shortcut" : "RIM",
    "description" : "Mauretanien",
    "sortNr" : 9999
  }, {
    "code" : "MR",
    "language" : "fr",
    "shortcut" : "RIM",
    "description" : "Mauritanie",
    "sortNr" : 9999
  }, {
    "code" : "MR",
    "language" : "en",
    "shortcut" : "RIM",
    "description" : "Mauritania",
    "sortNr" : 9999
  }, {
    "code" : "MS",
    "language" : "de",
    "shortcut" : "MS",
    "description" : "Montserrat",
    "sortNr" : 9999
  }, {
    "code" : "MS",
    "language" : "fr",
    "shortcut" : "MS",
    "description" : "Montserrat",
    "sortNr" : 9999
  }, {
    "code" : "MS",
    "language" : "en",
    "shortcut" : "MS",
    "description" : "Montserrat",
    "sortNr" : 9999
  }, {
    "code" : "MT",
    "language" : "de",
    "shortcut" : "M",
    "description" : "Malta",
    "sortNr" : 9999
  }, {
    "code" : "MT",
    "language" : "fr",
    "shortcut" : "M",
    "description" : "Malte",
    "sortNr" : 9999
  }, {
    "code" : "MT",
    "language" : "en",
    "shortcut" : "M",
    "description" : "Malta",
    "sortNr" : 9999
  }, {
    "code" : "MU",
    "language" : "de",
    "shortcut" : "MS",
    "description" : "Mauritius",
    "sortNr" : 9999
  }, {
    "code" : "MU",
    "language" : "fr",
    "shortcut" : "MS",
    "description" : "Maurice",
    "sortNr" : 9999
  }, {
    "code" : "MU",
    "language" : "en",
    "shortcut" : "MS",
    "description" : "Mauritius",
    "sortNr" : 9999
  }, {
    "code" : "MV",
    "language" : "de",
    "shortcut" : "MV",
    "description" : "Malediven",
    "sortNr" : 9999
  }, {
    "code" : "MV",
    "language" : "fr",
    "shortcut" : "MV",
    "description" : "Maldives",
    "sortNr" : 9999
  }, {
    "code" : "MV",
    "language" : "en",
    "shortcut" : "MV",
    "description" : "Maldives",
    "sortNr" : 9999
  }, {
    "code" : "MW",
    "language" : "de",
    "shortcut" : "MW",
    "description" : "Malawi",
    "sortNr" : 9999
  }, {
    "code" : "MW",
    "language" : "fr",
    "shortcut" : "MW",
    "description" : "Malawi",
    "sortNr" : 9999
  }, {
    "code" : "MW",
    "language" : "en",
    "shortcut" : "MW",
    "description" : "Malawi",
    "sortNr" : 9999
  }, {
    "code" : "MX",
    "language" : "de",
    "shortcut" : "MEX",
    "description" : "Mexiko",
    "sortNr" : 9999
  }, {
    "code" : "MX",
    "language" : "fr",
    "shortcut" : "MEX",
    "description" : "Mexique",
    "sortNr" : 9999
  }, {
    "code" : "MX",
    "language" : "en",
    "shortcut" : "MEX",
    "description" : "Mexico",
    "sortNr" : 9999
  }, {
    "code" : "MY",
    "language" : "de",
    "shortcut" : "MAL",
    "description" : "Malaysia",
    "sortNr" : 9999
  }, {
    "code" : "MY",
    "language" : "fr",
    "shortcut" : "MAL",
    "description" : "Malaisie",
    "sortNr" : 9999
  }, {
    "code" : "MY",
    "language" : "en",
    "shortcut" : "MAL",
    "description" : "Malaysia",
    "sortNr" : 9999
  }, {
    "code" : "MZ",
    "language" : "de",
    "shortcut" : "MOC",
    "description" : "Mosambik",
    "sortNr" : 9999
  }, {
    "code" : "MZ",
    "language" : "fr",
    "shortcut" : "MOC",
    "description" : "Mozambique",
    "sortNr" : 9999
  }, {
    "code" : "MZ",
    "language" : "en",
    "shortcut" : "MOC",
    "description" : "Mozambique",
    "sortNr" : 9999
  }, {
    "code" : "NA",
    "language" : "de",
    "shortcut" : "NAM",
    "description" : "Namibia",
    "sortNr" : 9999
  }, {
    "code" : "NA",
    "language" : "fr",
    "shortcut" : "NAM",
    "description" : "Namibie",
    "sortNr" : 9999
  }, {
    "code" : "NA",
    "language" : "en",
    "shortcut" : "NAM",
    "description" : "Namibia",
    "sortNr" : 9999
  }, {
    "code" : "NC",
    "language" : "de",
    "shortcut" : "NC",
    "description" : "Neukaledonien",
    "sortNr" : 9999
  }, {
    "code" : "NC",
    "language" : "fr",
    "shortcut" : "NC",
    "description" : "Nouvelle-Calédonie",
    "sortNr" : 9999
  }, {
    "code" : "NC",
    "language" : "en",
    "shortcut" : "NC",
    "description" : "New Caledonia",
    "sortNr" : 9999
  }, {
    "code" : "NE",
    "language" : "de",
    "shortcut" : "RN",
    "description" : "Niger",
    "sortNr" : 9999
  }, {
    "code" : "NE",
    "language" : "fr",
    "shortcut" : "RN",
    "description" : "Niger",
    "sortNr" : 9999
  }, {
    "code" : "NE",
    "language" : "en",
    "shortcut" : "RN",
    "description" : "Niger",
    "sortNr" : 9999
  }, {
    "code" : "NF",
    "language" : "de",
    "shortcut" : "NF",
    "description" : "Norfolkinsel",
    "sortNr" : 9999
  }, {
    "code" : "NF",
    "language" : "fr",
    "shortcut" : "NF",
    "description" : "Norfolk, Île",
    "sortNr" : 9999
  }, {
    "code" : "NF",
    "language" : "en",
    "shortcut" : "NF",
    "description" : "Norfolk Island",
    "sortNr" : 9999
  }, {
    "code" : "NG",
    "language" : "de",
    "shortcut" : "WAN",
    "description" : "Nigeria",
    "sortNr" : 9999
  }, {
    "code" : "NG",
    "language" : "fr",
    "shortcut" : "WAN",
    "description" : "Nigéria",
    "sortNr" : 9999
  }, {
    "code" : "NG",
    "language" : "en",
    "shortcut" : "WAN",
    "description" : "Nigeria",
    "sortNr" : 9999
  }, {
    "code" : "NI",
    "language" : "de",
    "shortcut" : "NIC",
    "description" : "Nicaragua",
    "sortNr" : 9999
  }, {
    "code" : "NI",
    "language" : "fr",
    "shortcut" : "NIC",
    "description" : "Nicaragua",
    "sortNr" : 9999
  }, {
    "code" : "NI",
    "language" : "en",
    "shortcut" : "NIC",
    "description" : "Nicaragua",
    "sortNr" : 9999
  }, {
    "code" : "NL",
    "language" : "de",
    "shortcut" : "NL",
    "description" : "Niederlande",
    "sortNr" : 9999
  }, {
    "code" : "NL",
    "language" : "fr",
    "shortcut" : "NL",
    "description" : "Pays-Bas",
    "sortNr" : 9999
  }, {
    "code" : "NL",
    "language" : "en",
    "shortcut" : "NL",
    "description" : "Netherlands",
    "sortNr" : 9999
  }, {
    "code" : "NO",
    "language" : "de",
    "shortcut" : "N",
    "description" : "Norwegen",
    "sortNr" : 9999
  }, {
    "code" : "NO",
    "language" : "fr",
    "shortcut" : "N",
    "description" : "Norvège",
    "sortNr" : 9999
  }, {
    "code" : "NO",
    "language" : "en",
    "shortcut" : "N",
    "description" : "Norway",
    "sortNr" : 9999
  }, {
    "code" : "NP",
    "language" : "de",
    "shortcut" : "NEP",
    "description" : "Nepal",
    "sortNr" : 9999
  }, {
    "code" : "NP",
    "language" : "fr",
    "shortcut" : "NEP",
    "description" : "Népal",
    "sortNr" : 9999
  }, {
    "code" : "NP",
    "language" : "en",
    "shortcut" : "NEP",
    "description" : "Nepal",
    "sortNr" : 9999
  }, {
    "code" : "NR",
    "language" : "de",
    "shortcut" : "NAU",
    "description" : "Nauru",
    "sortNr" : 9999
  }, {
    "code" : "NR",
    "language" : "fr",
    "shortcut" : "NAU",
    "description" : "Nauru",
    "sortNr" : 9999
  }, {
    "code" : "NR",
    "language" : "en",
    "shortcut" : "NAU",
    "description" : "Nauru",
    "sortNr" : 9999
  }, {
    "code" : "NU",
    "language" : "de",
    "shortcut" : "NU",
    "description" : "Niue",
    "sortNr" : 9999
  }, {
    "code" : "NU",
    "language" : "fr",
    "shortcut" : "NU",
    "description" : "Niue",
    "sortNr" : 9999
  }, {
    "code" : "NU",
    "language" : "en",
    "shortcut" : "NU",
    "description" : "Niue",
    "sortNr" : 9999
  }, {
    "code" : "NZ",
    "language" : "de",
    "shortcut" : "NZ",
    "description" : "Neuseeland",
    "sortNr" : 9999
  }, {
    "code" : "NZ",
    "language" : "fr",
    "shortcut" : "NZ",
    "description" : "Nouvelle-Zélande",
    "sortNr" : 9999
  }, {
    "code" : "NZ",
    "language" : "en",
    "shortcut" : "NZ",
    "description" : "New Zealand",
    "sortNr" : 9999
  }, {
    "code" : "OM",
    "language" : "de",
    "shortcut" : "OM",
    "description" : "Oman",
    "sortNr" : 9999
  }, {
    "code" : "OM",
    "language" : "fr",
    "shortcut" : "OM",
    "description" : "Oman",
    "sortNr" : 9999
  }, {
    "code" : "OM",
    "language" : "en",
    "shortcut" : "OM",
    "description" : "Oman",
    "sortNr" : 9999
  }, {
    "code" : "OeKB",
    "language" : "de",
    "shortcut" : "OeKB",
    "description" : "OeKB (Oesterreichische Kontrollbank AG)",
    "sortNr" : 9999
  }, {
    "code" : "OeKB",
    "language" : "fr",
    "shortcut" : "OeKB",
    "description" : "OeKB (Oesterreichische Kontrollbank AG)",
    "sortNr" : 9999
  }, {
    "code" : "OeKB",
    "language" : "en",
    "shortcut" : "OeKB",
    "description" : "OeKB (Oesterreichische Kontrollbank AG)",
    "sortNr" : 9999
  }, {
    "code" : "P1",
    "language" : "de",
    "shortcut" : "Eurol",
    "description" : "Euroland",
    "sortNr" : 9999
  }, {
    "code" : "P1",
    "language" : "fr",
    "shortcut" : "Eurol",
    "description" : "Zone euro",
    "sortNr" : 9999
  }, {
    "code" : "P1",
    "language" : "en",
    "shortcut" : "Eurol",
    "description" : "Euroland",
    "sortNr" : 9999
  }, {
    "code" : "P2",
    "language" : "de",
    "shortcut" : "EuexE",
    "description" : "Europa ex Euroland",
    "sortNr" : 9999
  }, {
    "code" : "P2",
    "language" : "fr",
    "shortcut" : "EuexE",
    "description" : "Europe hors zone euro",
    "sortNr" : 9999
  }, {
    "code" : "P2",
    "language" : "en",
    "shortcut" : "EuexE",
    "description" : "Europe excluding Euroland",
    "sortNr" : 9999
  }, {
    "code" : "P3",
    "language" : "de",
    "shortcut" : "NoAm",
    "description" : "Nordamerika",
    "sortNr" : 9999
  }, {
    "code" : "P3",
    "language" : "fr",
    "shortcut" : "NoAM",
    "description" : "Amérique du Nord",
    "sortNr" : 9999
  }, {
    "code" : "P3",
    "language" : "en",
    "shortcut" : "NoAm",
    "description" : "Nordamerika",
    "sortNr" : 9999
  }, {
    "code" : "P4",
    "language" : "de",
    "shortcut" : "AsPaz",
    "description" : "Asien / Pazifik",
    "sortNr" : 9999
  }, {
    "code" : "P4",
    "language" : "fr",
    "shortcut" : "AsPaz",
    "description" : "Asie / Pacifique",
    "sortNr" : 9999
  }, {
    "code" : "P4",
    "language" : "en",
    "shortcut" : "AsPaz",
    "description" : "Asia/Pacific",
    "sortNr" : 9999
  }, {
    "code" : "P5",
    "language" : "de",
    "shortcut" : "EMEUR",
    "description" : "Emerging Markets Europa & Mittlerer Osten",
    "sortNr" : 9999
  }, {
    "code" : "P5",
    "language" : "fr",
    "shortcut" : "EMEUR",
    "description" : "Marchés émergents Europe et Moyen-Orient",
    "sortNr" : 9999
  }, {
    "code" : "P5",
    "language" : "en",
    "shortcut" : "EMEUR",
    "description" : "Emerging market Europe & Middle East",
    "sortNr" : 9999
  }, {
    "code" : "P6",
    "language" : "de",
    "shortcut" : "EMASI",
    "description" : "Emerging Markets Asien",
    "sortNr" : 9999
  }, {
    "code" : "P6",
    "language" : "fr",
    "shortcut" : "EMASI",
    "description" : "Marchés émergents Asie",
    "sortNr" : 9999
  }, {
    "code" : "P6",
    "language" : "en",
    "shortcut" : "EMASI",
    "description" : "Emerging markets Asia",
    "sortNr" : 9999
  }, {
    "code" : "P7",
    "language" : "de",
    "shortcut" : "EMLat",
    "description" : "Emerging Markets Lateinamerika",
    "sortNr" : 9999
  }, {
    "code" : "P7",
    "language" : "fr",
    "shortcut" : "EMLat",
    "description" : "Marchés émergents Amérique latine",
    "sortNr" : 9999
  }, {
    "code" : "P7",
    "language" : "en",
    "shortcut" : "EMLat",
    "description" : "Emerging markets Latin America",
    "sortNr" : 9999
  }, {
    "code" : "P8",
    "language" : "de",
    "shortcut" : "EMübr",
    "description" : "Emerging Markets Übrige",
    "sortNr" : 9999
  }, {
    "code" : "P8",
    "language" : "fr",
    "shortcut" : "EMübr",
    "description" : "Autres marchés émergents",
    "sortNr" : 9999
  }, {
    "code" : "P8",
    "language" : "en",
    "shortcut" : "EMübr",
    "description" : "Emerging markets other",
    "sortNr" : 9999
  }, {
    "code" : "P9",
    "language" : "de",
    "shortcut" : "übrig",
    "description" : "Übrige",
    "sortNr" : 9999
  }, {
    "code" : "P9",
    "language" : "fr",
    "shortcut" : "übrig",
    "description" : "autres",
    "sortNr" : 9999
  }, {
    "code" : "P9",
    "language" : "en",
    "shortcut" : "übrig",
    "description" : "Other",
    "sortNr" : 9999
  }, {
    "code" : "PA",
    "language" : "de",
    "shortcut" : "PA",
    "description" : "Panama",
    "sortNr" : 9999
  }, {
    "code" : "PA",
    "language" : "fr",
    "shortcut" : "PA",
    "description" : "Panama",
    "sortNr" : 9999
  }, {
    "code" : "PA",
    "language" : "en",
    "shortcut" : "PA",
    "description" : "Panama",
    "sortNr" : 9999
  }, {
    "code" : "PE",
    "language" : "de",
    "shortcut" : "PE",
    "description" : "Peru",
    "sortNr" : 9999
  }, {
    "code" : "PE",
    "language" : "fr",
    "shortcut" : "PE",
    "description" : "Pérou",
    "sortNr" : 9999
  }, {
    "code" : "PE",
    "language" : "en",
    "shortcut" : "PE",
    "description" : "Peru",
    "sortNr" : 9999
  }, {
    "code" : "PF",
    "language" : "de",
    "shortcut" : "PF",
    "description" : "Französisch-Polynesien",
    "sortNr" : 9999
  }, {
    "code" : "PF",
    "language" : "fr",
    "shortcut" : "PF",
    "description" : "Polynésie française",
    "sortNr" : 9999
  }, {
    "code" : "PF",
    "language" : "en",
    "shortcut" : "PF",
    "description" : "French Polynesia",
    "sortNr" : 9999
  }, {
    "code" : "PG",
    "language" : "de",
    "shortcut" : "PNG",
    "description" : "Papua-Neuguinea",
    "sortNr" : 9999
  }, {
    "code" : "PG",
    "language" : "fr",
    "shortcut" : "PNG",
    "description" : "Papouasie-Nouvelle-Guinée",
    "sortNr" : 9999
  }, {
    "code" : "PG",
    "language" : "en",
    "shortcut" : "PNG",
    "description" : "Papua New Guinea",
    "sortNr" : 9999
  }, {
    "code" : "PH",
    "language" : "de",
    "shortcut" : "PH",
    "description" : "Philippinen",
    "sortNr" : 9999
  }, {
    "code" : "PH",
    "language" : "fr",
    "shortcut" : "PH",
    "description" : "Philippines",
    "sortNr" : 9999
  }, {
    "code" : "PH",
    "language" : "en",
    "shortcut" : "PH",
    "description" : "Philippines",
    "sortNr" : 9999
  }, {
    "code" : "PK",
    "language" : "de",
    "shortcut" : "PK",
    "description" : "Pakistan",
    "sortNr" : 9999
  }, {
    "code" : "PK",
    "language" : "fr",
    "shortcut" : "PK",
    "description" : "Pakistan",
    "sortNr" : 9999
  }, {
    "code" : "PK",
    "language" : "en",
    "shortcut" : "PK",
    "description" : "Pakistan",
    "sortNr" : 9999
  }, {
    "code" : "PL",
    "language" : "de",
    "shortcut" : "PL",
    "description" : "Polen",
    "sortNr" : 9999
  }, {
    "code" : "PL",
    "language" : "fr",
    "shortcut" : "PL",
    "description" : "Pologne",
    "sortNr" : 9999
  }, {
    "code" : "PL",
    "language" : "en",
    "shortcut" : "PL",
    "description" : "Poland",
    "sortNr" : 9999
  }, {
    "code" : "PM",
    "language" : "de",
    "shortcut" : "PM",
    "description" : "St. Pierre und Miquelon",
    "sortNr" : 9999
  }, {
    "code" : "PM",
    "language" : "fr",
    "shortcut" : "PM",
    "description" : "Saint-Pierre-et- Miquelon",
    "sortNr" : 9999
  }, {
    "code" : "PM",
    "language" : "en",
    "shortcut" : "PM",
    "description" : "Saint Pierre and Miquelon",
    "sortNr" : 9999
  }, {
    "code" : "PN",
    "language" : "de",
    "shortcut" : "PN",
    "description" : "Pitcairninseln",
    "sortNr" : 9999
  }, {
    "code" : "PN",
    "language" : "fr",
    "shortcut" : "PN",
    "description" : "Iles Pitcairn",
    "sortNr" : 9999
  }, {
    "code" : "PN",
    "language" : "en",
    "shortcut" : "PN",
    "description" : "Pitcairn Islands",
    "sortNr" : 9999
  }, {
    "code" : "PR",
    "language" : "de",
    "shortcut" : "PR",
    "description" : "Puerto Rico",
    "sortNr" : 9999
  }, {
    "code" : "PR",
    "language" : "fr",
    "shortcut" : "PR",
    "description" : "Porto Rico",
    "sortNr" : 9999
  }, {
    "code" : "PR",
    "language" : "en",
    "shortcut" : "PR",
    "description" : "Puerto Rico",
    "sortNr" : 9999
  }, {
    "code" : "PS",
    "language" : "de",
    "shortcut" : "PS",
    "description" : "Palestine, State of",
    "sortNr" : 9999
  }, {
    "code" : "PS",
    "language" : "fr",
    "shortcut" : "PS",
    "description" : "Palestine, État de",
    "sortNr" : 9999
  }, {
    "code" : "PS",
    "language" : "en",
    "shortcut" : "PS",
    "description" : "Palestine, State of",
    "sortNr" : 9999
  }, {
    "code" : "PT",
    "language" : "de",
    "shortcut" : "P",
    "description" : "Portugal",
    "sortNr" : 9999
  }, {
    "code" : "PT",
    "language" : "fr",
    "shortcut" : "P",
    "description" : "Portugal",
    "sortNr" : 9999
  }, {
    "code" : "PT",
    "language" : "en",
    "shortcut" : "P",
    "description" : "Portugal",
    "sortNr" : 9999
  }, {
    "code" : "PW",
    "language" : "de",
    "shortcut" : "PW",
    "description" : "Palau",
    "sortNr" : 9999
  }, {
    "code" : "PW",
    "language" : "fr",
    "shortcut" : "PW",
    "description" : "Palaos",
    "sortNr" : 9999
  }, {
    "code" : "PW",
    "language" : "en",
    "shortcut" : "PW",
    "description" : "Palau",
    "sortNr" : 9999
  }, {
    "code" : "PY",
    "language" : "de",
    "shortcut" : "PY",
    "description" : "Paraguay",
    "sortNr" : 9999
  }, {
    "code" : "PY",
    "language" : "fr",
    "shortcut" : "PY",
    "description" : "Paraguay",
    "sortNr" : 9999
  }, {
    "code" : "PY",
    "language" : "en",
    "shortcut" : "PY",
    "description" : "Paraguay",
    "sortNr" : 9999
  }, {
    "code" : "QA",
    "language" : "de",
    "shortcut" : "Q",
    "description" : "Katar",
    "sortNr" : 9999
  }, {
    "code" : "QA",
    "language" : "fr",
    "shortcut" : "Q",
    "description" : "Qatar",
    "sortNr" : 9999
  }, {
    "code" : "QA",
    "language" : "en",
    "shortcut" : "Q",
    "description" : "Qatar",
    "sortNr" : 9999
  }, {
    "code" : "RE",
    "language" : "de",
    "shortcut" : "RE",
    "description" : "Réunion",
    "sortNr" : 9999
  }, {
    "code" : "RE",
    "language" : "fr",
    "shortcut" : "RE",
    "description" : "Réunion",
    "sortNr" : 9999
  }, {
    "code" : "RE",
    "language" : "en",
    "shortcut" : "RE",
    "description" : "Réunion",
    "sortNr" : 9999
  }, {
    "code" : "RO",
    "language" : "de",
    "shortcut" : "RO",
    "description" : "Rumänien",
    "sortNr" : 9999
  }, {
    "code" : "RO",
    "language" : "fr",
    "shortcut" : "RO",
    "description" : "Roumanie",
    "sortNr" : 9999
  }, {
    "code" : "RO",
    "language" : "en",
    "shortcut" : "RO",
    "description" : "Romania",
    "sortNr" : 9999
  }, {
    "code" : "RS",
    "language" : "de",
    "shortcut" : "RS",
    "description" : "Serbien, Republik",
    "sortNr" : 9999
  }, {
    "code" : "RS",
    "language" : "fr",
    "shortcut" : "RS",
    "description" : "Sérbie, République",
    "sortNr" : 9999
  }, {
    "code" : "RS",
    "language" : "en",
    "shortcut" : "RS",
    "description" : "Serbia",
    "sortNr" : 9999
  }, {
    "code" : "RU",
    "language" : "de",
    "shortcut" : "RUS",
    "description" : "Russland",
    "sortNr" : 9999
  }, {
    "code" : "RU",
    "language" : "fr",
    "shortcut" : "RUS",
    "description" : "Russie, Fédération de",
    "sortNr" : 9999
  }, {
    "code" : "RU",
    "language" : "en",
    "shortcut" : "RUS",
    "description" : "Russian Federation",
    "sortNr" : 9999
  }, {
    "code" : "RW",
    "language" : "de",
    "shortcut" : "RWA",
    "description" : "Ruanda",
    "sortNr" : 9999
  }, {
    "code" : "RW",
    "language" : "fr",
    "shortcut" : "RWA",
    "description" : "Rwanda",
    "sortNr" : 9999
  }, {
    "code" : "RW",
    "language" : "en",
    "shortcut" : "RWA",
    "description" : "Rwanda",
    "sortNr" : 9999
  }, {
    "code" : "SA",
    "language" : "de",
    "shortcut" : "SA",
    "description" : "Saudi-Arabien",
    "sortNr" : 9999
  }, {
    "code" : "SA",
    "language" : "fr",
    "shortcut" : "AS",
    "description" : "Arabie Saoudite",
    "sortNr" : 9999
  }, {
    "code" : "SA",
    "language" : "en",
    "shortcut" : "SA",
    "description" : "Saudi Arabia",
    "sortNr" : 9999
  }, {
    "code" : "SB",
    "language" : "de",
    "shortcut" : "SB",
    "description" : "Salomoninseln",
    "sortNr" : 9999
  }, {
    "code" : "SB",
    "language" : "fr",
    "shortcut" : "SB",
    "description" : "Salomon, Îles",
    "sortNr" : 9999
  }, {
    "code" : "SB",
    "language" : "en",
    "shortcut" : "SB",
    "description" : "Solomon Islands",
    "sortNr" : 9999
  }, {
    "code" : "SC",
    "language" : "de",
    "shortcut" : "SY",
    "description" : "Seychellen",
    "sortNr" : 9999
  }, {
    "code" : "SC",
    "language" : "fr",
    "shortcut" : "SY",
    "description" : "Seychelles",
    "sortNr" : 9999
  }, {
    "code" : "SC",
    "language" : "en",
    "shortcut" : "SY",
    "description" : "Seychelles",
    "sortNr" : 9999
  }, {
    "code" : "SD",
    "language" : "de",
    "shortcut" : "SUD",
    "description" : "Sudan",
    "sortNr" : 9999
  }, {
    "code" : "SD",
    "language" : "fr",
    "shortcut" : "SUD",
    "description" : "Soudan",
    "sortNr" : 9999
  }, {
    "code" : "SD",
    "language" : "en",
    "shortcut" : "SUD",
    "description" : "Sudan",
    "sortNr" : 9999
  }, {
    "code" : "SE",
    "language" : "de",
    "shortcut" : "S",
    "description" : "Schweden",
    "sortNr" : 9999
  }, {
    "code" : "SE",
    "language" : "fr",
    "shortcut" : "S",
    "description" : "Suède",
    "sortNr" : 9999
  }, {
    "code" : "SE",
    "language" : "en",
    "shortcut" : "S",
    "description" : "Sweden",
    "sortNr" : 9999
  }, {
    "code" : "SG",
    "language" : "de",
    "shortcut" : "SGP",
    "description" : "Singapur",
    "sortNr" : 9999
  }, {
    "code" : "SG",
    "language" : "fr",
    "shortcut" : "SGP",
    "description" : "Singapour",
    "sortNr" : 9999
  }, {
    "code" : "SG",
    "language" : "en",
    "shortcut" : "SGP",
    "description" : "Singapore",
    "sortNr" : 9999
  }, {
    "code" : "SH",
    "language" : "de",
    "shortcut" : "SH",
    "description" : "St. Helena",
    "sortNr" : 9999
  }, {
    "code" : "SH",
    "language" : "fr",
    "shortcut" : "SH",
    "description" : "Sainte-Hélène",
    "sortNr" : 9999
  }, {
    "code" : "SH",
    "language" : "en",
    "shortcut" : "SH",
    "description" : "Saint Helena",
    "sortNr" : 9999
  }, {
    "code" : "SI",
    "language" : "de",
    "shortcut" : "SLO",
    "description" : "Slowenien",
    "sortNr" : 9999
  }, {
    "code" : "SI",
    "language" : "fr",
    "shortcut" : "SLO",
    "description" : "Slovénie",
    "sortNr" : 9999
  }, {
    "code" : "SI",
    "language" : "en",
    "shortcut" : "SLO",
    "description" : "Slovenia",
    "sortNr" : 9999
  }, {
    "code" : "SJ",
    "language" : "de",
    "shortcut" : "SJ",
    "description" : "Svalbard und Jan Mayen",
    "sortNr" : 9999
  }, {
    "code" : "SJ",
    "language" : "fr",
    "shortcut" : "SJ",
    "description" : "Svalbard et l'Île Jan Mayen",
    "sortNr" : 9999
  }, {
    "code" : "SJ",
    "language" : "en",
    "shortcut" : "SJ",
    "description" : "Svalbard and Jan Mayen",
    "sortNr" : 9999
  }, {
    "code" : "SK",
    "language" : "de",
    "shortcut" : "SK",
    "description" : "Slowakei",
    "sortNr" : 9999
  }, {
    "code" : "SK",
    "language" : "fr",
    "shortcut" : "SK",
    "description" : "Slovaquie",
    "sortNr" : 9999
  }, {
    "code" : "SK",
    "language" : "en",
    "shortcut" : "SK",
    "description" : "Slovakia",
    "sortNr" : 9999
  }, {
    "code" : "SL",
    "language" : "de",
    "shortcut" : "WAL",
    "description" : "Sierra Leone",
    "sortNr" : 9999
  }, {
    "code" : "SL",
    "language" : "fr",
    "shortcut" : "WAL",
    "description" : "Sierra Leone",
    "sortNr" : 9999
  }, {
    "code" : "SL",
    "language" : "en",
    "shortcut" : "WAL",
    "description" : "Sierra Leone",
    "sortNr" : 9999
  }, {
    "code" : "SM",
    "language" : "de",
    "shortcut" : "RSM",
    "description" : "San Marino",
    "sortNr" : 9999
  }, {
    "code" : "SM",
    "language" : "fr",
    "shortcut" : "RSM",
    "description" : "Saint-Marin",
    "sortNr" : 9999
  }, {
    "code" : "SM",
    "language" : "en",
    "shortcut" : "RSM",
    "description" : "San Marino",
    "sortNr" : 9999
  }, {
    "code" : "SN",
    "language" : "de",
    "shortcut" : "SN",
    "description" : "Senegal",
    "sortNr" : 9999
  }, {
    "code" : "SN",
    "language" : "fr",
    "shortcut" : "SN",
    "description" : "Sénégal",
    "sortNr" : 9999
  }, {
    "code" : "SN",
    "language" : "en",
    "shortcut" : "SN",
    "description" : "Senegal",
    "sortNr" : 9999
  }, {
    "code" : "SO",
    "language" : "de",
    "shortcut" : "SO",
    "description" : "Somalia",
    "sortNr" : 9999
  }, {
    "code" : "SO",
    "language" : "fr",
    "shortcut" : "SO",
    "description" : "Somalie",
    "sortNr" : 9999
  }, {
    "code" : "SO",
    "language" : "en",
    "shortcut" : "SO",
    "description" : "Somalia",
    "sortNr" : 9999
  }, {
    "code" : "SR",
    "language" : "de",
    "shortcut" : "SME",
    "description" : "Suriname",
    "sortNr" : 9999
  }, {
    "code" : "SR",
    "language" : "fr",
    "shortcut" : "SME",
    "description" : "Suriname",
    "sortNr" : 9999
  }, {
    "code" : "SR",
    "language" : "en",
    "shortcut" : "SME",
    "description" : "Suriname",
    "sortNr" : 9999
  }, {
    "code" : "SS",
    "language" : "de",
    "shortcut" : "SSD",
    "description" : "Südsudan",
    "sortNr" : 9999
  }, {
    "code" : "SS",
    "language" : "fr",
    "shortcut" : "SDuSu",
    "description" : "Soudan du sud",
    "sortNr" : 9999
  }, {
    "code" : "SS",
    "language" : "en",
    "shortcut" : "SSD",
    "description" : "Southern Sudan",
    "sortNr" : 9999
  }, {
    "code" : "ST",
    "language" : "de",
    "shortcut" : "STP",
    "description" : "São Tomé und Príncipe",
    "sortNr" : 9999
  }, {
    "code" : "ST",
    "language" : "fr",
    "shortcut" : "STP",
    "description" : "Sao Tomé-et- Principe",
    "sortNr" : 9999
  }, {
    "code" : "ST",
    "language" : "en",
    "shortcut" : "STP",
    "description" : "Sao Tome and Principe",
    "sortNr" : 9999
  }, {
    "code" : "SV",
    "language" : "de",
    "shortcut" : "ES",
    "description" : "El Salvador",
    "sortNr" : 9999
  }, {
    "code" : "SV",
    "language" : "fr",
    "shortcut" : "ES",
    "description" : "El Salvador",
    "sortNr" : 9999
  }, {
    "code" : "SV",
    "language" : "en",
    "shortcut" : "ES",
    "description" : "El Salvador",
    "sortNr" : 9999
  }, {
    "code" : "SX",
    "language" : "de",
    "shortcut" : "SX",
    "description" : "Sint Maarten (Dutch part)",
    "sortNr" : 9999
  }, {
    "code" : "SX",
    "language" : "fr",
    "shortcut" : "SX",
    "description" : "Sint Maarten (Dutch part)",
    "sortNr" : 9999
  }, {
    "code" : "SX",
    "language" : "en",
    "shortcut" : "SX",
    "description" : "Sint Maarten (Dutch part)",
    "sortNr" : 9999
  }, {
    "code" : "SY",
    "language" : "de",
    "shortcut" : "SYR",
    "description" : "Syrien",
    "sortNr" : 9999
  }, {
    "code" : "SY",
    "language" : "fr",
    "shortcut" : "SYR",
    "description" : "République arabe syrienne",
    "sortNr" : 9999
  }, {
    "code" : "SY",
    "language" : "en",
    "shortcut" : "SYR",
    "description" : "Syrian Arab Republic",
    "sortNr" : 9999
  }, {
    "code" : "SZ",
    "language" : "de",
    "shortcut" : "SD",
    "description" : "Swasiland",
    "sortNr" : 9999
  }, {
    "code" : "SZ",
    "language" : "fr",
    "shortcut" : "SD",
    "description" : "Swaziland",
    "sortNr" : 9999
  }, {
    "code" : "SZ",
    "language" : "en",
    "shortcut" : "SD",
    "description" : "Swaziland",
    "sortNr" : 9999
  }, {
    "code" : "TC",
    "language" : "de",
    "shortcut" : "TC",
    "description" : "Turks- und Caicosinseln",
    "sortNr" : 9999
  }, {
    "code" : "TC",
    "language" : "fr",
    "shortcut" : "TC",
    "description" : "Turks-et-Caïcos, Îles",
    "sortNr" : 9999
  }, {
    "code" : "TC",
    "language" : "en",
    "shortcut" : "TC",
    "description" : "Turks and Caicos Islands",
    "sortNr" : 9999
  }, {
    "code" : "TD",
    "language" : "de",
    "shortcut" : "TCH",
    "description" : "Tschad",
    "sortNr" : 9999
  }, {
    "code" : "TD",
    "language" : "fr",
    "shortcut" : "TCH",
    "description" : "Tchad",
    "sortNr" : 9999
  }, {
    "code" : "TD",
    "language" : "en",
    "shortcut" : "TCH",
    "description" : "Chad",
    "sortNr" : 9999
  }, {
    "code" : "TF",
    "language" : "de",
    "shortcut" : "TF",
    "description" : "Französische Süd- und Antarktisgebiete",
    "sortNr" : 9999
  }, {
    "code" : "TF",
    "language" : "fr",
    "shortcut" : "TF",
    "description" : "Terres australes françaises",
    "sortNr" : 9999
  }, {
    "code" : "TF",
    "language" : "en",
    "shortcut" : "TF",
    "description" : "French Southern Territories",
    "sortNr" : 9999
  }, {
    "code" : "TG",
    "language" : "de",
    "shortcut" : "TG",
    "description" : "Togo",
    "sortNr" : 9999
  }, {
    "code" : "TG",
    "language" : "fr",
    "shortcut" : "TG",
    "description" : "Togo",
    "sortNr" : 9999
  }, {
    "code" : "TG",
    "language" : "en",
    "shortcut" : "TG",
    "description" : "Togo",
    "sortNr" : 9999
  }, {
    "code" : "TH",
    "language" : "de",
    "shortcut" : "T",
    "description" : "Thailand",
    "sortNr" : 9999
  }, {
    "code" : "TH",
    "language" : "fr",
    "shortcut" : "T",
    "description" : "Thaïlande",
    "sortNr" : 9999
  }, {
    "code" : "TH",
    "language" : "en",
    "shortcut" : "T",
    "description" : "Thailand",
    "sortNr" : 9999
  }, {
    "code" : "TJ",
    "language" : "de",
    "shortcut" : "TJ",
    "description" : "Tadschikistan",
    "sortNr" : 9999
  }, {
    "code" : "TJ",
    "language" : "fr",
    "shortcut" : "TJ",
    "description" : "Tadjikistan",
    "sortNr" : 9999
  }, {
    "code" : "TJ",
    "language" : "en",
    "shortcut" : "TJ",
    "description" : "Tajikistan",
    "sortNr" : 9999
  }, {
    "code" : "TK",
    "language" : "de",
    "shortcut" : "TK",
    "description" : "Tokelau",
    "sortNr" : 9999
  }, {
    "code" : "TK",
    "language" : "fr",
    "shortcut" : "TK",
    "description" : "Tokelau",
    "sortNr" : 9999
  }, {
    "code" : "TK",
    "language" : "en",
    "shortcut" : "TK",
    "description" : "Tokelau",
    "sortNr" : 9999
  }, {
    "code" : "TL",
    "language" : "de",
    "shortcut" : "TLS",
    "description" : "Timor-Leste",
    "sortNr" : 9999
  }, {
    "code" : "TL",
    "language" : "fr",
    "shortcut" : "TLS",
    "description" : "Timor-Leste",
    "sortNr" : 9999
  }, {
    "code" : "TL",
    "language" : "en",
    "shortcut" : "TLS",
    "description" : "Timor-Leste",
    "sortNr" : 9999
  }, {
    "code" : "TM",
    "language" : "de",
    "shortcut" : "TM",
    "description" : "Turkmenistan",
    "sortNr" : 9999
  }, {
    "code" : "TM",
    "language" : "fr",
    "shortcut" : "TM",
    "description" : "Turkménistan",
    "sortNr" : 9999
  }, {
    "code" : "TM",
    "language" : "en",
    "shortcut" : "TM",
    "description" : "Turkmenistan",
    "sortNr" : 9999
  }, {
    "code" : "TN",
    "language" : "de",
    "shortcut" : "TN",
    "description" : "Tunesien",
    "sortNr" : 9999
  }, {
    "code" : "TN",
    "language" : "fr",
    "shortcut" : "TN",
    "description" : "Tunisie",
    "sortNr" : 9999
  }, {
    "code" : "TN",
    "language" : "en",
    "shortcut" : "TN",
    "description" : "Tunisia",
    "sortNr" : 9999
  }, {
    "code" : "TO",
    "language" : "de",
    "shortcut" : "TO",
    "description" : "Tonga",
    "sortNr" : 9999
  }, {
    "code" : "TO",
    "language" : "fr",
    "shortcut" : "TO",
    "description" : "Tonga",
    "sortNr" : 9999
  }, {
    "code" : "TO",
    "language" : "en",
    "shortcut" : "TO",
    "description" : "Tonga",
    "sortNr" : 9999
  }, {
    "code" : "TR",
    "language" : "de",
    "shortcut" : "TR",
    "description" : "Türkei",
    "sortNr" : 9999
  }, {
    "code" : "TR",
    "language" : "fr",
    "shortcut" : "TR",
    "description" : "Turquie",
    "sortNr" : 9999
  }, {
    "code" : "TR",
    "language" : "en",
    "shortcut" : "TR",
    "description" : "Turkey",
    "sortNr" : 9999
  }, {
    "code" : "TT",
    "language" : "de",
    "shortcut" : "TT",
    "description" : "Trinidad und Tobago",
    "sortNr" : 9999
  }, {
    "code" : "TT",
    "language" : "fr",
    "shortcut" : "TT",
    "description" : "Trinité-et- Tobago",
    "sortNr" : 9999
  }, {
    "code" : "TT",
    "language" : "en",
    "shortcut" : "TT",
    "description" : "Trinidad and Tobago",
    "sortNr" : 9999
  }, {
    "code" : "TV",
    "language" : "de",
    "shortcut" : "TUV",
    "description" : "Tuvalu",
    "sortNr" : 9999
  }, {
    "code" : "TV",
    "language" : "fr",
    "shortcut" : "TUV",
    "description" : "Tuvalu",
    "sortNr" : 9999
  }, {
    "code" : "TV",
    "language" : "en",
    "shortcut" : "TUV",
    "description" : "Tuvalu",
    "sortNr" : 9999
  }, {
    "code" : "TW",
    "language" : "de",
    "shortcut" : "RC",
    "description" : "Taiwan",
    "sortNr" : 9999
  }, {
    "code" : "TW",
    "language" : "fr",
    "shortcut" : "RC",
    "description" : "Taïwan, Province de Chine",
    "sortNr" : 9999
  }, {
    "code" : "TW",
    "language" : "en",
    "shortcut" : "RC",
    "description" : "Taiwan, Province of China",
    "sortNr" : 9999
  }, {
    "code" : "TZ",
    "language" : "de",
    "shortcut" : "EAT",
    "description" : "Tansania",
    "sortNr" : 9999
  }, {
    "code" : "TZ",
    "language" : "fr",
    "shortcut" : "EAT",
    "description" : "Tanzanie, République- Unie de",
    "sortNr" : 9999
  }, {
    "code" : "TZ",
    "language" : "en",
    "shortcut" : "EAT",
    "description" : "Tanzania, United Republic of",
    "sortNr" : 9999
  }, {
    "code" : "UA",
    "language" : "de",
    "shortcut" : "UA",
    "description" : "Ukraine",
    "sortNr" : 9999
  }, {
    "code" : "UA",
    "language" : "fr",
    "shortcut" : "UA",
    "description" : "Ukraine",
    "sortNr" : 9999
  }, {
    "code" : "UA",
    "language" : "en",
    "shortcut" : "UA",
    "description" : "Ukraine",
    "sortNr" : 9999
  }, {
    "code" : "UG",
    "language" : "de",
    "shortcut" : "EAU",
    "description" : "Uganda",
    "sortNr" : 9999
  }, {
    "code" : "UG",
    "language" : "fr",
    "shortcut" : "EAU",
    "description" : "Ouganda",
    "sortNr" : 9999
  }, {
    "code" : "UG",
    "language" : "en",
    "shortcut" : "EAU",
    "description" : "Uganda",
    "sortNr" : 9999
  }, {
    "code" : "UM",
    "language" : "de",
    "shortcut" : "UM",
    "description" : "Amerikanische Überseeinseln, Kleinere",
    "sortNr" : 9999
  }, {
    "code" : "UM",
    "language" : "fr",
    "shortcut" : "UM",
    "description" : "Îles mineures éloignées des États-Unis",
    "sortNr" : 9999
  }, {
    "code" : "UM",
    "language" : "en",
    "shortcut" : "UM",
    "description" : "United States Minor Outlying Islands",
    "sortNr" : 9999
  }, {
    "code" : "US",
    "language" : "de",
    "shortcut" : "USA",
    "description" : "Vereinigte Staaten von Amerika",
    "sortNr" : 9999
  }, {
    "code" : "US",
    "language" : "fr",
    "shortcut" : "USA",
    "description" : "Etats-Unis",
    "sortNr" : 9999
  }, {
    "code" : "US",
    "language" : "en",
    "shortcut" : "USA",
    "description" : "United States of America",
    "sortNr" : 9999
  }, {
    "code" : "UY",
    "language" : "de",
    "shortcut" : "ROU",
    "description" : "Uruguay",
    "sortNr" : 9999
  }, {
    "code" : "UY",
    "language" : "fr",
    "shortcut" : "ROU",
    "description" : "Uruguay",
    "sortNr" : 9999
  }, {
    "code" : "UY",
    "language" : "en",
    "shortcut" : "ROU",
    "description" : "Uruguay",
    "sortNr" : 9999
  }, {
    "code" : "UZ",
    "language" : "de",
    "shortcut" : "US",
    "description" : "Usbekistan",
    "sortNr" : 9999
  }, {
    "code" : "UZ",
    "language" : "fr",
    "shortcut" : "US",
    "description" : "Ouzbékistan",
    "sortNr" : 9999
  }, {
    "code" : "UZ",
    "language" : "en",
    "shortcut" : "US",
    "description" : "Uzbekistan",
    "sortNr" : 9999
  }, {
    "code" : "VA",
    "language" : "de",
    "shortcut" : "V",
    "description" : "Vatikanstadt",
    "sortNr" : 9999
  }, {
    "code" : "VA",
    "language" : "fr",
    "shortcut" : "V",
    "description" : "Saint-Siège (État de la Cité du Vatican)",
    "sortNr" : 9999
  }, {
    "code" : "VA",
    "language" : "en",
    "shortcut" : "V",
    "description" : "Holy See (Vatican City State)",
    "sortNr" : 9999
  }, {
    "code" : "VC",
    "language" : "de",
    "shortcut" : "WV",
    "description" : "St. Vincent und die Grenadinen",
    "sortNr" : 9999
  }, {
    "code" : "VC",
    "language" : "fr",
    "shortcut" : "WV",
    "description" : "Saint-Vincentet-et-les-Grenadines",
    "sortNr" : 9999
  }, {
    "code" : "VC",
    "language" : "en",
    "shortcut" : "WV",
    "description" : "Saint Vincent and the Grenadines",
    "sortNr" : 9999
  }, {
    "code" : "VE",
    "language" : "de",
    "shortcut" : "YV",
    "description" : "Venezuela",
    "sortNr" : 9999
  }, {
    "code" : "VE",
    "language" : "fr",
    "shortcut" : "YV",
    "description" : "Venezuela",
    "sortNr" : 9999
  }, {
    "code" : "VE",
    "language" : "en",
    "shortcut" : "YV",
    "description" : "Venezuela",
    "sortNr" : 9999
  }, {
    "code" : "VG",
    "language" : "de",
    "shortcut" : "VG",
    "description" : "Jungferninseln (UK)",
    "sortNr" : 9999
  }, {
    "code" : "VG",
    "language" : "fr",
    "shortcut" : "IVR-U",
    "description" : "Iles vierges britanniques (R.-U.)",
    "sortNr" : 9999
  }, {
    "code" : "VG",
    "language" : "en",
    "shortcut" : "VG",
    "description" : "Virgin Islands, British",
    "sortNr" : 9999
  }, {
    "code" : "VI",
    "language" : "de",
    "shortcut" : "VI",
    "description" : "Jungferninseln (US)",
    "sortNr" : 9999
  }, {
    "code" : "VI",
    "language" : "fr",
    "shortcut" : "IVAmé",
    "description" : "Iles vierges américaines (USA)",
    "sortNr" : 9999
  }, {
    "code" : "VI",
    "language" : "en",
    "shortcut" : "VI",
    "description" : "Virgin Islands, U.S.",
    "sortNr" : 9999
  }, {
    "code" : "VN",
    "language" : "de",
    "shortcut" : "VN",
    "description" : "Vietnam",
    "sortNr" : 9999
  }, {
    "code" : "VN",
    "language" : "fr",
    "shortcut" : "VN",
    "description" : "Viet Nam",
    "sortNr" : 9999
  }, {
    "code" : "VN",
    "language" : "en",
    "shortcut" : "VN",
    "description" : "Viet Nam",
    "sortNr" : 9999
  }, {
    "code" : "VU",
    "language" : "de",
    "shortcut" : "VU",
    "description" : "Vanuatu",
    "sortNr" : 9999
  }, {
    "code" : "VU",
    "language" : "fr",
    "shortcut" : "VU",
    "description" : "Vanuatu",
    "sortNr" : 9999
  }, {
    "code" : "VU",
    "language" : "en",
    "shortcut" : "VU",
    "description" : "Vanuatu",
    "sortNr" : 9999
  }, {
    "code" : "WF",
    "language" : "de",
    "shortcut" : "WF",
    "description" : "Wallis und Futuna",
    "sortNr" : 9999
  }, {
    "code" : "WF",
    "language" : "fr",
    "shortcut" : "WF",
    "description" : "Wallis-et-Futuna",
    "sortNr" : 9999
  }, {
    "code" : "WF",
    "language" : "en",
    "shortcut" : "WF",
    "description" : "Wallis and Futuna",
    "sortNr" : 9999
  }, {
    "code" : "WM",
    "language" : "de",
    "shortcut" : "Z4",
    "description" : "WM, Ersatzagentur für ISIN",
    "sortNr" : 9999
  }, {
    "code" : "WM",
    "language" : "fr",
    "shortcut" : "Z4",
    "description" : "MD, agence de remplacement de l'ISIN",
    "sortNr" : 9999
  }, {
    "code" : "WM",
    "language" : "en",
    "shortcut" : "Z4",
    "description" : "MM, replacement agency for ISIN",
    "sortNr" : 9999
  }, {
    "code" : "WS",
    "language" : "de",
    "shortcut" : "WS",
    "description" : "Samoa",
    "sortNr" : 9999
  }, {
    "code" : "WS",
    "language" : "fr",
    "shortcut" : "WS",
    "description" : "Samoa",
    "sortNr" : 9999
  }, {
    "code" : "WS",
    "language" : "en",
    "shortcut" : "WS",
    "description" : "Samoa",
    "sortNr" : 9999
  }, {
    "code" : "XK",
    "language" : "de",
    "shortcut" : "XK",
    "description" : "Kosovo",
    "sortNr" : 9999
  }, {
    "code" : "XK",
    "language" : "fr",
    "shortcut" : "XK",
    "description" : "Kosovo",
    "sortNr" : 9999
  }, {
    "code" : "XK",
    "language" : "en",
    "shortcut" : "XK",
    "description" : "Kosovo",
    "sortNr" : 9999
  }, {
    "code" : "YE",
    "language" : "de",
    "shortcut" : "YMN",
    "description" : "Jemen",
    "sortNr" : 9999
  }, {
    "code" : "YE",
    "language" : "fr",
    "shortcut" : "YMN",
    "description" : "Yémen",
    "sortNr" : 9999
  }, {
    "code" : "YE",
    "language" : "en",
    "shortcut" : "YMN",
    "description" : "Yemen",
    "sortNr" : 9999
  }, {
    "code" : "YT",
    "language" : "de",
    "shortcut" : "YT",
    "description" : "Mayotte",
    "sortNr" : 9999
  }, {
    "code" : "YT",
    "language" : "fr",
    "shortcut" : "YT",
    "description" : "Mayotte",
    "sortNr" : 9999
  }, {
    "code" : "YT",
    "language" : "en",
    "shortcut" : "YT",
    "description" : "Mayotte",
    "sortNr" : 9999
  }, {
    "code" : "YU",
    "language" : "de",
    "shortcut" : "YU",
    "description" : "Serbien und Montenegro",
    "sortNr" : 9999
  }, {
    "code" : "YU",
    "language" : "fr",
    "shortcut" : "YU",
    "description" : "Serbie et Monténégro",
    "sortNr" : 9999
  }, {
    "code" : "YU",
    "language" : "en",
    "shortcut" : "YU",
    "description" : "Serbia and Montenegro",
    "sortNr" : 9999
  }, {
    "code" : "Z1",
    "language" : "de",
    "shortcut" : "Z1",
    "description" : "Indizes/Volumen",
    "sortNr" : 9999
  }, {
    "code" : "Z1",
    "language" : "fr",
    "shortcut" : "Z1",
    "description" : "Index/volumes",
    "sortNr" : 9999
  }, {
    "code" : "Z1",
    "language" : "en",
    "shortcut" : "Z1",
    "description" : "Indices/volumes",
    "sortNr" : 9999
  }, {
    "code" : "Z2",
    "language" : "de",
    "shortcut" : "Z",
    "description" : "CUSIP",
    "sortNr" : 9999
  }, {
    "code" : "Z2",
    "language" : "fr",
    "shortcut" : "Z",
    "description" : "CUSIP",
    "sortNr" : 9999
  }, {
    "code" : "Z2",
    "language" : "en",
    "shortcut" : "Z",
    "description" : "CUSIP",
    "sortNr" : 9999
  }, {
    "code" : "Z3",
    "language" : "de",
    "shortcut" : "Z3",
    "description" : "SICOVAM, Ersatzagentur für ISIN",
    "sortNr" : 9999
  }, {
    "code" : "Z3",
    "language" : "fr",
    "shortcut" : "Z3",
    "description" : "SICOVAM, agence de remplacement pour l'ISIN",
    "sortNr" : 9999
  }, {
    "code" : "Z3",
    "language" : "en",
    "shortcut" : "Z3",
    "description" : "SICOVAM, replacement agency for ISIN",
    "sortNr" : 9999
  }, {
    "code" : "Z5",
    "language" : "de",
    "shortcut" : "Z5",
    "description" : "Telekurs, Ersatzagentur für ISIN",
    "sortNr" : 9999
  }, {
    "code" : "Z5",
    "language" : "fr",
    "shortcut" : "Z5",
    "description" : "Telekurs, agence de remplacement de l'ISIN",
    "sortNr" : 9999
  }, {
    "code" : "Z5",
    "language" : "en",
    "shortcut" : "Z5",
    "description" : "Telekurs, replacement agency for ISIN",
    "sortNr" : 9999
  }, {
    "code" : "Z6",
    "language" : "de",
    "shortcut" : "Z6",
    "description" : "Münzen und Edelmetalle",
    "sortNr" : 9999
  }, {
    "code" : "Z6",
    "language" : "fr",
    "shortcut" : "Z6",
    "description" : "Pièces et métaux précieux",
    "sortNr" : 9999
  }, {
    "code" : "Z6",
    "language" : "en",
    "shortcut" : "Z6",
    "description" : "Coins and precious metals",
    "sortNr" : 9999
  }, {
    "code" : "Z7",
    "language" : "de",
    "shortcut" : "Z7",
    "description" : "Telekurs Finanz intern",
    "sortNr" : 9999
  }, {
    "code" : "Z7",
    "language" : "fr",
    "shortcut" : "Z7",
    "description" : "Telekurs finance, interne",
    "sortNr" : 9999
  }, {
    "code" : "Z7",
    "language" : "en",
    "shortcut" : "Z7",
    "description" : "Telekurs finance internal",
    "sortNr" : 9999
  }, {
    "code" : "ZA",
    "language" : "de",
    "shortcut" : "ZA",
    "description" : "Südafrika",
    "sortNr" : 9999
  }, {
    "code" : "ZA",
    "language" : "fr",
    "shortcut" : "ZA",
    "description" : "Afrique du Sud",
    "sortNr" : 9999
  }, {
    "code" : "ZA",
    "language" : "en",
    "shortcut" : "ZA",
    "description" : "South Africa",
    "sortNr" : 9999
  }, {
    "code" : "ZM",
    "language" : "de",
    "shortcut" : "Z",
    "description" : "Sambia",
    "sortNr" : 9999
  }, {
    "code" : "ZM",
    "language" : "fr",
    "shortcut" : "Z",
    "description" : "Zambie",
    "sortNr" : 9999
  }, {
    "code" : "ZM",
    "language" : "en",
    "shortcut" : "Z",
    "description" : "Zambia",
    "sortNr" : 9999
  }, {
    "code" : "ZR",
    "language" : "de",
    "shortcut" : "ZRE",
    "description" : "Zaire",
    "sortNr" : 9999
  }, {
    "code" : "ZR",
    "language" : "fr",
    "shortcut" : "ZRE",
    "description" : "Zaïre",
    "sortNr" : 9999
  }, {
    "code" : "ZR",
    "language" : "en",
    "shortcut" : "ZRE",
    "description" : "Zaire",
    "sortNr" : 9999
  }, {
    "code" : "ZW",
    "language" : "de",
    "shortcut" : "RSR",
    "description" : "Simbabwe",
    "sortNr" : 9999
  }, {
    "code" : "ZW",
    "language" : "fr",
    "shortcut" : "RSR",
    "description" : "Zimbabwe",
    "sortNr" : 9999
  }, {
    "code" : "ZW",
    "language" : "en",
    "shortcut" : "RSR",
    "description" : "Zimbabwe",
    "sortNr" : 9999
  }, {
    "code" : "ZZ",
    "language" : "de",
    "shortcut" : "UNBEK",
    "description" : "Unbekannt/Staatenlos",
    "sortNr" : 9999
  }, {
    "code" : "ZZ",
    "language" : "fr",
    "shortcut" : "INCON",
    "description" : "Inconnu/sans Etat",
    "sortNr" : 9999
  }, {
    "code" : "ZZ",
    "language" : "en",
    "shortcut" : "UNKNO",
    "description" : "Unknown/stateless",
    "sortNr" : 9999
  } ]
