var src = src || {}
src.orderMortgageCertificates = [
	{
		"orderKey":"54530902270136",
		"mortgagecertificates":[
			{
			"key": "40913558598700",
			"propertyKey": "40913296211527",
			"nominalAmount": {
			  "amount": 120000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "01",
			"totalPriorRankingLiens": {
			  "amount": 113920000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1980-10-09",
			"totalMortgageCertificates": {
			  "amount": 114040000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			},
			{
			"key": "40913558598701",
			"propertyKey": "40913296211527",
			"nominalAmount": {
			  "amount": 1000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "02",
			"totalPriorRankingLiens": {
			  "amount": 49920000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 7680000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-06-15",
			"totalMortgageCertificates": {
			  "amount": 58600000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			},
			{
			"key": "40913558598702",
			"propertyKey": "40913296211527",
			"nominalAmount": {
			  "amount": 280000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "03",
			"totalPriorRankingLiens": {
			  "amount": 32000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 71680000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-06-15",
			"totalMortgageCertificates": {
			  "amount": 103960000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			},
			{
			"key": "40913558598703",
			"propertyKey": "40913296211527",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "04",
			"totalPriorRankingLiens": {
			  "amount": 25600000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 89600000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-06-15",
			"totalMortgageCertificates": {
			  "amount": 115300000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			},
			{
			"key": "40913558598704",
			"propertyKey": "40913296211527",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "05",
			"totalPriorRankingLiens": {
			  "amount": 19200000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 96000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-06-15",
			"totalMortgageCertificates": {
			  "amount": 115300000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			},
			{
			"key": "40913558598705",
			"propertyKey": "40913296211527",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "06",
			"totalPriorRankingLiens": {
			  "amount": 12800000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 102400000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-06-15",
			"totalMortgageCertificates": {
			  "amount": 115300000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			},
			{
			"key": "40913558598706",
			"propertyKey": "40913296211527",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "07",
			"totalPriorRankingLiens": {
			  "amount": 6400000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 108800000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-06-15",
			"totalMortgageCertificates": {
			  "amount": 115300000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			},
			{
			"key": "40913558598707",
			"propertyKey": "40913296211527",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "08",
			"totalPriorRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 115200000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-06-15",
			"totalMortgageCertificates": {
			  "amount": 115300000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			}
		]
	},
	{
		"orderKey":"62057340725463",
		"mortgagecertificates":[
			{
			"key": "40913560696404",
			"propertyKey": "40913324985400",
			"nominalAmount": {
			  "amount": 1000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "01",
			"totalPriorRankingLiens": {
			  "amount": 64000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-11-06",
			"totalMortgageCertificates": {
			  "amount": 65000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560696405",
			"propertyKey": "40913324985400",
			"nominalAmount": {
			  "amount": 400000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "02",
			"totalPriorRankingLiens": {
			  "amount": 38400000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 64000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-11-06",
			"totalMortgageCertificates": {
			  "amount": 102800000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560696406",
			"propertyKey": "40913324985400",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "03",
			"totalPriorRankingLiens": {
			  "amount": 32000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 89600000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-11-06",
			"totalMortgageCertificates": {
			  "amount": 121700000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560696407",
			"propertyKey": "40913324985400",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "04",
			"totalPriorRankingLiens": {
			  "amount": 25600000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 96000000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-11-06",
			"totalMortgageCertificates": {
			  "amount": 121700000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560696408",
			"propertyKey": "40913324985400",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "05",
			"totalPriorRankingLiens": {
			  "amount": 19200000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 102400000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-11-06",
			"totalMortgageCertificates": {
			  "amount": 121700000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560696409",
			"propertyKey": "40913324985400",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "06",
			"totalPriorRankingLiens": {
			  "amount": 12800000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 108800000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-11-06",
			"totalMortgageCertificates": {
			  "amount": 121700000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560696410",
			"propertyKey": "40913324985400",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "07",
			"totalPriorRankingLiens": {
			  "amount": 6400000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 115200000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-11-06",
			"totalMortgageCertificates": {
			  "amount": 121700000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560696411",
			"propertyKey": "40913324985400",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "08",
			"totalPriorRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 121600000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1987-11-06",
			"totalMortgageCertificates": {
			  "amount": 121700000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  }
		]
	},
	{
		"orderKey":"62964341203191",
		"mortgagecertificates":[
			{
			"key": "40913558489221",
			"propertyKey": "40913296212852",
			"nominalAmount": {
			  "amount": 40000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 6.5,
			"rank": "01",
			"totalPriorRankingLiens": {
			  "amount": 400000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1967-10-11",
			"totalMortgageCertificates": {
			  "amount": 440000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			},
			{
			"key": "40913558489222",
			"propertyKey": "40913296212852",
			"nominalAmount": {
			  "amount": 100000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 10,
			"rank": "02",
			"totalPriorRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 160000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1999-05-04",
			"totalMortgageCertificates": {
			  "amount": 260000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
			}
		]
	},
	{
		"orderKey":"59560732583955",
		"mortgagecertificates":[
			{
			"key": "40913558706352",
			"propertyKey": "40913282011500",
			"nominalAmount": {
			  "amount": 410000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 10,
			"rank": "01",
			"totalPriorRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "2001-04-30",
			"totalMortgageCertificates": {
			  "amount": 410000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  }
		]
	},
	{
		"orderKey":"59093316108491",
		"mortgagecertificates":[
			{
			"key": "40913560804934",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 8000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 6,
			"rank": "01",
			"totalPriorRankingLiens": {
			  "amount": 56943000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1922-09-26",
			"totalMortgageCertificates": {
			  "amount": 56951000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560804935",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 13000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 6,
			"rank": "02",
			"totalPriorRankingLiens": {
			  "amount": 55890000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 648000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1957-07-09",
			"totalMortgageCertificates": {
			  "amount": 56551000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560804936",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 40000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 7,
			"rank": "03",
			"totalPriorRankingLiens": {
			  "amount": 52650000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 1701000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1971-11-02",
			"totalMortgageCertificates": {
			  "amount": 54391000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560804937",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 10000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 6,
			"rank": "04",
			"totalPriorRankingLiens": {
			  "amount": 51840000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 4941000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1965-05-26",
			"totalMortgageCertificates": {
			  "amount": 56791000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560804938",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 20000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "05",
			"totalPriorRankingLiens": {
			  "amount": 50220000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 5751000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1978-07-27",
			"totalMortgageCertificates": {
			  "amount": 55991000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560804939",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 20000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 8,
			"rank": "06",
			"totalPriorRankingLiens": {
			  "amount": 48600000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 7371000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1988-11-23",
			"totalMortgageCertificates": {
			  "amount": 55991000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560804940",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 50000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 10,
			"rank": "07",
			"totalPriorRankingLiens": {
			  "amount": 44550000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 8991000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "1990-02-13",
			"totalMortgageCertificates": {
			  "amount": 53591000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "40913560804941",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 200000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 10,
			"rank": "08",
			"totalPriorRankingLiens": {
			  "amount": 28350000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 13041000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "2003-07-07",
			"totalMortgageCertificates": {
			  "amount": 41591000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  },
		  {
			"key": "43309913054734",
			"propertyKey": "40913322583453",
			"nominalAmount": {
			  "amount": 350000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 10,
			"rank": "09",
			"totalPriorRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 29241000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "2011-08-18",
			"totalMortgageCertificates": {
			  "amount": 29591000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  }
		]
	},
	{
		"orderKey":"63915860156330",
		"mortgagecertificates":[	
		]
	},
	{
		"orderKey":"52665579170713",
		"mortgagecertificates":[
			{
			"key": "40913560910244",
			"propertyKey": "40913297033235",
			"nominalAmount": {
			  "amount": 500000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"maxInterestRate": 10,
			"rank": "01",
			"totalPriorRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalEqualRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"totalLowerRankingLiens": {
			  "amount": 0,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"dateCertificate": "2009-03-10",
			"totalMortgageCertificates": {
			  "amount": 500000,
			  "currency:currency": {
				"href": "CHF"
			  },
			  "_links": {
				"curies": [
				  {
					"name": "currency",
					"href": "/v2/banks/6300/codes/Currencies/{rel}",
					"templated": true
				  }
				]
			  }
			},
			"SecurityTypes:securitiesType": {
			  "href": 418
			},
			"_links": {
			  "curies": [
				{
				  "name": "SecurityTypes",
				  "href": "/v2/banks/6300/codes/SecurityTypes/{rel}",
				  "templated": true
				}
			  ]
			}
		  }
		]
	}
]
