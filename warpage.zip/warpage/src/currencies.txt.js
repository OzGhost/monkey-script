var src = src || {}
  src.currencies = [ {
    "code" : "*07",
    "language" : "de",
    "shortcut" : "V20",
    "description" : "VREN20",
    "sortNr" : 9999
  }, {
    "code" : "*07",
    "language" : "fr",
    "shortcut" : "VREN2",
    "description" : "VREN20",
    "sortNr" : 9999
  }, {
    "code" : "*07",
    "language" : "en",
    "shortcut" : "V20",
    "description" : "VREN20",
    "sortNr" : 9999
  }, {
    "code" : "*08",
    "language" : "de",
    "shortcut" : "V10",
    "description" : "VREN10",
    "sortNr" : 9999
  }, {
    "code" : "*08",
    "language" : "fr",
    "shortcut" : "VREN1",
    "description" : "VREN10",
    "sortNr" : 9999
  }, {
    "code" : "*08",
    "language" : "en",
    "shortcut" : "V10",
    "description" : "VREN10",
    "sortNr" : 9999
  }, {
    "code" : "*30",
    "language" : "de",
    "shortcut" : "KGR",
    "description" : "KRUEGR",
    "sortNr" : 9999
  }, {
    "code" : "*30",
    "language" : "fr",
    "shortcut" : "KRUEG",
    "description" : "KRUEGR",
    "sortNr" : 9999
  }, {
    "code" : "*30",
    "language" : "en",
    "shortcut" : "KRUEG",
    "description" : "KRUEGR",
    "sortNr" : 9999
  }, {
    "code" : "*31",
    "language" : "de",
    "shortcut" : "NOB",
    "description" : "NOBLE",
    "sortNr" : 9999
  }, {
    "code" : "*31",
    "language" : "fr",
    "shortcut" : "NOBLE",
    "description" : "NOBLE",
    "sortNr" : 9999
  }, {
    "code" : "*31",
    "language" : "en",
    "shortcut" : "NOBLE",
    "description" : "NOBLE",
    "sortNr" : 9999
  }, {
    "code" : "*50",
    "language" : "de",
    "shortcut" : "DIV 1",
    "description" : "Diverse zu 1",
    "sortNr" : 9999
  }, {
    "code" : "*50",
    "language" : "fr",
    "shortcut" : "DIV 1",
    "description" : "Divers par 1",
    "sortNr" : 9999
  }, {
    "code" : "*50",
    "language" : "en",
    "shortcut" : "DIV 1",
    "description" : "DIV 1",
    "sortNr" : 9999
  }, {
    "code" : "*51",
    "language" : "de",
    "shortcut" : "DI100",
    "description" : "Diverse zu 100",
    "sortNr" : 9999
  }, {
    "code" : "*51",
    "language" : "fr",
    "shortcut" : "DI100",
    "description" : "Divers par 100",
    "sortNr" : 9999
  }, {
    "code" : "*51",
    "language" : "en",
    "shortcut" : "DI100",
    "description" : "DIV 100",
    "sortNr" : 9999
  }, {
    "code" : "903",
    "language" : "de",
    "shortcut" : "$",
    "description" : "US-Dollar (FIXKURS)",
    "sortNr" : 9999
  }, {
    "code" : "903",
    "language" : "fr",
    "shortcut" : "$",
    "description" : "Dollar américain (COURS FIXE)",
    "sortNr" : 9999
  }, {
    "code" : "903",
    "language" : "en",
    "shortcut" : "$",
    "description" : "US Dollar (FIXED RATE)",
    "sortNr" : 9999
  }, {
    "code" : "934",
    "language" : "de",
    "shortcut" : "DM£",
    "description" : "Pfund für Em.nach 1970 (FIXKURS)",
    "sortNr" : 9999
  }, {
    "code" : "934",
    "language" : "fr",
    "shortcut" : "DM£",
    "description" : "Livre pour Em. d'après 1970 (COURS FIXE)",
    "sortNr" : 9999
  }, {
    "code" : "934",
    "language" : "en",
    "shortcut" : "DM£",
    "description" : "Pound for iss.after 1970 (FIXED RATE)",
    "sortNr" : 9999
  }, {
    "code" : "ADP",
    "language" : "de",
    "shortcut" : "ADP",
    "description" : "Peseten (Andorra)",
    "sortNr" : 9999
  }, {
    "code" : "ADP",
    "language" : "fr",
    "shortcut" : "Peset",
    "description" : "Pesetas (Andorre)",
    "sortNr" : 9999
  }, {
    "code" : "ADP",
    "language" : "en",
    "shortcut" : "ADP",
    "description" : "Pesetas (Andorra)",
    "sortNr" : 9999
  }, {
    "code" : "AED",
    "language" : "de",
    "shortcut" : "AED",
    "description" : "VAE Dirham",
    "sortNr" : 9999
  }, {
    "code" : "AED",
    "language" : "fr",
    "shortcut" : "AED",
    "description" : "Dirham des Emirats arabes unis",
    "sortNr" : 9999
  }, {
    "code" : "AED",
    "language" : "en",
    "shortcut" : "AED",
    "description" : "United Arab Emirates Dirham",
    "sortNr" : 9999
  }, {
    "code" : "AEG",
    "language" : "de",
    "shortcut" : "AEG",
    "description" : "US Eagle",
    "sortNr" : 9999
  }, {
    "code" : "AEG",
    "language" : "fr",
    "shortcut" : "US Ea",
    "description" : "US Eagle",
    "sortNr" : 9999
  }, {
    "code" : "AEG",
    "language" : "en",
    "shortcut" : "USE",
    "description" : "US Eagle",
    "sortNr" : 9999
  }, {
    "code" : "AFA",
    "language" : "de",
    "shortcut" : "AFA",
    "description" : "Afghanistan Afghani",
    "sortNr" : 9999
  }, {
    "code" : "AFA",
    "language" : "fr",
    "shortcut" : "AFA",
    "description" : "Afghanistan Afghani",
    "sortNr" : 9999
  }, {
    "code" : "AFA",
    "language" : "en",
    "shortcut" : "AFA",
    "description" : "Afghanistan Afghani",
    "sortNr" : 9999
  }, {
    "code" : "AFN",
    "language" : "de",
    "shortcut" : "AFN",
    "description" : "Afghanistan Afghani",
    "sortNr" : 9999
  }, {
    "code" : "AFN",
    "language" : "fr",
    "shortcut" : "AFN",
    "description" : "Afghanistan Afghani",
    "sortNr" : 9999
  }, {
    "code" : "AFN",
    "language" : "en",
    "shortcut" : "AFN",
    "description" : "Afghanistan Afghani",
    "sortNr" : 9999
  }, {
    "code" : "AG50",
    "language" : "de",
    "shortcut" : "S1000",
    "description" : "Barren Silber 1000g",
    "sortNr" : 9999
  }, {
    "code" : "AG50",
    "language" : "fr",
    "shortcut" : "S1000",
    "description" : "Plaquette d'argent 1000g",
    "sortNr" : 9999
  }, {
    "code" : "AG50",
    "language" : "en",
    "shortcut" : "S1000",
    "description" : "Silver bar 1000g",
    "sortNr" : 9999
  }, {
    "code" : "AG52",
    "language" : "de",
    "shortcut" : "S500",
    "description" : "Barren Silber 500g",
    "sortNr" : 9999
  }, {
    "code" : "AG52",
    "language" : "fr",
    "shortcut" : "S500",
    "description" : "Plaquette d'argent 500g",
    "sortNr" : 9999
  }, {
    "code" : "AG52",
    "language" : "en",
    "shortcut" : "S500",
    "description" : "Silver bar 500g",
    "sortNr" : 9999
  }, {
    "code" : "AG53",
    "language" : "de",
    "shortcut" : "S250",
    "description" : "Barren Silber 250g",
    "sortNr" : 9999
  }, {
    "code" : "AG53",
    "language" : "fr",
    "shortcut" : "S250",
    "description" : "Plaquette d'argent 250g",
    "sortNr" : 9999
  }, {
    "code" : "AG53",
    "language" : "en",
    "shortcut" : "S250",
    "description" : "Silver bar 250g",
    "sortNr" : 9999
  }, {
    "code" : "ALL",
    "language" : "de",
    "shortcut" : "LEK",
    "description" : "Albanischer Lek",
    "sortNr" : 9999
  }, {
    "code" : "ALL",
    "language" : "fr",
    "shortcut" : "LEK",
    "description" : "Albanie Lek",
    "sortNr" : 9999
  }, {
    "code" : "ALL",
    "language" : "en",
    "shortcut" : "LEK",
    "description" : "Albania Lek",
    "sortNr" : 9999
  }, {
    "code" : "AMD",
    "language" : "de",
    "shortcut" : "AMD",
    "description" : "Armenien Dram",
    "sortNr" : 9999
  }, {
    "code" : "AMD",
    "language" : "fr",
    "shortcut" : "AMD",
    "description" : "Armenien Dram",
    "sortNr" : 9999
  }, {
    "code" : "AMD",
    "language" : "en",
    "shortcut" : "AMD",
    "description" : "Armenien Dram",
    "sortNr" : 9999
  }, {
    "code" : "ANG",
    "language" : "de",
    "shortcut" : "ANG",
    "description" : "Niederländische Antillen Gulden",
    "sortNr" : 9999
  }, {
    "code" : "ANG",
    "language" : "fr",
    "shortcut" : "ANG",
    "description" : "Florin des Antilles néerlandaises",
    "sortNr" : 9999
  }, {
    "code" : "ANG",
    "language" : "en",
    "shortcut" : "ANG",
    "description" : "Niederländische Antillen Gulden",
    "sortNr" : 9999
  }, {
    "code" : "AOA",
    "language" : "de",
    "shortcut" : "AOA",
    "description" : "Angolan Kwanza",
    "sortNr" : 9999
  }, {
    "code" : "AOA",
    "language" : "fr",
    "shortcut" : "AOA",
    "description" : "Angolan Kwanza",
    "sortNr" : 9999
  }, {
    "code" : "AOA",
    "language" : "en",
    "shortcut" : "AOA",
    "description" : "Angolan Kwanza",
    "sortNr" : 9999
  }, {
    "code" : "ARS",
    "language" : "de",
    "shortcut" : "ARS",
    "description" : "Argentinischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "ARS",
    "language" : "fr",
    "shortcut" : "ARS",
    "description" : "Argentinischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "ARS",
    "language" : "en",
    "shortcut" : "ARS",
    "description" : "Argentinischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "ATS",
    "language" : "de",
    "shortcut" : "ATS",
    "description" : "Schilling (Oesterreich)",
    "sortNr" : 9999
  }, {
    "code" : "ATS",
    "language" : "fr",
    "shortcut" : "ATS",
    "description" : "Schilling autriche",
    "sortNr" : 9999
  }, {
    "code" : "ATS",
    "language" : "en",
    "shortcut" : "ATS",
    "description" : "Schilling",
    "sortNr" : 9999
  }, {
    "code" : "AU50",
    "language" : "de",
    "shortcut" : "G1000",
    "description" : "Barren Gold 1000g",
    "sortNr" : 9999
  }, {
    "code" : "AU50",
    "language" : "fr",
    "shortcut" : "G1000",
    "description" : "Plaquette d'or 1000g",
    "sortNr" : 9999
  }, {
    "code" : "AU50",
    "language" : "en",
    "shortcut" : "G1000",
    "description" : "Gold bar 1000g",
    "sortNr" : 9999
  }, {
    "code" : "AU52",
    "language" : "de",
    "shortcut" : "G500",
    "description" : "Barren Gold 500g",
    "sortNr" : 9999
  }, {
    "code" : "AU52",
    "language" : "fr",
    "shortcut" : "G500",
    "description" : "Plaquette d'or 500g",
    "sortNr" : 9999
  }, {
    "code" : "AU52",
    "language" : "en",
    "shortcut" : "G500",
    "description" : "Gold bar 500g",
    "sortNr" : 9999
  }, {
    "code" : "AU53",
    "language" : "de",
    "shortcut" : "G250",
    "description" : "Barren Gold 250g",
    "sortNr" : 9999
  }, {
    "code" : "AU53",
    "language" : "fr",
    "shortcut" : "G250",
    "description" : "Plaquette d'or 250g",
    "sortNr" : 9999
  }, {
    "code" : "AU53",
    "language" : "en",
    "shortcut" : "G250",
    "description" : "Gold bar 250g",
    "sortNr" : 9999
  }, {
    "code" : "AU54",
    "language" : "de",
    "shortcut" : "G100",
    "description" : "Barren Gold 100g",
    "sortNr" : 9999
  }, {
    "code" : "AU54",
    "language" : "fr",
    "shortcut" : "G100",
    "description" : "Plaquette d'or 100g",
    "sortNr" : 9999
  }, {
    "code" : "AU54",
    "language" : "en",
    "shortcut" : "G100",
    "description" : "Gold bar 100g",
    "sortNr" : 9999
  }, {
    "code" : "AU55",
    "language" : "de",
    "shortcut" : "G50",
    "description" : "Barren Gold 50g",
    "sortNr" : 9999
  }, {
    "code" : "AU55",
    "language" : "fr",
    "shortcut" : "G50",
    "description" : "Plaquette d'or 50g",
    "sortNr" : 9999
  }, {
    "code" : "AU55",
    "language" : "en",
    "shortcut" : "G50",
    "description" : "Gold bar 50g",
    "sortNr" : 9999
  }, {
    "code" : "AU56",
    "language" : "de",
    "shortcut" : "G20",
    "description" : "Barren Gold 20g",
    "sortNr" : 9999
  }, {
    "code" : "AU56",
    "language" : "fr",
    "shortcut" : "G20",
    "description" : "Plaquette d'or 20g",
    "sortNr" : 9999
  }, {
    "code" : "AU56",
    "language" : "en",
    "shortcut" : "G20",
    "description" : "Gold bar 20g",
    "sortNr" : 9999
  }, {
    "code" : "AU57",
    "language" : "de",
    "shortcut" : "G10",
    "description" : "Barren Gold 10g",
    "sortNr" : 9999
  }, {
    "code" : "AU57",
    "language" : "fr",
    "shortcut" : "G10",
    "description" : "Plaquette d'or 10g",
    "sortNr" : 9999
  }, {
    "code" : "AU57",
    "language" : "en",
    "shortcut" : "G10",
    "description" : "Gold bar 10g",
    "sortNr" : 9999
  }, {
    "code" : "AU58",
    "language" : "de",
    "shortcut" : "G5",
    "description" : "Barren Gold 5g",
    "sortNr" : 9999
  }, {
    "code" : "AU58",
    "language" : "fr",
    "shortcut" : "G5",
    "description" : "Plaquette d'or 5g",
    "sortNr" : 9999
  }, {
    "code" : "AU58",
    "language" : "en",
    "shortcut" : "G5",
    "description" : "Gold bar 5g",
    "sortNr" : 9999
  }, {
    "code" : "AU59",
    "language" : "de",
    "shortcut" : "G2.5",
    "description" : "Barren Gold 2.5g",
    "sortNr" : 9999
  }, {
    "code" : "AU59",
    "language" : "fr",
    "shortcut" : "G2.5",
    "description" : "Plaquette d'or 2.5g",
    "sortNr" : 9999
  }, {
    "code" : "AU59",
    "language" : "en",
    "shortcut" : "G2.5",
    "description" : "Gold bar 2.5g",
    "sortNr" : 9999
  }, {
    "code" : "AU60",
    "language" : "de",
    "shortcut" : "G2",
    "description" : "Barren Gold 2g",
    "sortNr" : 9999
  }, {
    "code" : "AU60",
    "language" : "fr",
    "shortcut" : "G2",
    "description" : "Plaquette d'or 2g",
    "sortNr" : 9999
  }, {
    "code" : "AU60",
    "language" : "en",
    "shortcut" : "G2",
    "description" : "Gold bar 2g",
    "sortNr" : 9999
  }, {
    "code" : "AU61",
    "language" : "de",
    "shortcut" : "G1",
    "description" : "Barren Gold 1g",
    "sortNr" : 9999
  }, {
    "code" : "AU61",
    "language" : "fr",
    "shortcut" : "G1",
    "description" : "Plaquette d'or 1g",
    "sortNr" : 9999
  }, {
    "code" : "AU61",
    "language" : "en",
    "shortcut" : "G1",
    "description" : "Gold bar 1g",
    "sortNr" : 9999
  }, {
    "code" : "AU62",
    "language" : "de",
    "shortcut" : "OZG1",
    "description" : "Barren Gold 1 Unze",
    "sortNr" : 9999
  }, {
    "code" : "AU62",
    "language" : "fr",
    "shortcut" : "OZG1",
    "description" : "Plaquette d'or 1 once",
    "sortNr" : 9999
  }, {
    "code" : "AU62",
    "language" : "en",
    "shortcut" : "OZG1",
    "description" : "Gold bar 1 ounce",
    "sortNr" : 9999
  }, {
    "code" : "AUD",
    "language" : "de",
    "shortcut" : "AUD",
    "description" : "Australischer Dollar",
    "sortNr" : 9999
  }, {
    "code" : "AUD",
    "language" : "fr",
    "shortcut" : "AUD",
    "description" : "Dollar australien",
    "sortNr" : 9999
  }, {
    "code" : "AUD",
    "language" : "en",
    "shortcut" : "AUD",
    "description" : "Australian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "AWG",
    "language" : "de",
    "shortcut" : "AWG",
    "description" : "Aruba Florin",
    "sortNr" : 9999
  }, {
    "code" : "AWG",
    "language" : "fr",
    "shortcut" : "AWG",
    "description" : "Aruba Florin",
    "sortNr" : 9999
  }, {
    "code" : "AWG",
    "language" : "en",
    "shortcut" : "AWG",
    "description" : "Aruba Florin",
    "sortNr" : 9999
  }, {
    "code" : "AZN",
    "language" : "de",
    "shortcut" : "AZN",
    "description" : "Azerbaijan New Manat",
    "sortNr" : 9999
  }, {
    "code" : "AZN",
    "language" : "fr",
    "shortcut" : "AZN",
    "description" : "Azerbaijan New Manat",
    "sortNr" : 9999
  }, {
    "code" : "AZN",
    "language" : "en",
    "shortcut" : "AZN",
    "description" : "Azerbaijan New Manat",
    "sortNr" : 9999
  }, {
    "code" : "BAM",
    "language" : "de",
    "shortcut" : "BAM",
    "description" : "Bosnien Herzegowina Konvertierbare Mark",
    "sortNr" : 9999
  }, {
    "code" : "BAM",
    "language" : "fr",
    "shortcut" : "BAM",
    "description" : "Bosnien Herzegowina Konvertierbare Mark",
    "sortNr" : 9999
  }, {
    "code" : "BAM",
    "language" : "en",
    "shortcut" : "BAM",
    "description" : "Bosnien Herzegowina Konvertierbare Mark",
    "sortNr" : 9999
  }, {
    "code" : "BBD",
    "language" : "de",
    "shortcut" : "BBD",
    "description" : "Barbadian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BBD",
    "language" : "fr",
    "shortcut" : "BBD",
    "description" : "Barbadian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BBD",
    "language" : "en",
    "shortcut" : "BBD",
    "description" : "Barbadian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BDT",
    "language" : "de",
    "shortcut" : "BDT",
    "description" : "Bangladesch Taka",
    "sortNr" : 9999
  }, {
    "code" : "BDT",
    "language" : "fr",
    "shortcut" : "BDT",
    "description" : "Bangladesch Taka",
    "sortNr" : 9999
  }, {
    "code" : "BDT",
    "language" : "en",
    "shortcut" : "BDT",
    "description" : "Bangladesch Taka",
    "sortNr" : 9999
  }, {
    "code" : "BEF",
    "language" : "de",
    "shortcut" : "BEF",
    "description" : "Franc (Belgien)",
    "sortNr" : 9999
  }, {
    "code" : "BEF",
    "language" : "fr",
    "shortcut" : "BEF",
    "description" : "Francs Belges",
    "sortNr" : 9999
  }, {
    "code" : "BEF",
    "language" : "en",
    "shortcut" : "BEF",
    "description" : "Belgian Franc",
    "sortNr" : 9999
  }, {
    "code" : "BGN",
    "language" : "de",
    "shortcut" : "BGN",
    "description" : "Bulgarien Lewa",
    "sortNr" : 9999
  }, {
    "code" : "BGN",
    "language" : "fr",
    "shortcut" : "BGN",
    "description" : "Bulgarien Lewa",
    "sortNr" : 9999
  }, {
    "code" : "BGN",
    "language" : "en",
    "shortcut" : "BGN",
    "description" : "Bulgarien Lewa",
    "sortNr" : 9999
  }, {
    "code" : "BHD",
    "language" : "de",
    "shortcut" : "BHD",
    "description" : "Bahrain Dinar",
    "sortNr" : 9999
  }, {
    "code" : "BHD",
    "language" : "fr",
    "shortcut" : "BHD",
    "description" : "Bahrain Dinar",
    "sortNr" : 9999
  }, {
    "code" : "BHD",
    "language" : "en",
    "shortcut" : "BHD",
    "description" : "Bahrain Dinar",
    "sortNr" : 9999
  }, {
    "code" : "BIF",
    "language" : "de",
    "shortcut" : "BIF",
    "description" : "Burundian Franc",
    "sortNr" : 9999
  }, {
    "code" : "BIF",
    "language" : "fr",
    "shortcut" : "BIF",
    "description" : "Burundian Franc",
    "sortNr" : 9999
  }, {
    "code" : "BIF",
    "language" : "en",
    "shortcut" : "BIF",
    "description" : "Burundian Franc",
    "sortNr" : 9999
  }, {
    "code" : "BMD",
    "language" : "de",
    "shortcut" : "BMD",
    "description" : "Bermuda Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BMD",
    "language" : "fr",
    "shortcut" : "BMD",
    "description" : "Bermuda Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BMD",
    "language" : "en",
    "shortcut" : "BMD",
    "description" : "Bermuda Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BND",
    "language" : "de",
    "shortcut" : "BND",
    "description" : "Brunei Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BND",
    "language" : "fr",
    "shortcut" : "BND",
    "description" : "Brunei Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BND",
    "language" : "en",
    "shortcut" : "BND",
    "description" : "Brunei Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BOB",
    "language" : "de",
    "shortcut" : "BOB",
    "description" : "Bolivianischer Boliviano",
    "sortNr" : 9999
  }, {
    "code" : "BOB",
    "language" : "fr",
    "shortcut" : "BOB",
    "description" : "Bolivianischer Boliviano",
    "sortNr" : 9999
  }, {
    "code" : "BOB",
    "language" : "en",
    "shortcut" : "BOB",
    "description" : "Bolivianischer Boliviano",
    "sortNr" : 9999
  }, {
    "code" : "BOV",
    "language" : "de",
    "shortcut" : "BOV",
    "description" : "Mvdol (Bolivien)",
    "sortNr" : 9999
  }, {
    "code" : "BOV",
    "language" : "fr",
    "shortcut" : "BOV",
    "description" : "Mvdol (Bolivie)",
    "sortNr" : 9999
  }, {
    "code" : "BOV",
    "language" : "en",
    "shortcut" : "BOV",
    "description" : "Mvdol (Bolivia)",
    "sortNr" : 9999
  }, {
    "code" : "BRL",
    "language" : "de",
    "shortcut" : "BRL",
    "description" : "Brasilianischer Real",
    "sortNr" : 9999
  }, {
    "code" : "BRL",
    "language" : "fr",
    "shortcut" : "BRL",
    "description" : "Brasilianischer Real",
    "sortNr" : 9999
  }, {
    "code" : "BRL",
    "language" : "en",
    "shortcut" : "BRL",
    "description" : "Brasilianischer Real",
    "sortNr" : 9999
  }, {
    "code" : "BSD",
    "language" : "de",
    "shortcut" : "BSD",
    "description" : "Bahamian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BSD",
    "language" : "fr",
    "shortcut" : "BSD",
    "description" : "Bahamian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BSD",
    "language" : "en",
    "shortcut" : "BSD",
    "description" : "Bahamian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BTN",
    "language" : "de",
    "shortcut" : "BTN",
    "description" : "Bhutan Ngultrum",
    "sortNr" : 9999
  }, {
    "code" : "BTN",
    "language" : "fr",
    "shortcut" : "BTN",
    "description" : "Bhutan Ngultrum",
    "sortNr" : 9999
  }, {
    "code" : "BTN",
    "language" : "en",
    "shortcut" : "BTN",
    "description" : "Bhutan Ngultrum",
    "sortNr" : 9999
  }, {
    "code" : "BWP",
    "language" : "de",
    "shortcut" : "BWP",
    "description" : "Botswana Pula",
    "sortNr" : 9999
  }, {
    "code" : "BWP",
    "language" : "fr",
    "shortcut" : "BWP",
    "description" : "Botswana Pula",
    "sortNr" : 9999
  }, {
    "code" : "BWP",
    "language" : "en",
    "shortcut" : "BWP",
    "description" : "Botswana Pula",
    "sortNr" : 9999
  }, {
    "code" : "BYN",
    "language" : "de",
    "shortcut" : "BYN",
    "description" : "Weissrussischer Rubel Neu",
    "sortNr" : 9999
  }, {
    "code" : "BYN",
    "language" : "fr",
    "shortcut" : "BYN",
    "description" : "Rouble biélorusse Nouveau",
    "sortNr" : 9999
  }, {
    "code" : "BYN",
    "language" : "en",
    "shortcut" : "BYN",
    "description" : "Belarusian ruble New",
    "sortNr" : 9999
  }, {
    "code" : "BYR",
    "language" : "de",
    "shortcut" : "BYR",
    "description" : "Weissrussischer Rubel",
    "sortNr" : 9999
  }, {
    "code" : "BYR",
    "language" : "fr",
    "shortcut" : "BYR",
    "description" : "Rouble biélorusse",
    "sortNr" : 9999
  }, {
    "code" : "BYR",
    "language" : "en",
    "shortcut" : "BYR",
    "description" : "Belarusian ruble",
    "sortNr" : 9999
  }, {
    "code" : "BZD",
    "language" : "de",
    "shortcut" : "BZD",
    "description" : "Belize Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BZD",
    "language" : "fr",
    "shortcut" : "BZD",
    "description" : "Belize Dollar",
    "sortNr" : 9999
  }, {
    "code" : "BZD",
    "language" : "en",
    "shortcut" : "BZD",
    "description" : "Belize Dollar",
    "sortNr" : 9999
  }, {
    "code" : "CAD",
    "language" : "de",
    "shortcut" : "CAD",
    "description" : "Kanadischer Dollar",
    "sortNr" : 110
  }, {
    "code" : "CAD",
    "language" : "fr",
    "shortcut" : "CAD",
    "description" : "Dollar canadien",
    "sortNr" : 110
  }, {
    "code" : "CAD",
    "language" : "en",
    "shortcut" : "CAD",
    "description" : "Canadian Dollar",
    "sortNr" : 110
  }, {
    "code" : "CDF",
    "language" : "de",
    "shortcut" : "CDF",
    "description" : "Kongolesischer Franc",
    "sortNr" : 9999
  }, {
    "code" : "CDF",
    "language" : "fr",
    "shortcut" : "CDF",
    "description" : "Kongolesischer Franc",
    "sortNr" : 9999
  }, {
    "code" : "CDF",
    "language" : "en",
    "shortcut" : "CDF",
    "description" : "Kongolesischer Franc",
    "sortNr" : 9999
  }, {
    "code" : "CHF",
    "language" : "de",
    "shortcut" : "CHF",
    "description" : "Schweizer Franken",
    "sortNr" : 1
  }, {
    "code" : "CHF",
    "language" : "fr",
    "shortcut" : "CHF",
    "description" : "Franc Suisse",
    "sortNr" : 1
  }, {
    "code" : "CHF",
    "language" : "en",
    "shortcut" : "CHF",
    "description" : "Swiss francs",
    "sortNr" : 1
  }, {
    "code" : "CLF",
    "language" : "de",
    "shortcut" : "CLF",
    "description" : "Chile Unidad de Fomento",
    "sortNr" : 9999
  }, {
    "code" : "CLF",
    "language" : "fr",
    "shortcut" : "CLF",
    "description" : "Chile Unidad de Fomento",
    "sortNr" : 9999
  }, {
    "code" : "CLF",
    "language" : "en",
    "shortcut" : "CLF",
    "description" : "Chile Unidad de Fomento",
    "sortNr" : 9999
  }, {
    "code" : "CLP",
    "language" : "de",
    "shortcut" : "CLP",
    "description" : "Chilenischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "CLP",
    "language" : "fr",
    "shortcut" : "CLP",
    "description" : "Chilenischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "CLP",
    "language" : "en",
    "shortcut" : "CLP",
    "description" : "Chilenischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "CNH",
    "language" : "de",
    "shortcut" : "CNH",
    "description" : "Offshore Renminbi Yuan",
    "sortNr" : 9999
  }, {
    "code" : "CNH",
    "language" : "fr",
    "shortcut" : "CNH",
    "description" : "Offshore Renminbi Yuan",
    "sortNr" : 9999
  }, {
    "code" : "CNH",
    "language" : "en",
    "shortcut" : "CNH",
    "description" : "Offshore Renminbi Yuan",
    "sortNr" : 9999
  }, {
    "code" : "CNY",
    "language" : "de",
    "shortcut" : "CNY",
    "description" : "Chinesischer Renminbi Yuan",
    "sortNr" : 260
  }, {
    "code" : "CNY",
    "language" : "fr",
    "shortcut" : "CNY",
    "description" : "Chinesischer Renminbi Yuan",
    "sortNr" : 260
  }, {
    "code" : "CNY",
    "language" : "en",
    "shortcut" : "CNY",
    "description" : "Chinesischer Renminbi Yuan",
    "sortNr" : 260
  }, {
    "code" : "COP",
    "language" : "de",
    "shortcut" : "COP",
    "description" : "Kolumbianischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "COP",
    "language" : "fr",
    "shortcut" : "COP",
    "description" : "Kolumbianischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "COP",
    "language" : "en",
    "shortcut" : "COP",
    "description" : "Kolumbianischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "COU",
    "language" : "de",
    "shortcut" : "COU",
    "description" : "Kolumbien Unidad-De-Valor-Real",
    "sortNr" : 9999
  }, {
    "code" : "COU",
    "language" : "fr",
    "shortcut" : "COU",
    "description" : "Kolumbien Unidad-De-Valor-Real",
    "sortNr" : 9999
  }, {
    "code" : "COU",
    "language" : "en",
    "shortcut" : "COU",
    "description" : "Kolumbien Unidad-De-Valor-Real",
    "sortNr" : 9999
  }, {
    "code" : "CRC",
    "language" : "de",
    "shortcut" : "CRC",
    "description" : "Costa Rica Colon",
    "sortNr" : 9999
  }, {
    "code" : "CRC",
    "language" : "fr",
    "shortcut" : "CRC",
    "description" : "Costa Rica Colon",
    "sortNr" : 9999
  }, {
    "code" : "CRC",
    "language" : "en",
    "shortcut" : "CRC",
    "description" : "Costa Rica Colon",
    "sortNr" : 9999
  }, {
    "code" : "CSD",
    "language" : "de",
    "shortcut" : "CSD",
    "description" : "serbischer Dinar (alt)",
    "sortNr" : 9999
  }, {
    "code" : "CSD",
    "language" : "fr",
    "shortcut" : "CSD",
    "description" : "Dinar Serbe",
    "sortNr" : 9999
  }, {
    "code" : "CSD",
    "language" : "en",
    "shortcut" : "CSD",
    "description" : "Serbian dinar (old)",
    "sortNr" : 9999
  }, {
    "code" : "CUC",
    "language" : "de",
    "shortcut" : "CUC",
    "description" : "Kuba Peso Convertible",
    "sortNr" : 9999
  }, {
    "code" : "CUC",
    "language" : "fr",
    "shortcut" : "CUC",
    "description" : "Kuba Peso Convertible",
    "sortNr" : 9999
  }, {
    "code" : "CUC",
    "language" : "en",
    "shortcut" : "CUC",
    "description" : "Kuba Peso Convertible",
    "sortNr" : 9999
  }, {
    "code" : "CUP",
    "language" : "de",
    "shortcut" : "CUP",
    "description" : "Kubanischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "CUP",
    "language" : "fr",
    "shortcut" : "CUP",
    "description" : "Kubanischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "CUP",
    "language" : "en",
    "shortcut" : "CUP",
    "description" : "Kubanischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "CVE",
    "language" : "de",
    "shortcut" : "CVE",
    "description" : "Cape Verdean Escudo",
    "sortNr" : 9999
  }, {
    "code" : "CVE",
    "language" : "fr",
    "shortcut" : "CVE",
    "description" : "Cape Verdean Escudo",
    "sortNr" : 9999
  }, {
    "code" : "CVE",
    "language" : "en",
    "shortcut" : "CVE",
    "description" : "Cape Verdean Escudo",
    "sortNr" : 9999
  }, {
    "code" : "CYP",
    "language" : "de",
    "shortcut" : "CYP",
    "description" : "CYP",
    "sortNr" : 9999
  }, {
    "code" : "CYP",
    "language" : "fr",
    "shortcut" : "CYP",
    "description" : "CYP",
    "sortNr" : 9999
  }, {
    "code" : "CYP",
    "language" : "en",
    "shortcut" : "CYP",
    "description" : "CYP",
    "sortNr" : 9999
  }, {
    "code" : "CZK",
    "language" : "de",
    "shortcut" : "CZK",
    "description" : "Tschechische Krone",
    "sortNr" : 280
  }, {
    "code" : "CZK",
    "language" : "fr",
    "shortcut" : "CZK",
    "description" : "Couronne tchèque",
    "sortNr" : 280
  }, {
    "code" : "CZK",
    "language" : "en",
    "shortcut" : "CZK",
    "description" : "Czech Koruny",
    "sortNr" : 280
  }, {
    "code" : "DDM",
    "language" : "de",
    "shortcut" : "DDM",
    "description" : "Mark der DDR",
    "sortNr" : 9999
  }, {
    "code" : "DDM",
    "language" : "fr",
    "shortcut" : "DDM",
    "description" : "Mark de la RDA",
    "sortNr" : 9999
  }, {
    "code" : "DDM",
    "language" : "en",
    "shortcut" : "GDM",
    "description" : "GDR Mark",
    "sortNr" : 9999
  }, {
    "code" : "DEG",
    "language" : "de",
    "shortcut" : "DEG",
    "description" : "Double Eagle",
    "sortNr" : 9999
  }, {
    "code" : "DEG",
    "language" : "fr",
    "shortcut" : "Doubl",
    "description" : "Double Eagle",
    "sortNr" : 9999
  }, {
    "code" : "DEG",
    "language" : "en",
    "shortcut" : "DEG",
    "description" : "Double Eagle",
    "sortNr" : 9999
  }, {
    "code" : "DEM",
    "language" : "de",
    "shortcut" : "DEM",
    "description" : "Mark (Deutschland)",
    "sortNr" : 9999
  }, {
    "code" : "DEM",
    "language" : "fr",
    "shortcut" : "DEM",
    "description" : "Mark allemand",
    "sortNr" : 9999
  }, {
    "code" : "DEM",
    "language" : "en",
    "shortcut" : "DEM",
    "description" : "German mark",
    "sortNr" : 9999
  }, {
    "code" : "DJF",
    "language" : "de",
    "shortcut" : "DJF",
    "description" : "Djiboutian Franc",
    "sortNr" : 9999
  }, {
    "code" : "DJF",
    "language" : "fr",
    "shortcut" : "DJF",
    "description" : "Djiboutian Franc",
    "sortNr" : 9999
  }, {
    "code" : "DJF",
    "language" : "en",
    "shortcut" : "DJF",
    "description" : "Djiboutian Franc",
    "sortNr" : 9999
  }, {
    "code" : "DKK",
    "language" : "de",
    "shortcut" : "DKK",
    "description" : "Dänische Krone",
    "sortNr" : 50
  }, {
    "code" : "DKK",
    "language" : "fr",
    "shortcut" : "DKK",
    "description" : "Couronne danoise",
    "sortNr" : 50
  }, {
    "code" : "DKK",
    "language" : "en",
    "shortcut" : "DKK",
    "description" : "Danish Kroner",
    "sortNr" : 50
  }, {
    "code" : "DOP",
    "language" : "de",
    "shortcut" : "DOP",
    "description" : "Dominikanischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "DOP",
    "language" : "fr",
    "shortcut" : "DOP",
    "description" : "Peso dominicain",
    "sortNr" : 9999
  }, {
    "code" : "DOP",
    "language" : "en",
    "shortcut" : "DOM",
    "description" : "Dominikanischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "DZD",
    "language" : "de",
    "shortcut" : "DIN",
    "description" : "Algerian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "DZD",
    "language" : "fr",
    "shortcut" : "DIN",
    "description" : "Algerian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "DZD",
    "language" : "en",
    "shortcut" : "DIN",
    "description" : "Algerian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "ECV",
    "language" : "de",
    "shortcut" : "ECV",
    "description" : "Ecuador Unidad de Valor Constante",
    "sortNr" : 9999
  }, {
    "code" : "ECV",
    "language" : "fr",
    "shortcut" : "ECV",
    "description" : "Ecuador Unidad de Valor Constante",
    "sortNr" : 9999
  }, {
    "code" : "ECV",
    "language" : "en",
    "shortcut" : "ECV",
    "description" : "Ecuador Unidad de Valor Constante",
    "sortNr" : 9999
  }, {
    "code" : "EEK",
    "language" : "de",
    "shortcut" : "EEK",
    "description" : "Estische Kronen",
    "sortNr" : 9999
  }, {
    "code" : "EEK",
    "language" : "fr",
    "shortcut" : "EEK",
    "description" : "Estische Kronen",
    "sortNr" : 9999
  }, {
    "code" : "EEK",
    "language" : "en",
    "shortcut" : "EEK",
    "description" : "Estische Kronen",
    "sortNr" : 9999
  }, {
    "code" : "EGP",
    "language" : "de",
    "shortcut" : "EGP",
    "description" : "Ägyptisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "EGP",
    "language" : "fr",
    "shortcut" : "EGP",
    "description" : "Livre égyptienne",
    "sortNr" : 9999
  }, {
    "code" : "EGP",
    "language" : "en",
    "shortcut" : "EGP",
    "description" : "Egyptian Pound",
    "sortNr" : 9999
  }, {
    "code" : "ERN",
    "language" : "de",
    "shortcut" : "NAK",
    "description" : "Eritrea Nakfa",
    "sortNr" : 9999
  }, {
    "code" : "ERN",
    "language" : "fr",
    "shortcut" : "NAK",
    "description" : "Eritrea Nakfa",
    "sortNr" : 9999
  }, {
    "code" : "ERN",
    "language" : "en",
    "shortcut" : "NAK",
    "description" : "Eritrea Nakfa",
    "sortNr" : 9999
  }, {
    "code" : "ESP",
    "language" : "de",
    "shortcut" : "ESP",
    "description" : "Peseta (Spanien)",
    "sortNr" : 9999
  }, {
    "code" : "ESP",
    "language" : "fr",
    "shortcut" : "ESP",
    "description" : "Pesetas espagnoles",
    "sortNr" : 9999
  }, {
    "code" : "ESP",
    "language" : "en",
    "shortcut" : "ESP",
    "description" : "Spanish Peseta",
    "sortNr" : 9999
  }, {
    "code" : "ETB",
    "language" : "de",
    "shortcut" : "ETB",
    "description" : "Äthiopien Birr",
    "sortNr" : 9999
  }, {
    "code" : "ETB",
    "language" : "fr",
    "shortcut" : "ETB",
    "description" : "Äthiopien Birr",
    "sortNr" : 9999
  }, {
    "code" : "ETB",
    "language" : "en",
    "shortcut" : "ETB",
    "description" : "Äthiopien Birr",
    "sortNr" : 9999
  }, {
    "code" : "EUR",
    "language" : "de",
    "shortcut" : "EUR",
    "description" : "Euro",
    "sortNr" : 9999
  }, {
    "code" : "EUR",
    "language" : "fr",
    "shortcut" : "EUR",
    "description" : "Euro",
    "sortNr" : 9999
  }, {
    "code" : "EUR",
    "language" : "en",
    "shortcut" : "EUR",
    "description" : "Euro",
    "sortNr" : 9999
  }, {
    "code" : "FIM",
    "language" : "de",
    "shortcut" : "FIM",
    "description" : "Markkas (Finnland)",
    "sortNr" : 9999
  }, {
    "code" : "FIM",
    "language" : "fr",
    "shortcut" : "FIM",
    "description" : "Marks Finlandais",
    "sortNr" : 9999
  }, {
    "code" : "FIM",
    "language" : "en",
    "shortcut" : "FIM",
    "description" : "Finnish markka",
    "sortNr" : 9999
  }, {
    "code" : "FJD",
    "language" : "de",
    "shortcut" : "FJD",
    "description" : "Fidschi Dollar",
    "sortNr" : 9999
  }, {
    "code" : "FJD",
    "language" : "fr",
    "shortcut" : "FJD",
    "description" : "Fidschi Dollar",
    "sortNr" : 9999
  }, {
    "code" : "FJD",
    "language" : "en",
    "shortcut" : "FJD",
    "description" : "Fidschi Dollar",
    "sortNr" : 9999
  }, {
    "code" : "FJX",
    "language" : "de",
    "shortcut" : "FJD",
    "description" : "Fidschi Dollar",
    "sortNr" : 9999
  }, {
    "code" : "FJX",
    "language" : "fr",
    "shortcut" : "FJD",
    "description" : "Dollar des Iles Fidji",
    "sortNr" : 9999
  }, {
    "code" : "FJX",
    "language" : "en",
    "shortcut" : "FJD",
    "description" : "Fiji dollar",
    "sortNr" : 9999
  }, {
    "code" : "FKP",
    "language" : "de",
    "shortcut" : "FKP",
    "description" : "Fakland Pfund",
    "sortNr" : 9999
  }, {
    "code" : "FKP",
    "language" : "fr",
    "shortcut" : "FKP",
    "description" : "Fakland Pfund",
    "sortNr" : 9999
  }, {
    "code" : "FKP",
    "language" : "en",
    "shortcut" : "FKP",
    "description" : "Fakland Pfund",
    "sortNr" : 9999
  }, {
    "code" : "FRF",
    "language" : "de",
    "shortcut" : "FRF",
    "description" : "Franc (Frankreich)",
    "sortNr" : 9999
  }, {
    "code" : "FRF",
    "language" : "fr",
    "shortcut" : "FRF",
    "description" : "Francs francais",
    "sortNr" : 9999
  }, {
    "code" : "FRF",
    "language" : "en",
    "shortcut" : "FRF",
    "description" : "French franc",
    "sortNr" : 9999
  }, {
    "code" : "GBP",
    "language" : "de",
    "shortcut" : "GBP",
    "description" : "Pfund Sterling",
    "sortNr" : 9999
  }, {
    "code" : "GBP",
    "language" : "fr",
    "shortcut" : "GBP",
    "description" : "Livre sterling",
    "sortNr" : 9999
  }, {
    "code" : "GBP",
    "language" : "en",
    "shortcut" : "GBP",
    "description" : "Pound sterling",
    "sortNr" : 9999
  }, {
    "code" : "GDK",
    "language" : "de",
    "shortcut" : "GDK",
    "description" : "Gedenkmünzen",
    "sortNr" : 9999
  }, {
    "code" : "GDK",
    "language" : "fr",
    "shortcut" : "Pièce",
    "description" : "Pièces de commémoration",
    "sortNr" : 9999
  }, {
    "code" : "GDK",
    "language" : "en",
    "shortcut" : "CCN",
    "description" : "Commemorative coins",
    "sortNr" : 9999
  }, {
    "code" : "GEL",
    "language" : "de",
    "shortcut" : "GEL",
    "description" : "Georgian Lari",
    "sortNr" : 9999
  }, {
    "code" : "GEL",
    "language" : "fr",
    "shortcut" : "GEL",
    "description" : "Georgian Lari",
    "sortNr" : 9999
  }, {
    "code" : "GEL",
    "language" : "en",
    "shortcut" : "GEL",
    "description" : "Georgian Lari",
    "sortNr" : 9999
  }, {
    "code" : "GHC",
    "language" : "de",
    "shortcut" : "GHC",
    "description" : "Ghana Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GHC",
    "language" : "fr",
    "shortcut" : "GHC",
    "description" : "Ghana Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GHC",
    "language" : "en",
    "shortcut" : "GHC",
    "description" : "Ghana Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GHP",
    "language" : "de",
    "shortcut" : "GHP",
    "description" : "Ghana Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GHP",
    "language" : "fr",
    "shortcut" : "GHP",
    "description" : "Ghana Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GHP",
    "language" : "en",
    "shortcut" : "GHP",
    "description" : "Ghana Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GHS",
    "language" : "de",
    "shortcut" : "GHS",
    "description" : "Ghanaian Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GHS",
    "language" : "fr",
    "shortcut" : "GHS",
    "description" : "Ghanaian Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GHS",
    "language" : "en",
    "shortcut" : "GHS",
    "description" : "Ghanaian Cedi",
    "sortNr" : 9999
  }, {
    "code" : "GIP",
    "language" : "de",
    "shortcut" : "GIP",
    "description" : "Gibraltar Pfund",
    "sortNr" : 9999
  }, {
    "code" : "GIP",
    "language" : "fr",
    "shortcut" : "GIP",
    "description" : "Gibraltar Pfund",
    "sortNr" : 9999
  }, {
    "code" : "GIP",
    "language" : "en",
    "shortcut" : "GIP",
    "description" : "Gibraltar Pfund",
    "sortNr" : 9999
  }, {
    "code" : "GMD",
    "language" : "de",
    "shortcut" : "GMD",
    "description" : "Gambian Dalasi",
    "sortNr" : 9999
  }, {
    "code" : "GMD",
    "language" : "fr",
    "shortcut" : "GMD",
    "description" : "Gambian Dalasi",
    "sortNr" : 9999
  }, {
    "code" : "GMD",
    "language" : "en",
    "shortcut" : "GMD",
    "description" : "Gambian Dalasi",
    "sortNr" : 9999
  }, {
    "code" : "GMZ",
    "language" : "de",
    "shortcut" : "GMZ",
    "description" : "Div. Goldmünzen",
    "sortNr" : 9999
  }, {
    "code" : "GMZ",
    "language" : "fr",
    "shortcut" : "Diver",
    "description" : "Div. pièces d'or",
    "sortNr" : 9999
  }, {
    "code" : "GMZ",
    "language" : "en",
    "shortcut" : "VGC",
    "description" : "Various gold coins",
    "sortNr" : 9999
  }, {
    "code" : "GNF",
    "language" : "de",
    "shortcut" : "GNF",
    "description" : "Guinean Franc",
    "sortNr" : 9999
  }, {
    "code" : "GNF",
    "language" : "fr",
    "shortcut" : "GNF",
    "description" : "Guinean Franc",
    "sortNr" : 9999
  }, {
    "code" : "GNF",
    "language" : "en",
    "shortcut" : "GNF",
    "description" : "Guinean Franc",
    "sortNr" : 9999
  }, {
    "code" : "GPA",
    "language" : "de",
    "shortcut" : "GPA",
    "description" : "Palladium Gramm",
    "sortNr" : 860
  }, {
    "code" : "GPA",
    "language" : "fr",
    "shortcut" : "GPA",
    "description" : "Palladium gramme",
    "sortNr" : 860
  }, {
    "code" : "GPA",
    "language" : "en",
    "shortcut" : "GPA",
    "description" : "Palladium grams",
    "sortNr" : 860
  }, {
    "code" : "GPL",
    "language" : "de",
    "shortcut" : "GPL",
    "description" : "Platin Gramm",
    "sortNr" : 840
  }, {
    "code" : "GPL",
    "language" : "fr",
    "shortcut" : "GPL",
    "description" : "Platine gramme",
    "sortNr" : 840
  }, {
    "code" : "GPL",
    "language" : "en",
    "shortcut" : "GPL",
    "description" : "Platinum grams",
    "sortNr" : 840
  }, {
    "code" : "GRD",
    "language" : "de",
    "shortcut" : "DR.",
    "description" : "Drachme (Griechenland)",
    "sortNr" : 9999
  }, {
    "code" : "GRD",
    "language" : "fr",
    "shortcut" : "DR -",
    "description" : "DR - Drawn units",
    "sortNr" : 9999
  }, {
    "code" : "GRD",
    "language" : "en",
    "shortcut" : "GRD",
    "description" : "Greek drachma",
    "sortNr" : 9999
  }, {
    "code" : "GRG",
    "language" : "de",
    "shortcut" : "GRG",
    "description" : "Gold Gramm",
    "sortNr" : 800
  }, {
    "code" : "GRG",
    "language" : "fr",
    "shortcut" : "GRG",
    "description" : "Or gramme",
    "sortNr" : 800
  }, {
    "code" : "GRG",
    "language" : "en",
    "shortcut" : "GRG",
    "description" : "Gold grams",
    "sortNr" : 800
  }, {
    "code" : "GRS",
    "language" : "de",
    "shortcut" : "GRS",
    "description" : "Silber Gramm",
    "sortNr" : 820
  }, {
    "code" : "GRS",
    "language" : "fr",
    "shortcut" : "GRS",
    "description" : "Argent gramme",
    "sortNr" : 820
  }, {
    "code" : "GRS",
    "language" : "en",
    "shortcut" : "GRS",
    "description" : "Silver grams",
    "sortNr" : 820
  }, {
    "code" : "GTQ",
    "language" : "de",
    "shortcut" : "GTQ",
    "description" : "Guatemalan Quetzal",
    "sortNr" : 9999
  }, {
    "code" : "GTQ",
    "language" : "fr",
    "shortcut" : "GTQ",
    "description" : "Guatemalan Quetzal",
    "sortNr" : 9999
  }, {
    "code" : "GTQ",
    "language" : "en",
    "shortcut" : "GTQ",
    "description" : "Guatemalan Quetzal",
    "sortNr" : 9999
  }, {
    "code" : "GYD",
    "language" : "de",
    "shortcut" : "GYD",
    "description" : "Guyanese Dollar",
    "sortNr" : 9999
  }, {
    "code" : "GYD",
    "language" : "fr",
    "shortcut" : "GYD",
    "description" : "Guyanese Dollar",
    "sortNr" : 9999
  }, {
    "code" : "GYD",
    "language" : "en",
    "shortcut" : "GYD",
    "description" : "Guyanese Dollar",
    "sortNr" : 9999
  }, {
    "code" : "H20",
    "language" : "de",
    "shortcut" : "H20",
    "description" : "Helvetia CHF 20",
    "sortNr" : 9999
  }, {
    "code" : "H20",
    "language" : "fr",
    "shortcut" : "H20",
    "description" : "Helvetia CHF 20",
    "sortNr" : 9999
  }, {
    "code" : "H20",
    "language" : "en",
    "shortcut" : "H20",
    "description" : "Helvetia CHF 20",
    "sortNr" : 9999
  }, {
    "code" : "HKD",
    "language" : "de",
    "shortcut" : "HKD",
    "description" : "Hongkong-Dollar",
    "sortNr" : 130
  }, {
    "code" : "HKD",
    "language" : "fr",
    "shortcut" : "HKD",
    "description" : "Dollar de Hongkong",
    "sortNr" : 130
  }, {
    "code" : "HKD",
    "language" : "en",
    "shortcut" : "HKD",
    "description" : "Hong Kong Dollar",
    "sortNr" : 130
  }, {
    "code" : "HNL",
    "language" : "de",
    "shortcut" : "HNL",
    "description" : "Honduran Lempira",
    "sortNr" : 9999
  }, {
    "code" : "HNL",
    "language" : "fr",
    "shortcut" : "HNL",
    "description" : "Honduran Lempira",
    "sortNr" : 9999
  }, {
    "code" : "HNL",
    "language" : "en",
    "shortcut" : "HNL",
    "description" : "Honduran Lempira",
    "sortNr" : 9999
  }, {
    "code" : "HRK",
    "language" : "de",
    "shortcut" : "HRK",
    "description" : "Kroatische Kuna",
    "sortNr" : 9999
  }, {
    "code" : "HRK",
    "language" : "fr",
    "shortcut" : "HRK",
    "description" : "Kuna croate",
    "sortNr" : 9999
  }, {
    "code" : "HRK",
    "language" : "en",
    "shortcut" : "HRK",
    "description" : "Croatian Kuna",
    "sortNr" : 9999
  }, {
    "code" : "HTG",
    "language" : "de",
    "shortcut" : "HTG",
    "description" : "Haitian Gourde",
    "sortNr" : 9999
  }, {
    "code" : "HTG",
    "language" : "fr",
    "shortcut" : "HTG",
    "description" : "Haitian Gourde",
    "sortNr" : 9999
  }, {
    "code" : "HTG",
    "language" : "en",
    "shortcut" : "HTG",
    "description" : "Haitian Gourde",
    "sortNr" : 9999
  }, {
    "code" : "HUF",
    "language" : "de",
    "shortcut" : "HUF",
    "description" : "Ungarischer Forint",
    "sortNr" : 320
  }, {
    "code" : "HUF",
    "language" : "fr",
    "shortcut" : "HUF",
    "description" : "Forint hongrois",
    "sortNr" : 320
  }, {
    "code" : "HUF",
    "language" : "en",
    "shortcut" : "HUF",
    "description" : "Hungarian forint",
    "sortNr" : 320
  }, {
    "code" : "IDR",
    "language" : "de",
    "shortcut" : "IDR",
    "description" : "Indonesische Rupiah",
    "sortNr" : 310
  }, {
    "code" : "IDR",
    "language" : "fr",
    "shortcut" : "IDR",
    "description" : "Rupiah indonésien",
    "sortNr" : 310
  }, {
    "code" : "IDR",
    "language" : "en",
    "shortcut" : "IDR",
    "description" : "Indonesische Rupiah",
    "sortNr" : 310
  }, {
    "code" : "IEP",
    "language" : "de",
    "shortcut" : "IEP",
    "description" : "Pfund (Irland)",
    "sortNr" : 9999
  }, {
    "code" : "IEP",
    "language" : "fr",
    "shortcut" : "IEP",
    "description" : "Livres irlandaises",
    "sortNr" : 9999
  }, {
    "code" : "IEP",
    "language" : "en",
    "shortcut" : "IEP",
    "description" : "Irish punt",
    "sortNr" : 9999
  }, {
    "code" : "ILS",
    "language" : "de",
    "shortcut" : "ILS",
    "description" : "Israelische Schekel",
    "sortNr" : 9999
  }, {
    "code" : "ILS",
    "language" : "fr",
    "shortcut" : "ILS",
    "description" : "Shekel de Israël",
    "sortNr" : 9999
  }, {
    "code" : "ILS",
    "language" : "en",
    "shortcut" : "ILS",
    "description" : "Israeli new Shekel",
    "sortNr" : 9999
  }, {
    "code" : "INR",
    "language" : "de",
    "shortcut" : "INR",
    "description" : "Indische Rupie",
    "sortNr" : 9999
  }, {
    "code" : "INR",
    "language" : "fr",
    "shortcut" : "INR",
    "description" : "Roupie indienne",
    "sortNr" : 9999
  }, {
    "code" : "INR",
    "language" : "en",
    "shortcut" : "INR",
    "description" : "Indische Rupie",
    "sortNr" : 9999
  }, {
    "code" : "IQD",
    "language" : "de",
    "shortcut" : "IQD",
    "description" : "Iraqi Dinar",
    "sortNr" : 9999
  }, {
    "code" : "IQD",
    "language" : "fr",
    "shortcut" : "IQD",
    "description" : "Iraqi Dinar",
    "sortNr" : 9999
  }, {
    "code" : "IQD",
    "language" : "en",
    "shortcut" : "IQD",
    "description" : "Iraqi Dinar",
    "sortNr" : 9999
  }, {
    "code" : "IRR",
    "language" : "de",
    "shortcut" : "IRR",
    "description" : "Iran Rial",
    "sortNr" : 9999
  }, {
    "code" : "IRR",
    "language" : "fr",
    "shortcut" : "IRR",
    "description" : "Iran Rial",
    "sortNr" : 9999
  }, {
    "code" : "IRR",
    "language" : "en",
    "shortcut" : "IRR",
    "description" : "Iran Rial",
    "sortNr" : 9999
  }, {
    "code" : "ISK",
    "language" : "de",
    "shortcut" : "ISK",
    "description" : "Isländische Krone",
    "sortNr" : 80
  }, {
    "code" : "ISK",
    "language" : "fr",
    "shortcut" : "ISK",
    "description" : "Couronne islandaise",
    "sortNr" : 80
  }, {
    "code" : "ISK",
    "language" : "en",
    "shortcut" : "ISK",
    "description" : "ISK",
    "sortNr" : 80
  }, {
    "code" : "ITL",
    "language" : "de",
    "shortcut" : "ITL",
    "description" : "Lira (Italien)",
    "sortNr" : 9999
  }, {
    "code" : "ITL",
    "language" : "fr",
    "shortcut" : "ITL",
    "description" : "Lires italiennes",
    "sortNr" : 9999
  }, {
    "code" : "ITL",
    "language" : "en",
    "shortcut" : "ITL",
    "description" : "Italian lira",
    "sortNr" : 9999
  }, {
    "code" : "JMD",
    "language" : "de",
    "shortcut" : "JMD",
    "description" : "Jamaika-Dollar",
    "sortNr" : 9999
  }, {
    "code" : "JMD",
    "language" : "fr",
    "shortcut" : "JMD",
    "description" : "Dollar de la Jamaïque",
    "sortNr" : 9999
  }, {
    "code" : "JMD",
    "language" : "en",
    "shortcut" : "JMD",
    "description" : "Jamaika Dollar",
    "sortNr" : 9999
  }, {
    "code" : "JOD",
    "language" : "de",
    "shortcut" : "JOD",
    "description" : "Jordanian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "JOD",
    "language" : "fr",
    "shortcut" : "JOD",
    "description" : "Jordanian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "JOD",
    "language" : "en",
    "shortcut" : "JOD",
    "description" : "Jordanian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "JPY",
    "language" : "de",
    "shortcut" : "JPY",
    "description" : "Japanischer Yen",
    "sortNr" : 90
  }, {
    "code" : "JPY",
    "language" : "fr",
    "shortcut" : "JPY",
    "description" : "Yen japonais",
    "sortNr" : 90
  }, {
    "code" : "JPY",
    "language" : "en",
    "shortcut" : "JPY",
    "description" : "Japanese Yen",
    "sortNr" : 90
  }, {
    "code" : "KES",
    "language" : "de",
    "shortcut" : "KES",
    "description" : "Kenyan Shilling",
    "sortNr" : 9999
  }, {
    "code" : "KES",
    "language" : "fr",
    "shortcut" : "KES",
    "description" : "Kenyan Shilling",
    "sortNr" : 9999
  }, {
    "code" : "KES",
    "language" : "en",
    "shortcut" : "KES",
    "description" : "Kenyan Shilling",
    "sortNr" : 9999
  }, {
    "code" : "KGG",
    "language" : "de",
    "shortcut" : "KGG",
    "description" : "Gold Kilogramm",
    "sortNr" : 9999
  }, {
    "code" : "KGG",
    "language" : "fr",
    "shortcut" : "KGG",
    "description" : "Or Kilogramme",
    "sortNr" : 9999
  }, {
    "code" : "KGG",
    "language" : "en",
    "shortcut" : "KGG",
    "description" : "Gold kilogram",
    "sortNr" : 9999
  }, {
    "code" : "KGS",
    "language" : "de",
    "shortcut" : "KGS",
    "description" : "Kirgisischer Som",
    "sortNr" : 9999
  }, {
    "code" : "KGS",
    "language" : "fr",
    "shortcut" : "KGS",
    "description" : "Som Kirghize",
    "sortNr" : 9999
  }, {
    "code" : "KGS",
    "language" : "en",
    "shortcut" : "KGS",
    "description" : "Kyrgyzstan Som",
    "sortNr" : 9999
  }, {
    "code" : "KHR",
    "language" : "de",
    "shortcut" : "RIE",
    "description" : "Cambodian Riel",
    "sortNr" : 9999
  }, {
    "code" : "KHR",
    "language" : "fr",
    "shortcut" : "RIE",
    "description" : "Cambodian Riel",
    "sortNr" : 9999
  }, {
    "code" : "KHR",
    "language" : "en",
    "shortcut" : "RIE",
    "description" : "Cambodian Riel",
    "sortNr" : 9999
  }, {
    "code" : "KMF",
    "language" : "de",
    "shortcut" : "KMF",
    "description" : "Komoren Franc",
    "sortNr" : 9999
  }, {
    "code" : "KMF",
    "language" : "fr",
    "shortcut" : "KMF",
    "description" : "Komoren Franc",
    "sortNr" : 9999
  }, {
    "code" : "KMF",
    "language" : "en",
    "shortcut" : "KMF",
    "description" : "Komoren Franc",
    "sortNr" : 9999
  }, {
    "code" : "KPA",
    "language" : "de",
    "shortcut" : "KPA",
    "description" : "Palladium Kilo",
    "sortNr" : 9999
  }, {
    "code" : "KPA",
    "language" : "fr",
    "shortcut" : "KPA",
    "description" : "Palladium kilo",
    "sortNr" : 9999
  }, {
    "code" : "KPA",
    "language" : "en",
    "shortcut" : "KPA",
    "description" : "Palladium kilo",
    "sortNr" : 9999
  }, {
    "code" : "KPL",
    "language" : "de",
    "shortcut" : "KPL",
    "description" : "Platin Kilo",
    "sortNr" : 9999
  }, {
    "code" : "KPL",
    "language" : "fr",
    "shortcut" : "KPL",
    "description" : "Platine kilo",
    "sortNr" : 9999
  }, {
    "code" : "KPL",
    "language" : "en",
    "shortcut" : "KPL",
    "description" : "Platinum kilo",
    "sortNr" : 9999
  }, {
    "code" : "KPW",
    "language" : "de",
    "shortcut" : "KPW",
    "description" : "Nordkoreanischer Won",
    "sortNr" : 9999
  }, {
    "code" : "KPW",
    "language" : "fr",
    "shortcut" : "KPW",
    "description" : "Nordkoreanischer Won",
    "sortNr" : 9999
  }, {
    "code" : "KPW",
    "language" : "en",
    "shortcut" : "KPW",
    "description" : "Nordkoreanischer Won",
    "sortNr" : 9999
  }, {
    "code" : "KRU",
    "language" : "de",
    "shortcut" : "KRU",
    "description" : "Krügerrand 1 Oz",
    "sortNr" : 9999
  }, {
    "code" : "KRU",
    "language" : "fr",
    "shortcut" : "KRU",
    "description" : "Krügerrand 1 Oz",
    "sortNr" : 9999
  }, {
    "code" : "KRU",
    "language" : "en",
    "shortcut" : "KRU",
    "description" : "Krugerrand 1 Oz",
    "sortNr" : 9999
  }, {
    "code" : "KRW",
    "language" : "de",
    "shortcut" : "KRW",
    "description" : "Südkoreanischer Won",
    "sortNr" : 350
  }, {
    "code" : "KRW",
    "language" : "fr",
    "shortcut" : "KRW",
    "description" : "Won sud-coréen",
    "sortNr" : 350
  }, {
    "code" : "KRW",
    "language" : "en",
    "shortcut" : "KRW",
    "description" : "Südkoreanischer Won",
    "sortNr" : 350
  }, {
    "code" : "KSI",
    "language" : "de",
    "shortcut" : "KGS",
    "description" : "Silber Kilo",
    "sortNr" : 9999
  }, {
    "code" : "KSI",
    "language" : "fr",
    "shortcut" : "KGS",
    "description" : "Argent kilo",
    "sortNr" : 9999
  }, {
    "code" : "KSI",
    "language" : "en",
    "shortcut" : "KGS",
    "description" : "Silver kilo",
    "sortNr" : 9999
  }, {
    "code" : "KWD",
    "language" : "de",
    "shortcut" : "KWD",
    "description" : "Kuweit Dinar",
    "sortNr" : 9999
  }, {
    "code" : "KWD",
    "language" : "fr",
    "shortcut" : "KWD",
    "description" : "Kuweit Dinar",
    "sortNr" : 9999
  }, {
    "code" : "KWD",
    "language" : "en",
    "shortcut" : "KWD",
    "description" : "Kuweit Dinar",
    "sortNr" : 9999
  }, {
    "code" : "KYD",
    "language" : "de",
    "shortcut" : "KYD",
    "description" : "Cayman Island Dollar",
    "sortNr" : 9999
  }, {
    "code" : "KYD",
    "language" : "fr",
    "shortcut" : "KYD",
    "description" : "Cayman Island Dollar",
    "sortNr" : 9999
  }, {
    "code" : "KYD",
    "language" : "en",
    "shortcut" : "KYD",
    "description" : "Cayman Island Dollar",
    "sortNr" : 9999
  }, {
    "code" : "KZT",
    "language" : "de",
    "shortcut" : "KZT",
    "description" : "Kasachstan Tenge",
    "sortNr" : 9999
  }, {
    "code" : "KZT",
    "language" : "fr",
    "shortcut" : "KZT",
    "description" : "Kasachstan Tenge",
    "sortNr" : 9999
  }, {
    "code" : "KZT",
    "language" : "en",
    "shortcut" : "KZT",
    "description" : "Kasachstan Tenge",
    "sortNr" : 9999
  }, {
    "code" : "LAK",
    "language" : "de",
    "shortcut" : "LAK",
    "description" : "Laos Kip",
    "sortNr" : 9999
  }, {
    "code" : "LAK",
    "language" : "fr",
    "shortcut" : "LAK",
    "description" : "Laos Kip",
    "sortNr" : 9999
  }, {
    "code" : "LAK",
    "language" : "en",
    "shortcut" : "LAK",
    "description" : "Laos Kip",
    "sortNr" : 9999
  }, {
    "code" : "LBP",
    "language" : "de",
    "shortcut" : "LBP",
    "description" : "Lebanese Pound",
    "sortNr" : 9999
  }, {
    "code" : "LBP",
    "language" : "fr",
    "shortcut" : "LBP",
    "description" : "Lebanese Pound",
    "sortNr" : 9999
  }, {
    "code" : "LBP",
    "language" : "en",
    "shortcut" : "LBP",
    "description" : "Lebanese Pound",
    "sortNr" : 9999
  }, {
    "code" : "LKR",
    "language" : "de",
    "shortcut" : "LKR",
    "description" : "Sri Lankan Rupee",
    "sortNr" : 9999
  }, {
    "code" : "LKR",
    "language" : "fr",
    "shortcut" : "LKR",
    "description" : "Sri Lankan Rupee",
    "sortNr" : 9999
  }, {
    "code" : "LKR",
    "language" : "en",
    "shortcut" : "LKR",
    "description" : "Sri Lankan Rupee",
    "sortNr" : 9999
  }, {
    "code" : "LRD",
    "language" : "de",
    "shortcut" : "LRD",
    "description" : "Liberian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "LRD",
    "language" : "fr",
    "shortcut" : "LRD",
    "description" : "Liberian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "LRD",
    "language" : "en",
    "shortcut" : "LRD",
    "description" : "Liberian Dollar",
    "sortNr" : 9999
  }, {
    "code" : "LSL",
    "language" : "de",
    "shortcut" : "LSL",
    "description" : "Lesotho Loti",
    "sortNr" : 9999
  }, {
    "code" : "LSL",
    "language" : "fr",
    "shortcut" : "LSL",
    "description" : "Lesotho Loti",
    "sortNr" : 9999
  }, {
    "code" : "LSL",
    "language" : "en",
    "shortcut" : "LSL",
    "description" : "Lesotho Loti",
    "sortNr" : 9999
  }, {
    "code" : "LTL",
    "language" : "de",
    "shortcut" : "LTL",
    "description" : "Lithuanian Litas",
    "sortNr" : 9999
  }, {
    "code" : "LTL",
    "language" : "fr",
    "shortcut" : "LTL",
    "description" : "Lithuanian Litas",
    "sortNr" : 9999
  }, {
    "code" : "LTL",
    "language" : "en",
    "shortcut" : "LTL",
    "description" : "Lithuanian Litas",
    "sortNr" : 9999
  }, {
    "code" : "LUF",
    "language" : "de",
    "shortcut" : "LUF",
    "description" : "LUF",
    "sortNr" : 9999
  }, {
    "code" : "LUF",
    "language" : "fr",
    "shortcut" : "LUF",
    "description" : "LUF",
    "sortNr" : 9999
  }, {
    "code" : "LUF",
    "language" : "en",
    "shortcut" : "LUF",
    "description" : "LUF",
    "sortNr" : 9999
  }, {
    "code" : "LVL",
    "language" : "de",
    "shortcut" : "LVL",
    "description" : "LVL",
    "sortNr" : 9999
  }, {
    "code" : "LVL",
    "language" : "fr",
    "shortcut" : "LVL",
    "description" : "LVL",
    "sortNr" : 9999
  }, {
    "code" : "LVL",
    "language" : "en",
    "shortcut" : "LVL",
    "description" : "LVL",
    "sortNr" : 9999
  }, {
    "code" : "LYD",
    "language" : "de",
    "shortcut" : "LYD",
    "description" : "Libyscher Dinar",
    "sortNr" : 9999
  }, {
    "code" : "LYD",
    "language" : "fr",
    "shortcut" : "LYD",
    "description" : "Libyscher Dinar",
    "sortNr" : 9999
  }, {
    "code" : "LYD",
    "language" : "en",
    "shortcut" : "LYD",
    "description" : "Libyscher Dinar",
    "sortNr" : 9999
  }, {
    "code" : "MAD",
    "language" : "de",
    "shortcut" : "MAD",
    "description" : "Marokkanischer Dirham",
    "sortNr" : 9999
  }, {
    "code" : "MAD",
    "language" : "fr",
    "shortcut" : "MAD",
    "description" : "Dirham marocain",
    "sortNr" : 9999
  }, {
    "code" : "MAD",
    "language" : "en",
    "shortcut" : "MAD",
    "description" : "Marokkanischer Dirham",
    "sortNr" : 9999
  }, {
    "code" : "MDL",
    "language" : "de",
    "shortcut" : "MDL",
    "description" : "Moldau Leu",
    "sortNr" : 9999
  }, {
    "code" : "MDL",
    "language" : "fr",
    "shortcut" : "MDL",
    "description" : "Moldau Leu",
    "sortNr" : 9999
  }, {
    "code" : "MDL",
    "language" : "en",
    "shortcut" : "MDL",
    "description" : "Moldau Leu",
    "sortNr" : 9999
  }, {
    "code" : "MGA",
    "language" : "de",
    "shortcut" : "MGA",
    "description" : "Madagaskar Ariary",
    "sortNr" : 9999
  }, {
    "code" : "MGA",
    "language" : "fr",
    "shortcut" : "MGA",
    "description" : "Madagaskar Ariary",
    "sortNr" : 9999
  }, {
    "code" : "MGA",
    "language" : "en",
    "shortcut" : "MGA",
    "description" : "Madagaskar Ariary",
    "sortNr" : 9999
  }, {
    "code" : "MGF",
    "language" : "de",
    "shortcut" : "MGF",
    "description" : "Madagaskar Franc",
    "sortNr" : 9999
  }, {
    "code" : "MGF",
    "language" : "fr",
    "shortcut" : "MGF",
    "description" : "Madagaskar Franc",
    "sortNr" : 9999
  }, {
    "code" : "MGF",
    "language" : "en",
    "shortcut" : "MGF",
    "description" : "Madagaskar Franc",
    "sortNr" : 9999
  }, {
    "code" : "MKD",
    "language" : "de",
    "shortcut" : "MKD",
    "description" : "Mazedonischer Dinar",
    "sortNr" : 9999
  }, {
    "code" : "MKD",
    "language" : "fr",
    "shortcut" : "MKD",
    "description" : "Mazedonischer Dinar",
    "sortNr" : 9999
  }, {
    "code" : "MKD",
    "language" : "en",
    "shortcut" : "MKD",
    "description" : "Mazedonischer Dinar",
    "sortNr" : 9999
  }, {
    "code" : "MMK",
    "language" : "de",
    "shortcut" : "MMK",
    "description" : "Myanmar Kyat",
    "sortNr" : 9999
  }, {
    "code" : "MMK",
    "language" : "fr",
    "shortcut" : "MMK",
    "description" : "Myanmar Kyat",
    "sortNr" : 9999
  }, {
    "code" : "MMK",
    "language" : "en",
    "shortcut" : "MMK",
    "description" : "Myanmar Kyat",
    "sortNr" : 9999
  }, {
    "code" : "MNT",
    "language" : "de",
    "shortcut" : "MNT",
    "description" : "Mongolia Tugrik",
    "sortNr" : 9999
  }, {
    "code" : "MNT",
    "language" : "fr",
    "shortcut" : "MNT",
    "description" : "Mongolia Tugrik",
    "sortNr" : 9999
  }, {
    "code" : "MNT",
    "language" : "en",
    "shortcut" : "MNT",
    "description" : "Mongolia Tugrik",
    "sortNr" : 9999
  }, {
    "code" : "MOP",
    "language" : "de",
    "shortcut" : "MOP",
    "description" : "Macao Pataca",
    "sortNr" : 9999
  }, {
    "code" : "MOP",
    "language" : "fr",
    "shortcut" : "MOP",
    "description" : "Macao Pataca",
    "sortNr" : 9999
  }, {
    "code" : "MOP",
    "language" : "en",
    "shortcut" : "MOP",
    "description" : "Macao Pataca",
    "sortNr" : 9999
  }, {
    "code" : "MPL",
    "language" : "de",
    "shortcut" : "MPL",
    "description" : "Maple Leaf",
    "sortNr" : 9999
  }, {
    "code" : "MPL",
    "language" : "fr",
    "shortcut" : "MPL",
    "description" : "Maple Leaf",
    "sortNr" : 9999
  }, {
    "code" : "MPL",
    "language" : "en",
    "shortcut" : "MPL",
    "description" : "Maple leaf",
    "sortNr" : 9999
  }, {
    "code" : "MRO",
    "language" : "de",
    "shortcut" : "MRO",
    "description" : "Mauritanian Ouguiya",
    "sortNr" : 9999
  }, {
    "code" : "MRO",
    "language" : "fr",
    "shortcut" : "MRO",
    "description" : "Mauritanian Ouguiya",
    "sortNr" : 9999
  }, {
    "code" : "MRO",
    "language" : "en",
    "shortcut" : "MRO",
    "description" : "Mauritanian Ouguiya",
    "sortNr" : 9999
  }, {
    "code" : "MRU",
    "language" : "de",
    "shortcut" : "MRU",
    "description" : "Mauretanien Ougiya",
    "sortNr" : 9999
  }, {
    "code" : "MRU",
    "language" : "fr",
    "shortcut" : "MRU",
    "description" : "Mauritanie Ougiya",
    "sortNr" : 9999
  }, {
    "code" : "MRU",
    "language" : "en",
    "shortcut" : "MRU",
    "description" : "Mauritania Ouguiya",
    "sortNr" : 9999
  }, {
    "code" : "MTL",
    "language" : "de",
    "shortcut" : "MTL",
    "description" : "MTL",
    "sortNr" : 9999
  }, {
    "code" : "MTL",
    "language" : "fr",
    "shortcut" : "MTL",
    "description" : "MTL",
    "sortNr" : 9999
  }, {
    "code" : "MTL",
    "language" : "en",
    "shortcut" : "MTL",
    "description" : "MTL",
    "sortNr" : 9999
  }, {
    "code" : "MUR",
    "language" : "de",
    "shortcut" : "MUR",
    "description" : "Mauritian Rupee",
    "sortNr" : 9999
  }, {
    "code" : "MUR",
    "language" : "fr",
    "shortcut" : "MUR",
    "description" : "Mauritian Rupee",
    "sortNr" : 9999
  }, {
    "code" : "MUR",
    "language" : "en",
    "shortcut" : "MUR",
    "description" : "Mauritian Rupee",
    "sortNr" : 9999
  }, {
    "code" : "MVR",
    "language" : "de",
    "shortcut" : "MVR",
    "description" : "Malediven Rufiyaa",
    "sortNr" : 9999
  }, {
    "code" : "MVR",
    "language" : "fr",
    "shortcut" : "MVR",
    "description" : "Malediven Rufiyaa",
    "sortNr" : 9999
  }, {
    "code" : "MVR",
    "language" : "en",
    "shortcut" : "MVR",
    "description" : "Malediven Rufiyaa",
    "sortNr" : 9999
  }, {
    "code" : "MWA",
    "language" : "de",
    "shortcut" : "MWA",
    "description" : "Megawatt",
    "sortNr" : 9999
  }, {
    "code" : "MWA",
    "language" : "fr",
    "shortcut" : "Megaw",
    "description" : "Megawatt",
    "sortNr" : 9999
  }, {
    "code" : "MWA",
    "language" : "en",
    "shortcut" : "MWA",
    "description" : "Megawatt",
    "sortNr" : 9999
  }, {
    "code" : "MWK",
    "language" : "de",
    "shortcut" : "MWK",
    "description" : "Malawian Kwacha",
    "sortNr" : 9999
  }, {
    "code" : "MWK",
    "language" : "fr",
    "shortcut" : "MWK",
    "description" : "Malawian Kwacha",
    "sortNr" : 9999
  }, {
    "code" : "MWK",
    "language" : "en",
    "shortcut" : "MWK",
    "description" : "Malawian Kwacha",
    "sortNr" : 9999
  }, {
    "code" : "MXN",
    "language" : "de",
    "shortcut" : "MXN",
    "description" : "Mexikanischer Peso",
    "sortNr" : 330
  }, {
    "code" : "MXN",
    "language" : "fr",
    "shortcut" : "MXN",
    "description" : "Peso mexicain",
    "sortNr" : 330
  }, {
    "code" : "MXN",
    "language" : "en",
    "shortcut" : "MXN",
    "description" : "Mexikanischer Peso",
    "sortNr" : 330
  }, {
    "code" : "MXV",
    "language" : "de",
    "shortcut" : "MXV",
    "description" : "Unidad de Inversion (Mexico)",
    "sortNr" : 9999
  }, {
    "code" : "MXV",
    "language" : "fr",
    "shortcut" : "MXV",
    "description" : "Unidad de Inversion (Mexico)",
    "sortNr" : 9999
  }, {
    "code" : "MXV",
    "language" : "en",
    "shortcut" : "MXV",
    "description" : "Unidad de Inversion (Mexico)",
    "sortNr" : 9999
  }, {
    "code" : "MYR",
    "language" : "de",
    "shortcut" : "MYR",
    "description" : "Malaysischer Ringgit",
    "sortNr" : 9999
  }, {
    "code" : "MYR",
    "language" : "fr",
    "shortcut" : "MYR",
    "description" : "Ringgit malaysien",
    "sortNr" : 9999
  }, {
    "code" : "MYR",
    "language" : "en",
    "shortcut" : "MYR",
    "description" : "Malayischer Ringgit",
    "sortNr" : 9999
  }, {
    "code" : "MZM",
    "language" : "de",
    "shortcut" : "MZM",
    "description" : "Mosambikanische (Neue Metical) *ALT*",
    "sortNr" : 9999
  }, {
    "code" : "MZM",
    "language" : "fr",
    "shortcut" : "MZM",
    "description" : "Metical mozambicain *VIEUX*",
    "sortNr" : 9999
  }, {
    "code" : "MZM",
    "language" : "en",
    "shortcut" : "MZM",
    "description" : "Mosambikanische Neue Metical *OLD*",
    "sortNr" : 9999
  }, {
    "code" : "MZN",
    "language" : "de",
    "shortcut" : "MZN",
    "description" : "Mosambique Metical",
    "sortNr" : 9999
  }, {
    "code" : "MZN",
    "language" : "fr",
    "shortcut" : "MZN",
    "description" : "Mosambique Metical",
    "sortNr" : 9999
  }, {
    "code" : "MZN",
    "language" : "en",
    "shortcut" : "MZN",
    "description" : "Mosambique Metical",
    "sortNr" : 9999
  }, {
    "code" : "NAD",
    "language" : "de",
    "shortcut" : "NAD",
    "description" : "Namibia Dollar",
    "sortNr" : 9999
  }, {
    "code" : "NAD",
    "language" : "fr",
    "shortcut" : "NAD",
    "description" : "Namibia Dollar",
    "sortNr" : 9999
  }, {
    "code" : "NAD",
    "language" : "en",
    "shortcut" : "NAD",
    "description" : "Namibia Dollar",
    "sortNr" : 9999
  }, {
    "code" : "NAP",
    "language" : "de",
    "shortcut" : "NAP",
    "description" : "Gold Napoleon",
    "sortNr" : 1020
  }, {
    "code" : "NAP",
    "language" : "fr",
    "shortcut" : "NAP",
    "description" : "Or Napoléon",
    "sortNr" : 1020
  }, {
    "code" : "NAP",
    "language" : "en",
    "shortcut" : "NAP",
    "description" : "Gold Napoleon",
    "sortNr" : 1020
  }, {
    "code" : "NGN",
    "language" : "de",
    "shortcut" : "NGN",
    "description" : "Nigerian Naira",
    "sortNr" : 9999
  }, {
    "code" : "NGN",
    "language" : "fr",
    "shortcut" : "NGN",
    "description" : "Nigerian Naira",
    "sortNr" : 9999
  }, {
    "code" : "NGN",
    "language" : "en",
    "shortcut" : "NGN",
    "description" : "Nigerian Naira",
    "sortNr" : 9999
  }, {
    "code" : "NIO",
    "language" : "de",
    "shortcut" : "NIO",
    "description" : "Nicaragua Cordoba",
    "sortNr" : 9999
  }, {
    "code" : "NIO",
    "language" : "fr",
    "shortcut" : "NIO",
    "description" : "Nicaragua Cordoba",
    "sortNr" : 9999
  }, {
    "code" : "NIO",
    "language" : "en",
    "shortcut" : "NIO",
    "description" : "Nicaragua Cordoba",
    "sortNr" : 9999
  }, {
    "code" : "NLG",
    "language" : "de",
    "shortcut" : "NLG",
    "description" : "Gulden (Niederlande)",
    "sortNr" : 9999
  }, {
    "code" : "NLG",
    "language" : "fr",
    "shortcut" : "NLG",
    "description" : "Florins néerlandais",
    "sortNr" : 9999
  }, {
    "code" : "NLG",
    "language" : "en",
    "shortcut" : "NLG",
    "description" : "Dutch Guilder",
    "sortNr" : 9999
  }, {
    "code" : "NOB",
    "language" : "de",
    "shortcut" : "NOB",
    "description" : "Platin Noble",
    "sortNr" : 9999
  }, {
    "code" : "NOB",
    "language" : "fr",
    "shortcut" : "NOB",
    "description" : "Platine Noble",
    "sortNr" : 9999
  }, {
    "code" : "NOB",
    "language" : "en",
    "shortcut" : "NOB",
    "description" : "Platinum noble",
    "sortNr" : 9999
  }, {
    "code" : "NOK",
    "language" : "de",
    "shortcut" : "NOK",
    "description" : "Norwegische Krone",
    "sortNr" : 60
  }, {
    "code" : "NOK",
    "language" : "fr",
    "shortcut" : "NOK",
    "description" : "Couronne norvégienne",
    "sortNr" : 60
  }, {
    "code" : "NOK",
    "language" : "en",
    "shortcut" : "NOK",
    "description" : "Norwegian Kroner",
    "sortNr" : 60
  }, {
    "code" : "NPR",
    "language" : "de",
    "shortcut" : "NPR",
    "description" : "Nepalese Rupee",
    "sortNr" : 9999
  }, {
    "code" : "NPR",
    "language" : "fr",
    "shortcut" : "NPR",
    "description" : "Nepalese Rupee",
    "sortNr" : 9999
  }, {
    "code" : "NPR",
    "language" : "en",
    "shortcut" : "NPR",
    "description" : "Nepalese Rupee",
    "sortNr" : 9999
  }, {
    "code" : "NUG",
    "language" : "de",
    "shortcut" : "NUG",
    "description" : "Gold Aust.Nugget",
    "sortNr" : 9999
  }, {
    "code" : "NUG",
    "language" : "fr",
    "shortcut" : "NUG",
    "description" : "Or Austr. Nugget",
    "sortNr" : 9999
  }, {
    "code" : "NUG",
    "language" : "en",
    "shortcut" : "NUG",
    "description" : "Gold Aust. nugget",
    "sortNr" : 9999
  }, {
    "code" : "NZD",
    "language" : "de",
    "shortcut" : "NZD",
    "description" : "Neuseeländischer Dollar",
    "sortNr" : 9999
  }, {
    "code" : "NZD",
    "language" : "fr",
    "shortcut" : "NZD",
    "description" : "Dollar néo-zélandais",
    "sortNr" : 9999
  }, {
    "code" : "NZD",
    "language" : "en",
    "shortcut" : "NZD",
    "description" : "New Zealand Dollar",
    "sortNr" : 9999
  }, {
    "code" : "OMR",
    "language" : "de",
    "shortcut" : "OMR",
    "description" : "Rial Omani",
    "sortNr" : 9999
  }, {
    "code" : "OMR",
    "language" : "fr",
    "shortcut" : "OMR",
    "description" : "Rial Omani",
    "sortNr" : 9999
  }, {
    "code" : "OMR",
    "language" : "en",
    "shortcut" : "OMR",
    "description" : "Rial Omani",
    "sortNr" : 9999
  }, {
    "code" : "OPA",
    "language" : "de",
    "shortcut" : "OPA",
    "description" : "Palladium Unze",
    "sortNr" : 940
  }, {
    "code" : "OPA",
    "language" : "fr",
    "shortcut" : "OPA",
    "description" : "Palladium once",
    "sortNr" : 940
  }, {
    "code" : "OPA",
    "language" : "en",
    "shortcut" : "OPA",
    "description" : "Palladium ounce",
    "sortNr" : 940
  }, {
    "code" : "OPL",
    "language" : "de",
    "shortcut" : "OPL",
    "description" : "Platin Unze",
    "sortNr" : 920
  }, {
    "code" : "OPL",
    "language" : "fr",
    "shortcut" : "OPL",
    "description" : "Platine once",
    "sortNr" : 920
  }, {
    "code" : "OPL",
    "language" : "en",
    "shortcut" : "OPL",
    "description" : "Platinum ounce",
    "sortNr" : 920
  }, {
    "code" : "OZG",
    "language" : "de",
    "shortcut" : "OZG",
    "description" : "Gold Unze",
    "sortNr" : 880
  }, {
    "code" : "OZG",
    "language" : "fr",
    "shortcut" : "OZG",
    "description" : "Or once",
    "sortNr" : 880
  }, {
    "code" : "OZG",
    "language" : "en",
    "shortcut" : "OZG",
    "description" : "Gold ounce",
    "sortNr" : 880
  }, {
    "code" : "OZS",
    "language" : "de",
    "shortcut" : "OZS",
    "description" : "Silber Unze",
    "sortNr" : 900
  }, {
    "code" : "OZS",
    "language" : "fr",
    "shortcut" : "OZS",
    "description" : "Argent once",
    "sortNr" : 900
  }, {
    "code" : "OZS",
    "language" : "en",
    "shortcut" : "OZS",
    "description" : "Silver ounce",
    "sortNr" : 900
  }, {
    "code" : "PAB",
    "language" : "de",
    "shortcut" : "PAB",
    "description" : "Panamanian Balboa",
    "sortNr" : 9999
  }, {
    "code" : "PAB",
    "language" : "fr",
    "shortcut" : "PAB",
    "description" : "Panamanian Balboa",
    "sortNr" : 9999
  }, {
    "code" : "PAB",
    "language" : "en",
    "shortcut" : "PAB",
    "description" : "Panamanian Balboa",
    "sortNr" : 9999
  }, {
    "code" : "PEN",
    "language" : "de",
    "shortcut" : "PEN",
    "description" : "Peruvian Nuevo Sol",
    "sortNr" : 9999
  }, {
    "code" : "PEN",
    "language" : "fr",
    "shortcut" : "PEN",
    "description" : "Peruvian Nuevo Sol",
    "sortNr" : 9999
  }, {
    "code" : "PEN",
    "language" : "en",
    "shortcut" : "PEN",
    "description" : "Peruvian Nuevo Sol",
    "sortNr" : 9999
  }, {
    "code" : "PGK",
    "language" : "de",
    "shortcut" : "PGK",
    "description" : "Papua New Guinean Kina",
    "sortNr" : 9999
  }, {
    "code" : "PGK",
    "language" : "fr",
    "shortcut" : "PGK",
    "description" : "Papua New Guinean Kina",
    "sortNr" : 9999
  }, {
    "code" : "PGK",
    "language" : "en",
    "shortcut" : "PGK",
    "description" : "Papua New Guinean Kina",
    "sortNr" : 9999
  }, {
    "code" : "PHP",
    "language" : "de",
    "shortcut" : "PHP",
    "description" : "Philippinischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "PHP",
    "language" : "fr",
    "shortcut" : "PHP",
    "description" : "Philippinischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "PHP",
    "language" : "en",
    "shortcut" : "PHP",
    "description" : "Philippinischer Peso",
    "sortNr" : 9999
  }, {
    "code" : "PKR",
    "language" : "de",
    "shortcut" : "PKR",
    "description" : "Pakistanische Rupie",
    "sortNr" : 9999
  }, {
    "code" : "PKR",
    "language" : "fr",
    "shortcut" : "PKR",
    "description" : "Roupie pakistanaise",
    "sortNr" : 9999
  }, {
    "code" : "PKR",
    "language" : "en",
    "shortcut" : "PKR",
    "description" : "Pakistanische Rupie",
    "sortNr" : 9999
  }, {
    "code" : "PLN",
    "language" : "de",
    "shortcut" : "PLN",
    "description" : "Polnischer Zloty",
    "sortNr" : 270
  }, {
    "code" : "PLN",
    "language" : "fr",
    "shortcut" : "PLN",
    "description" : "Zloty polonais",
    "sortNr" : 270
  }, {
    "code" : "PLN",
    "language" : "en",
    "shortcut" : "PLN",
    "description" : "Polnischer Zloty",
    "sortNr" : 270
  }, {
    "code" : "PTE",
    "language" : "de",
    "shortcut" : "PTE",
    "description" : "Escudos (Portugal)",
    "sortNr" : 9999
  }, {
    "code" : "PTE",
    "language" : "fr",
    "shortcut" : "PTE",
    "description" : "Escudos portugais",
    "sortNr" : 9999
  }, {
    "code" : "PTE",
    "language" : "en",
    "shortcut" : "PTE",
    "description" : "Portuguese escudo",
    "sortNr" : 9999
  }, {
    "code" : "PYG",
    "language" : "de",
    "shortcut" : "PYG",
    "description" : "Paraguany Guarani",
    "sortNr" : 9999
  }, {
    "code" : "PYG",
    "language" : "fr",
    "shortcut" : "PYG",
    "description" : "Paraguany Guarani",
    "sortNr" : 9999
  }, {
    "code" : "PYG",
    "language" : "en",
    "shortcut" : "PYG",
    "description" : "Paraguany Guarani",
    "sortNr" : 9999
  }, {
    "code" : "QAR",
    "language" : "de",
    "shortcut" : "QAR",
    "description" : "Qatari Rial",
    "sortNr" : 9999
  }, {
    "code" : "QAR",
    "language" : "fr",
    "shortcut" : "QAR",
    "description" : "Qatari Rial",
    "sortNr" : 9999
  }, {
    "code" : "QAR",
    "language" : "en",
    "shortcut" : "QAT",
    "description" : "Qatari Rial",
    "sortNr" : 9999
  }, {
    "code" : "QOF",
    "language" : "de",
    "shortcut" : "QOF",
    "description" : "Offshore Katar Riyal",
    "sortNr" : 9999
  }, {
    "code" : "QOF",
    "language" : "fr",
    "shortcut" : "QOF",
    "description" : "Offshore Katar Riyal",
    "sortNr" : 9999
  }, {
    "code" : "QOF",
    "language" : "en",
    "shortcut" : "QOF",
    "description" : "Offshore Qatari Riyal",
    "sortNr" : 9999
  }, {
    "code" : "RON",
    "language" : "de",
    "shortcut" : "LEU",
    "description" : "Rumänischer Leu",
    "sortNr" : 9999
  }, {
    "code" : "RON",
    "language" : "fr",
    "shortcut" : "LEU",
    "description" : "Leu roumain",
    "sortNr" : 9999
  }, {
    "code" : "RON",
    "language" : "en",
    "shortcut" : "LEU",
    "description" : "Rumänischer Leu",
    "sortNr" : 9999
  }, {
    "code" : "RPR",
    "language" : "de",
    "shortcut" : "RPR",
    "description" : "RP-Rollen",
    "sortNr" : 9999
  }, {
    "code" : "RPR",
    "language" : "fr",
    "shortcut" : "Rôles",
    "description" : "Rôles RP",
    "sortNr" : 9999
  }, {
    "code" : "RPR",
    "language" : "en",
    "shortcut" : "RPR",
    "description" : "RP rolls",
    "sortNr" : 9999
  }, {
    "code" : "RSD",
    "language" : "de",
    "shortcut" : "RSD",
    "description" : "Serbian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "RSD",
    "language" : "fr",
    "shortcut" : "CSD",
    "description" : "Serbian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "RSD",
    "language" : "en",
    "shortcut" : "RSD",
    "description" : "Serbian Dinar",
    "sortNr" : 9999
  }, {
    "code" : "RUB",
    "language" : "de",
    "shortcut" : "RUB",
    "description" : "Russischer Rubel",
    "sortNr" : 9999
  }, {
    "code" : "RUB",
    "language" : "fr",
    "shortcut" : "RUB",
    "description" : "Rouble russe",
    "sortNr" : 9999
  }, {
    "code" : "RUB",
    "language" : "en",
    "shortcut" : "RUB",
    "description" : "Russischer Rubel",
    "sortNr" : 9999
  }, {
    "code" : "RWF",
    "language" : "de",
    "shortcut" : "FRR",
    "description" : "Rwandan Franc",
    "sortNr" : 9999
  }, {
    "code" : "RWF",
    "language" : "fr",
    "shortcut" : "FRR",
    "description" : "Rwandan Franc",
    "sortNr" : 9999
  }, {
    "code" : "RWF",
    "language" : "en",
    "shortcut" : "FRR",
    "description" : "Rwandan Franc",
    "sortNr" : 9999
  }, {
    "code" : "SAR",
    "language" : "de",
    "shortcut" : "SAR",
    "description" : "Saudiarabischer Rial",
    "sortNr" : 9999
  }, {
    "code" : "SAR",
    "language" : "fr",
    "shortcut" : "SAR",
    "description" : "Saudiarabischer Rial",
    "sortNr" : 9999
  }, {
    "code" : "SAR",
    "language" : "en",
    "shortcut" : "SAR",
    "description" : "Saudiarabischer Rial",
    "sortNr" : 9999
  }, {
    "code" : "SBD",
    "language" : "de",
    "shortcut" : "SBD",
    "description" : "Salomonen Dollar",
    "sortNr" : 9999
  }, {
    "code" : "SBD",
    "language" : "fr",
    "shortcut" : "SBD",
    "description" : "Salomonen Dollar",
    "sortNr" : 9999
  }, {
    "code" : "SBD",
    "language" : "en",
    "shortcut" : "SBD",
    "description" : "Salomonen Dollar",
    "sortNr" : 9999
  }, {
    "code" : "SCR",
    "language" : "de",
    "shortcut" : "SCR",
    "description" : "Seychellen Rupie",
    "sortNr" : 9999
  }, {
    "code" : "SCR",
    "language" : "fr",
    "shortcut" : "SCR",
    "description" : "Seychellen Rupie",
    "sortNr" : 9999
  }, {
    "code" : "SCR",
    "language" : "en",
    "shortcut" : "SCR",
    "description" : "Seychellen Rupie",
    "sortNr" : 9999
  }, {
    "code" : "SDD",
    "language" : "de",
    "shortcut" : "SDD",
    "description" : "Sudaniesischer Dinar",
    "sortNr" : 9999
  }, {
    "code" : "SDD",
    "language" : "fr",
    "shortcut" : "SDD",
    "description" : "Sudaniesischer Dinar",
    "sortNr" : 9999
  }, {
    "code" : "SDD",
    "language" : "en",
    "shortcut" : "SDD",
    "description" : "Sudaniesischer Dinar",
    "sortNr" : 9999
  }, {
    "code" : "SDG",
    "language" : "de",
    "shortcut" : "SDG",
    "description" : "Sudanesisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SDG",
    "language" : "fr",
    "shortcut" : "SDG",
    "description" : "Sudanesisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SDG",
    "language" : "en",
    "shortcut" : "SDG",
    "description" : "Sudanesisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SEK",
    "language" : "de",
    "shortcut" : "SEK",
    "description" : "Schwedische Krone",
    "sortNr" : 70
  }, {
    "code" : "SEK",
    "language" : "fr",
    "shortcut" : "SEK",
    "description" : "Couronne suédoise",
    "sortNr" : 70
  }, {
    "code" : "SEK",
    "language" : "en",
    "shortcut" : "SEK",
    "description" : "Swedish Kronor",
    "sortNr" : 70
  }, {
    "code" : "SGD",
    "language" : "de",
    "shortcut" : "SGD",
    "description" : "Singapur-Dollar",
    "sortNr" : 250
  }, {
    "code" : "SGD",
    "language" : "fr",
    "shortcut" : "SGD",
    "description" : "Dollar de Singapour",
    "sortNr" : 250
  }, {
    "code" : "SGD",
    "language" : "en",
    "shortcut" : "SGD",
    "description" : "Singapore Dollar",
    "sortNr" : 250
  }, {
    "code" : "SHP",
    "language" : "de",
    "shortcut" : "SHP",
    "description" : "St.-Helena Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SHP",
    "language" : "fr",
    "shortcut" : "SHP",
    "description" : "St.-Helena Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SHP",
    "language" : "en",
    "shortcut" : "SHP",
    "description" : "St.-Helena Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SIT",
    "language" : "de",
    "shortcut" : "SIT",
    "description" : "SIT",
    "sortNr" : 9999
  }, {
    "code" : "SIT",
    "language" : "fr",
    "shortcut" : "SIT",
    "description" : "SIT",
    "sortNr" : 9999
  }, {
    "code" : "SIT",
    "language" : "en",
    "shortcut" : "SIT",
    "description" : "SIT",
    "sortNr" : 9999
  }, {
    "code" : "SKK",
    "language" : "de",
    "shortcut" : "SKK",
    "description" : "SKK",
    "sortNr" : 9999
  }, {
    "code" : "SKK",
    "language" : "fr",
    "shortcut" : "SKK",
    "description" : "SKK",
    "sortNr" : 9999
  }, {
    "code" : "SKK",
    "language" : "en",
    "shortcut" : "SKK",
    "description" : "SKK",
    "sortNr" : 9999
  }, {
    "code" : "SLL",
    "language" : "de",
    "shortcut" : "SLL",
    "description" : "Sierra Leonean Leone",
    "sortNr" : 9999
  }, {
    "code" : "SLL",
    "language" : "fr",
    "shortcut" : "SLL",
    "description" : "Sierra Leonean Leone",
    "sortNr" : 9999
  }, {
    "code" : "SLL",
    "language" : "en",
    "shortcut" : "SLL",
    "description" : "Sierra Leonean Leone",
    "sortNr" : 9999
  }, {
    "code" : "SMZ",
    "language" : "de",
    "shortcut" : "SMZ",
    "description" : "Silbermünzen Div.",
    "sortNr" : 9999
  }, {
    "code" : "SMZ",
    "language" : "fr",
    "shortcut" : "SMZ",
    "description" : "Div. pièces en argent",
    "sortNr" : 9999
  }, {
    "code" : "SMZ",
    "language" : "en",
    "shortcut" : "SMZ",
    "description" : "Silver coins various",
    "sortNr" : 9999
  }, {
    "code" : "SOS",
    "language" : "de",
    "shortcut" : "SOS",
    "description" : "Somalia Schilling",
    "sortNr" : 9999
  }, {
    "code" : "SOS",
    "language" : "fr",
    "shortcut" : "SOS",
    "description" : "Somalia Schilling",
    "sortNr" : 9999
  }, {
    "code" : "SOS",
    "language" : "en",
    "shortcut" : "SOS",
    "description" : "Somalia Schilling",
    "sortNr" : 9999
  }, {
    "code" : "SOV",
    "language" : "de",
    "shortcut" : "SOV",
    "description" : "Gold Sovereign",
    "sortNr" : 1000
  }, {
    "code" : "SOV",
    "language" : "fr",
    "shortcut" : "SOV",
    "description" : "Or Sovereign",
    "sortNr" : 1000
  }, {
    "code" : "SOV",
    "language" : "en",
    "shortcut" : "SOV",
    "description" : "Gold Sovereign",
    "sortNr" : 1000
  }, {
    "code" : "SRD",
    "language" : "de",
    "shortcut" : "SRD",
    "description" : "Surinam Dollar",
    "sortNr" : 9999
  }, {
    "code" : "SRD",
    "language" : "fr",
    "shortcut" : "SFL",
    "description" : "Surinam Dollar",
    "sortNr" : 9999
  }, {
    "code" : "SRD",
    "language" : "en",
    "shortcut" : "SFL",
    "description" : "Surinam Dollar",
    "sortNr" : 9999
  }, {
    "code" : "SRG",
    "language" : "de",
    "shortcut" : "SRG",
    "description" : "SRG",
    "sortNr" : 9999
  }, {
    "code" : "SRG",
    "language" : "fr",
    "shortcut" : "SRG",
    "description" : "SRG",
    "sortNr" : 9999
  }, {
    "code" : "SRG",
    "language" : "en",
    "shortcut" : "SRG",
    "description" : "SRG",
    "sortNr" : 9999
  }, {
    "code" : "SSP",
    "language" : "de",
    "shortcut" : "SSP",
    "description" : "Südsudanesisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SSP",
    "language" : "fr",
    "shortcut" : "SDD",
    "description" : "Südsudanesisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SSP",
    "language" : "en",
    "shortcut" : "SDD",
    "description" : "Südsudanesisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "STD",
    "language" : "de",
    "shortcut" : "STD",
    "description" : "Sao Tome & Principe Dobra",
    "sortNr" : 9999
  }, {
    "code" : "STD",
    "language" : "fr",
    "shortcut" : "STD",
    "description" : "Sao Tome & Principe Dobra",
    "sortNr" : 9999
  }, {
    "code" : "STD",
    "language" : "en",
    "shortcut" : "STD",
    "description" : "Sao Tome & Principe Dobra",
    "sortNr" : 9999
  }, {
    "code" : "STN",
    "language" : "de",
    "shortcut" : "STN",
    "description" : "São Tomé and Príncipe Dobra",
    "sortNr" : 9999
  }, {
    "code" : "STN",
    "language" : "fr",
    "shortcut" : "STN",
    "description" : "São Tomé and Príncipe Dobra",
    "sortNr" : 9999
  }, {
    "code" : "STN",
    "language" : "en",
    "shortcut" : "STN",
    "description" : "São Tomé and Príncipe Dobra",
    "sortNr" : 9999
  }, {
    "code" : "SVC",
    "language" : "de",
    "shortcut" : "SVC",
    "description" : "SVC",
    "sortNr" : 9999
  }, {
    "code" : "SVC",
    "language" : "fr",
    "shortcut" : "SVC",
    "description" : "SVC",
    "sortNr" : 9999
  }, {
    "code" : "SVC",
    "language" : "en",
    "shortcut" : "SVC",
    "description" : "SVC",
    "sortNr" : 9999
  }, {
    "code" : "SYP",
    "language" : "de",
    "shortcut" : "SYP",
    "description" : "Syrisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SYP",
    "language" : "fr",
    "shortcut" : "SYP",
    "description" : "Syrisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SYP",
    "language" : "en",
    "shortcut" : "SYP",
    "description" : "Syrisches Pfund",
    "sortNr" : 9999
  }, {
    "code" : "SZL",
    "language" : "de",
    "shortcut" : "SZL",
    "description" : "Swaziland Lilangeni",
    "sortNr" : 9999
  }, {
    "code" : "SZL",
    "language" : "fr",
    "shortcut" : "SZL",
    "description" : "Swaziland Lilangeni",
    "sortNr" : 9999
  }, {
    "code" : "SZL",
    "language" : "en",
    "shortcut" : "SZL",
    "description" : "Swaziland Lilangeni",
    "sortNr" : 9999
  }, {
    "code" : "THB",
    "language" : "de",
    "shortcut" : "THB",
    "description" : "Thailändischer Baht",
    "sortNr" : 290
  }, {
    "code" : "THB",
    "language" : "fr",
    "shortcut" : "THB",
    "description" : "Baht thaïlandais",
    "sortNr" : 290
  }, {
    "code" : "THB",
    "language" : "en",
    "shortcut" : "THB",
    "description" : "Thai Baht",
    "sortNr" : 290
  }, {
    "code" : "TJS",
    "language" : "de",
    "shortcut" : "TJS",
    "description" : "Tadschikistan Somoni",
    "sortNr" : 9999
  }, {
    "code" : "TJS",
    "language" : "fr",
    "shortcut" : "TJS",
    "description" : "Tadschikistan Somoni",
    "sortNr" : 9999
  }, {
    "code" : "TJS",
    "language" : "en",
    "shortcut" : "TJS",
    "description" : "Tadschikistan Somoni",
    "sortNr" : 9999
  }, {
    "code" : "TMT",
    "language" : "de",
    "shortcut" : "TMT",
    "description" : "Turkmenistan New Manat",
    "sortNr" : 9999
  }, {
    "code" : "TMT",
    "language" : "fr",
    "shortcut" : "TMT",
    "description" : "Turkmenistan New Manat",
    "sortNr" : 9999
  }, {
    "code" : "TMT",
    "language" : "en",
    "shortcut" : "TMT",
    "description" : "Turkmenistan New Manat",
    "sortNr" : 9999
  }, {
    "code" : "TND",
    "language" : "de",
    "shortcut" : "TND",
    "description" : "Tunesischer Dinar",
    "sortNr" : 9999
  }, {
    "code" : "TND",
    "language" : "fr",
    "shortcut" : "TND",
    "description" : "Dinar tunisien",
    "sortNr" : 9999
  }, {
    "code" : "TND",
    "language" : "en",
    "shortcut" : "TND",
    "description" : "Tunesischer Dirham",
    "sortNr" : 9999
  }, {
    "code" : "TOP",
    "language" : "de",
    "shortcut" : "TOP",
    "description" : "Tonga Pa'anga",
    "sortNr" : 9999
  }, {
    "code" : "TOP",
    "language" : "fr",
    "shortcut" : "TOP",
    "description" : "Tonga Pa'anga",
    "sortNr" : 9999
  }, {
    "code" : "TOP",
    "language" : "en",
    "shortcut" : "TOP",
    "description" : "Tonga Pa'anga",
    "sortNr" : 9999
  }, {
    "code" : "TRL",
    "language" : "de",
    "shortcut" : "TRL",
    "description" : "Türkische Lira",
    "sortNr" : 9999
  }, {
    "code" : "TRL",
    "language" : "fr",
    "shortcut" : "TRL",
    "description" : "Livres turques",
    "sortNr" : 9999
  }, {
    "code" : "TRL",
    "language" : "en",
    "shortcut" : "TRL",
    "description" : "Turkish Lira",
    "sortNr" : 9999
  }, {
    "code" : "TRY",
    "language" : "de",
    "shortcut" : "TRY",
    "description" : "Türkische Lira",
    "sortNr" : 340
  }, {
    "code" : "TRY",
    "language" : "fr",
    "shortcut" : "TRY",
    "description" : "Livre turque",
    "sortNr" : 340
  }, {
    "code" : "TRY",
    "language" : "en",
    "shortcut" : "TRY",
    "description" : "Turkish Lira",
    "sortNr" : 340
  }, {
    "code" : "TTD",
    "language" : "de",
    "shortcut" : "TTD",
    "description" : "Trinidad & Tobago Dollar",
    "sortNr" : 9999
  }, {
    "code" : "TTD",
    "language" : "fr",
    "shortcut" : "TTD",
    "description" : "Trinidad & Tobago Dollar",
    "sortNr" : 9999
  }, {
    "code" : "TTD",
    "language" : "en",
    "shortcut" : "TTD",
    "description" : "Trinidad & Tobago Dollar",
    "sortNr" : 9999
  }, {
    "code" : "TWD",
    "language" : "de",
    "shortcut" : "TWD",
    "description" : "Taiwan-Dollar",
    "sortNr" : 9999
  }, {
    "code" : "TWD",
    "language" : "fr",
    "shortcut" : "TWD",
    "description" : "Dollar de Taiwan",
    "sortNr" : 9999
  }, {
    "code" : "TWD",
    "language" : "en",
    "shortcut" : "TWD",
    "description" : "Taiwan Dollar",
    "sortNr" : 9999
  }, {
    "code" : "TZS",
    "language" : "de",
    "shortcut" : "TZS",
    "description" : "Tanzanian Shilling",
    "sortNr" : 9999
  }, {
    "code" : "TZS",
    "language" : "fr",
    "shortcut" : "TZS",
    "description" : "Tanzanian Shilling",
    "sortNr" : 9999
  }, {
    "code" : "TZS",
    "language" : "en",
    "shortcut" : "TZS",
    "description" : "Tanzanian Shilling",
    "sortNr" : 9999
  }, {
    "code" : "UAH",
    "language" : "de",
    "shortcut" : "UAH",
    "description" : "Ukraine Hryvnia",
    "sortNr" : 9999
  }, {
    "code" : "UAH",
    "language" : "fr",
    "shortcut" : "UAH",
    "description" : "Ukraine Hryvnia",
    "sortNr" : 9999
  }, {
    "code" : "UAH",
    "language" : "en",
    "shortcut" : "UAH",
    "description" : "Ukraine Hryvnia",
    "sortNr" : 9999
  }, {
    "code" : "UGX",
    "language" : "de",
    "shortcut" : "UGX",
    "description" : "Ugandan Shilling",
    "sortNr" : 9999
  }, {
    "code" : "UGX",
    "language" : "fr",
    "shortcut" : "UGX",
    "description" : "Ugandan Shilling",
    "sortNr" : 9999
  }, {
    "code" : "UGX",
    "language" : "en",
    "shortcut" : "UGX",
    "description" : "Ugandan Shilling",
    "sortNr" : 9999
  }, {
    "code" : "USD",
    "language" : "de",
    "shortcut" : "USD",
    "description" : "US-Dollar",
    "sortNr" : 9999
  }, {
    "code" : "USD",
    "language" : "fr",
    "shortcut" : "USD",
    "description" : "US Dollar",
    "sortNr" : 9999
  }, {
    "code" : "USD",
    "language" : "en",
    "shortcut" : "USD",
    "description" : "U.S. Dollar",
    "sortNr" : 9999
  }, {
    "code" : "USN",
    "language" : "de",
    "shortcut" : "USN",
    "description" : "Dollar, Next Day Funds (USA)",
    "sortNr" : 9999
  }, {
    "code" : "USN",
    "language" : "fr",
    "shortcut" : "USN",
    "description" : "Dollar, Next Day Funds (USA)",
    "sortNr" : 9999
  }, {
    "code" : "USN",
    "language" : "en",
    "shortcut" : "USN",
    "description" : "Dollar, next day funds (USA)",
    "sortNr" : 9999
  }, {
    "code" : "USS",
    "language" : "de",
    "shortcut" : "USS",
    "description" : "Dollar, Same DAy Funds (USA)",
    "sortNr" : 9999
  }, {
    "code" : "USS",
    "language" : "fr",
    "shortcut" : "USS",
    "description" : "Dollar, Same DAy Funds (USA)",
    "sortNr" : 9999
  }, {
    "code" : "USS",
    "language" : "en",
    "shortcut" : "USS",
    "description" : "Dollar, next day funds (USA)",
    "sortNr" : 9999
  }, {
    "code" : "UYI",
    "language" : "de",
    "shortcut" : "UYI",
    "description" : "Uruguay Peso En Unidades Indexadas",
    "sortNr" : 9999
  }, {
    "code" : "UYI",
    "language" : "fr",
    "shortcut" : "UYI",
    "description" : "Uruguay Peso En Unidades Indexadas",
    "sortNr" : 9999
  }, {
    "code" : "UYI",
    "language" : "en",
    "shortcut" : "UYI",
    "description" : "Uruguay Peso En Unidades Indexadas",
    "sortNr" : 9999
  }, {
    "code" : "UYU",
    "language" : "de",
    "shortcut" : "UYU",
    "description" : "Uruguayan New Peso",
    "sortNr" : 9999
  }, {
    "code" : "UYU",
    "language" : "fr",
    "shortcut" : "UYU",
    "description" : "Uruguayan New Peso",
    "sortNr" : 9999
  }, {
    "code" : "UYU",
    "language" : "en",
    "shortcut" : "UYU",
    "description" : "Uruguayan New Peso",
    "sortNr" : 9999
  }, {
    "code" : "UZS",
    "language" : "de",
    "shortcut" : "UZS",
    "description" : "Usbekistan Sum",
    "sortNr" : 9999
  }, {
    "code" : "UZS",
    "language" : "fr",
    "shortcut" : "UZS",
    "description" : "Usbekistan Sum",
    "sortNr" : 9999
  }, {
    "code" : "UZS",
    "language" : "en",
    "shortcut" : "UZS",
    "description" : "Usbekistan Sum",
    "sortNr" : 9999
  }, {
    "code" : "V10",
    "language" : "de",
    "shortcut" : "V10",
    "description" : "Vreneli CHF 10",
    "sortNr" : 980
  }, {
    "code" : "V10",
    "language" : "fr",
    "shortcut" : "V10",
    "description" : "Vreneli CHF 10",
    "sortNr" : 980
  }, {
    "code" : "V10",
    "language" : "en",
    "shortcut" : "V10",
    "description" : "Vreneli CHF 10",
    "sortNr" : 980
  }, {
    "code" : "V20",
    "language" : "de",
    "shortcut" : "V20",
    "description" : "Vreneli CHF 20",
    "sortNr" : 960
  }, {
    "code" : "V20",
    "language" : "fr",
    "shortcut" : "V20",
    "description" : "Vreneli CHF 20",
    "sortNr" : 960
  }, {
    "code" : "V20",
    "language" : "en",
    "shortcut" : "V20",
    "description" : "Vreneli CHF 20",
    "sortNr" : 960
  }, {
    "code" : "VEB",
    "language" : "de",
    "shortcut" : "VEB",
    "description" : "VEB",
    "sortNr" : 9999
  }, {
    "code" : "VEB",
    "language" : "fr",
    "shortcut" : "VEB",
    "description" : "VEB",
    "sortNr" : 9999
  }, {
    "code" : "VEB",
    "language" : "en",
    "shortcut" : "VEB",
    "description" : "VEB",
    "sortNr" : 9999
  }, {
    "code" : "VEF",
    "language" : "de",
    "shortcut" : "VEF",
    "description" : "Venezuela Bolivar",
    "sortNr" : 9999
  }, {
    "code" : "VEF",
    "language" : "fr",
    "shortcut" : "VEF",
    "description" : "Venezuela Bolivar",
    "sortNr" : 9999
  }, {
    "code" : "VEF",
    "language" : "en",
    "shortcut" : "VEF",
    "description" : "Venezuela Bolivar",
    "sortNr" : 9999
  }, {
    "code" : "VND",
    "language" : "de",
    "shortcut" : "VND",
    "description" : "Vietnamesische Dong",
    "sortNr" : 9999
  }, {
    "code" : "VND",
    "language" : "fr",
    "shortcut" : "VND",
    "description" : "Vietnamesische Dong",
    "sortNr" : 9999
  }, {
    "code" : "VND",
    "language" : "en",
    "shortcut" : "VND",
    "description" : "Vietnamesische Dong",
    "sortNr" : 9999
  }, {
    "code" : "VUV",
    "language" : "de",
    "shortcut" : "VUV",
    "description" : "Vanuatu Vatu",
    "sortNr" : 9999
  }, {
    "code" : "VUV",
    "language" : "fr",
    "shortcut" : "VUV",
    "description" : "Vanuatu Vatu",
    "sortNr" : 9999
  }, {
    "code" : "VUV",
    "language" : "en",
    "shortcut" : "VUV",
    "description" : "Vanuatu Vatu",
    "sortNr" : 9999
  }, {
    "code" : "WST",
    "language" : "de",
    "shortcut" : "WST",
    "description" : "Samoan Tala",
    "sortNr" : 9999
  }, {
    "code" : "WST",
    "language" : "fr",
    "shortcut" : "WST",
    "description" : "Samoan Tala",
    "sortNr" : 9999
  }, {
    "code" : "WST",
    "language" : "en",
    "shortcut" : "WST",
    "description" : "Samoan Tala",
    "sortNr" : 9999
  }, {
    "code" : "XAA",
    "language" : "de",
    "shortcut" : "XAA",
    "description" : "Aluminium-Legierung",
    "sortNr" : 9999
  }, {
    "code" : "XAA",
    "language" : "fr",
    "shortcut" : "XAA",
    "description" : "Alliage aluminium",
    "sortNr" : 9999
  }, {
    "code" : "XAA",
    "language" : "en",
    "shortcut" : "XAA",
    "description" : "Aluminium alloy",
    "sortNr" : 9999
  }, {
    "code" : "XAF",
    "language" : "de",
    "shortcut" : "XAF",
    "description" : "CFA-Franc (Äquatorial)",
    "sortNr" : 9999
  }, {
    "code" : "XAF",
    "language" : "fr",
    "shortcut" : "XAF",
    "description" : "CFA-Franc (Äquatorial)",
    "sortNr" : 9999
  }, {
    "code" : "XAF",
    "language" : "en",
    "shortcut" : "XAF",
    "description" : "CFA-Franc (Äquatorial)",
    "sortNr" : 9999
  }, {
    "code" : "XAG",
    "language" : "de",
    "shortcut" : "AgAll",
    "description" : "Silber allgemein",
    "sortNr" : 9999
  }, {
    "code" : "XAG",
    "language" : "fr",
    "shortcut" : "AgGén",
    "description" : "Argent en général",
    "sortNr" : 9999
  }, {
    "code" : "XAG",
    "language" : "en",
    "shortcut" : "AgGen",
    "description" : "Silver general",
    "sortNr" : 9999
  }, {
    "code" : "XAL",
    "language" : "de",
    "shortcut" : "XAL",
    "description" : "Aluminium",
    "sortNr" : 9999
  }, {
    "code" : "XAL",
    "language" : "fr",
    "shortcut" : "XAL",
    "description" : "Aluminium",
    "sortNr" : 9999
  }, {
    "code" : "XAL",
    "language" : "en",
    "shortcut" : "XAL",
    "description" : "Aluminium",
    "sortNr" : 9999
  }, {
    "code" : "XAU",
    "language" : "de",
    "shortcut" : "AuAll",
    "description" : "Gold allgemein",
    "sortNr" : 9999
  }, {
    "code" : "XAU",
    "language" : "fr",
    "shortcut" : "AuGén",
    "description" : "Or en général",
    "sortNr" : 9999
  }, {
    "code" : "XAU",
    "language" : "en",
    "shortcut" : "AuAll",
    "description" : "Gold general",
    "sortNr" : 9999
  }, {
    "code" : "XBA",
    "language" : "de",
    "shortcut" : "XBA",
    "description" : "Währungseinheit EURCO",
    "sortNr" : 9999
  }, {
    "code" : "XBA",
    "language" : "fr",
    "shortcut" : "XBA",
    "description" : "Unité de vise EURCO",
    "sortNr" : 9999
  }, {
    "code" : "XBA",
    "language" : "en",
    "shortcut" : "XBA",
    "description" : "Currency unit EURCO",
    "sortNr" : 9999
  }, {
    "code" : "XBB",
    "language" : "de",
    "shortcut" : "XBB",
    "description" : "Europäische Währungseinheit",
    "sortNr" : 9999
  }, {
    "code" : "XBB",
    "language" : "fr",
    "shortcut" : "XBB",
    "description" : "Unité monétaire européenne",
    "sortNr" : 9999
  }, {
    "code" : "XBB",
    "language" : "en",
    "shortcut" : "XBB",
    "description" : "European Currency Unit",
    "sortNr" : 9999
  }, {
    "code" : "XBC",
    "language" : "de",
    "shortcut" : "XBC",
    "description" : "Europ. Rechnungseinheiten (Sammler)",
    "sortNr" : 9999
  }, {
    "code" : "XBC",
    "language" : "fr",
    "shortcut" : "XBC",
    "description" : "Unité de compte europ.",
    "sortNr" : 9999
  }, {
    "code" : "XBC",
    "language" : "en",
    "shortcut" : "XBC",
    "description" : "European Unit of Account (Collectors)",
    "sortNr" : 9999
  }, {
    "code" : "XCD",
    "language" : "de",
    "shortcut" : "XCD",
    "description" : "Ostkaribischer Dollar",
    "sortNr" : 9999
  }, {
    "code" : "XCD",
    "language" : "fr",
    "shortcut" : "XCD",
    "description" : "Ostkaribischer Dollar",
    "sortNr" : 9999
  }, {
    "code" : "XCD",
    "language" : "en",
    "shortcut" : "XCD",
    "description" : "Ostkaribischer Dollar",
    "sortNr" : 9999
  }, {
    "code" : "XCU",
    "language" : "de",
    "shortcut" : "XCU",
    "description" : "Kupfer",
    "sortNr" : 9999
  }, {
    "code" : "XCU",
    "language" : "fr",
    "shortcut" : "Cuivr",
    "description" : "Cuivre",
    "sortNr" : 9999
  }, {
    "code" : "XCU",
    "language" : "en",
    "shortcut" : "XCU",
    "description" : "Copper",
    "sortNr" : 9999
  }, {
    "code" : "XDR",
    "language" : "de",
    "shortcut" : "XDR",
    "description" : "Sonderziehungsrechte",
    "sortNr" : 9999
  }, {
    "code" : "XDR",
    "language" : "fr",
    "shortcut" : "XDR",
    "description" : "Droits de tirage spéciaux",
    "sortNr" : 9999
  }, {
    "code" : "XDR",
    "language" : "en",
    "shortcut" : "XDR",
    "description" : "Special drawing rights",
    "sortNr" : 9999
  }, {
    "code" : "XEU",
    "language" : "de",
    "shortcut" : "XEU",
    "description" : "ECU",
    "sortNr" : 9999
  }, {
    "code" : "XEU",
    "language" : "fr",
    "shortcut" : "XEU",
    "description" : "ECU",
    "sortNr" : 9999
  }, {
    "code" : "XEU",
    "language" : "en",
    "shortcut" : "XEU",
    "description" : "ECU",
    "sortNr" : 9999
  }, {
    "code" : "XFO",
    "language" : "de",
    "shortcut" : "XFO",
    "description" : "Goldfranken",
    "sortNr" : 9999
  }, {
    "code" : "XFO",
    "language" : "fr",
    "shortcut" : "XFO",
    "description" : "Franc or",
    "sortNr" : 9999
  }, {
    "code" : "XFO",
    "language" : "en",
    "shortcut" : "XFO",
    "description" : "Gold francs",
    "sortNr" : 9999
  }, {
    "code" : "XFU",
    "language" : "de",
    "shortcut" : "XFU",
    "description" : "UIC-Franc",
    "sortNr" : 9999
  }, {
    "code" : "XFU",
    "language" : "fr",
    "shortcut" : "XFU",
    "description" : "Franc UIC",
    "sortNr" : 9999
  }, {
    "code" : "XFU",
    "language" : "en",
    "shortcut" : "XFU",
    "description" : "UIC Franc",
    "sortNr" : 9999
  }, {
    "code" : "XIR",
    "language" : "de",
    "shortcut" : "IrAll",
    "description" : "Iridium allgemein",
    "sortNr" : 9999
  }, {
    "code" : "XIR",
    "language" : "fr",
    "shortcut" : "IrAll",
    "description" : "Iridium en général",
    "sortNr" : 9999
  }, {
    "code" : "XIR",
    "language" : "en",
    "shortcut" : "IrGen",
    "description" : "Iridium general",
    "sortNr" : 9999
  }, {
    "code" : "XNI",
    "language" : "de",
    "shortcut" : "XNI",
    "description" : "Nickel",
    "sortNr" : 9999
  }, {
    "code" : "XNI",
    "language" : "fr",
    "shortcut" : "XNI",
    "description" : "Nickel                                           XNI",
    "sortNr" : 9999
  }, {
    "code" : "XNI",
    "language" : "en",
    "shortcut" : "XNI",
    "description" : "Nickel",
    "sortNr" : 9999
  }, {
    "code" : "XOF",
    "language" : "de",
    "shortcut" : "XOF",
    "description" : "CFA-Franc (West)",
    "sortNr" : 9999
  }, {
    "code" : "XOF",
    "language" : "fr",
    "shortcut" : "XOF",
    "description" : "CFA-Franc (West)",
    "sortNr" : 9999
  }, {
    "code" : "XOF",
    "language" : "en",
    "shortcut" : "XOF",
    "description" : "CFA-Franc (West)",
    "sortNr" : 9999
  }, {
    "code" : "XOS",
    "language" : "de",
    "shortcut" : "OsAll",
    "description" : "Osmium allgemein",
    "sortNr" : 9999
  }, {
    "code" : "XOS",
    "language" : "fr",
    "shortcut" : "Osmiu",
    "description" : "Osmium en général",
    "sortNr" : 9999
  }, {
    "code" : "XOS",
    "language" : "en",
    "shortcut" : "OsGen",
    "description" : "Osmium general",
    "sortNr" : 9999
  }, {
    "code" : "XPB",
    "language" : "de",
    "shortcut" : "XPB",
    "description" : "Blei",
    "sortNr" : 9999
  }, {
    "code" : "XPB",
    "language" : "fr",
    "shortcut" : "XPB",
    "description" : "Plomb",
    "sortNr" : 9999
  }, {
    "code" : "XPB",
    "language" : "en",
    "shortcut" : "XPB",
    "description" : "Lead",
    "sortNr" : 9999
  }, {
    "code" : "XPD",
    "language" : "de",
    "shortcut" : "PdAll",
    "description" : "Palladium allgemein",
    "sortNr" : 9999
  }, {
    "code" : "XPD",
    "language" : "fr",
    "shortcut" : "PdGén",
    "description" : "Palladium en général",
    "sortNr" : 9999
  }, {
    "code" : "XPD",
    "language" : "en",
    "shortcut" : "PdGen",
    "description" : "Palladium general",
    "sortNr" : 9999
  }, {
    "code" : "XPF",
    "language" : "de",
    "shortcut" : "XPF",
    "description" : "Tahitian Franc",
    "sortNr" : 9999
  }, {
    "code" : "XPF",
    "language" : "fr",
    "shortcut" : "XPF",
    "description" : "Tahitian Franc",
    "sortNr" : 9999
  }, {
    "code" : "XPF",
    "language" : "en",
    "shortcut" : "XPF",
    "description" : "Tahitian Franc",
    "sortNr" : 9999
  }, {
    "code" : "XPT",
    "language" : "de",
    "shortcut" : "PtAll",
    "description" : "Platin allgemein",
    "sortNr" : 9999
  }, {
    "code" : "XPT",
    "language" : "fr",
    "shortcut" : "PtGén",
    "description" : "Platine en général",
    "sortNr" : 9999
  }, {
    "code" : "XPT",
    "language" : "en",
    "shortcut" : "PtGen",
    "description" : "Platinum general",
    "sortNr" : 9999
  }, {
    "code" : "XRH",
    "language" : "de",
    "shortcut" : "RhAll",
    "description" : "Rhodium allgemein",
    "sortNr" : 9999
  }, {
    "code" : "XRH",
    "language" : "fr",
    "shortcut" : "RhGén",
    "description" : "Rhodium en général",
    "sortNr" : 9999
  }, {
    "code" : "XRH",
    "language" : "en",
    "shortcut" : "RhGen",
    "description" : "Rhodium general",
    "sortNr" : 9999
  }, {
    "code" : "XRU",
    "language" : "de",
    "shortcut" : "RuAll",
    "description" : "Ruthenium allgemein",
    "sortNr" : 9999
  }, {
    "code" : "XRU",
    "language" : "fr",
    "shortcut" : "RuGén",
    "description" : "Ruthenium en général",
    "sortNr" : 9999
  }, {
    "code" : "XRU",
    "language" : "en",
    "shortcut" : "RuGen",
    "description" : "Ruthenium general",
    "sortNr" : 9999
  }, {
    "code" : "XSN",
    "language" : "de",
    "shortcut" : "XSN",
    "description" : "Zinn",
    "sortNr" : 9999
  }, {
    "code" : "XSN",
    "language" : "fr",
    "shortcut" : "XSN",
    "description" : "Etain",
    "sortNr" : 9999
  }, {
    "code" : "XSN",
    "language" : "en",
    "shortcut" : "XSN",
    "description" : "Tin",
    "sortNr" : 9999
  }, {
    "code" : "XUA",
    "language" : "de",
    "shortcut" : "ADB",
    "description" : "ADB Unit of Account",
    "sortNr" : 9999
  }, {
    "code" : "XUA",
    "language" : "fr",
    "shortcut" : "ADB",
    "description" : "ADB Unit of Account",
    "sortNr" : 9999
  }, {
    "code" : "XUA",
    "language" : "en",
    "shortcut" : "ADB",
    "description" : "ADB unit of account",
    "sortNr" : 9999
  }, {
    "code" : "XXD",
    "language" : "de",
    "shortcut" : "XXD",
    "description" : "Danziger Gulden",
    "sortNr" : 9999
  }, {
    "code" : "XXD",
    "language" : "fr",
    "shortcut" : "XXD",
    "description" : "Florins de Dantzig",
    "sortNr" : 9999
  }, {
    "code" : "XXD",
    "language" : "en",
    "shortcut" : "XXD",
    "description" : "Danzig Gulden",
    "sortNr" : 9999
  }, {
    "code" : "XXG",
    "language" : "de",
    "shortcut" : "XXG",
    "description" : "Goldmark",
    "sortNr" : 9999
  }, {
    "code" : "XXG",
    "language" : "fr",
    "shortcut" : "XXG",
    "description" : "Mark-or",
    "sortNr" : 9999
  }, {
    "code" : "XXG",
    "language" : "en",
    "shortcut" : "XXG",
    "description" : "Gold mark",
    "sortNr" : 9999
  }, {
    "code" : "XXK",
    "language" : "de",
    "shortcut" : "XXK",
    "description" : "Kontrakte",
    "sortNr" : 9999
  }, {
    "code" : "XXK",
    "language" : "fr",
    "shortcut" : "Contr",
    "description" : "Contrats",
    "sortNr" : 9999
  }, {
    "code" : "XXK",
    "language" : "en",
    "shortcut" : "XXC",
    "description" : "Contract",
    "sortNr" : 9999
  }, {
    "code" : "XXM",
    "language" : "de",
    "shortcut" : "XXM",
    "description" : "Mark",
    "sortNr" : 9999
  }, {
    "code" : "XXM",
    "language" : "fr",
    "shortcut" : "XXM",
    "description" : "Mark",
    "sortNr" : 9999
  }, {
    "code" : "XXM",
    "language" : "en",
    "shortcut" : "XXM",
    "description" : "Mark",
    "sortNr" : 9999
  }, {
    "code" : "XXP",
    "language" : "de",
    "shortcut" : "XXP",
    "description" : "Punkte",
    "sortNr" : 9999
  }, {
    "code" : "XXP",
    "language" : "fr",
    "shortcut" : "XXP",
    "description" : "Points",
    "sortNr" : 9999
  }, {
    "code" : "XXP",
    "language" : "en",
    "shortcut" : "XXP",
    "description" : "Points",
    "sortNr" : 9999
  }, {
    "code" : "XXQ",
    "language" : "de",
    "shortcut" : "XXQ",
    "description" : "Papiermark",
    "sortNr" : 9999
  }, {
    "code" : "XXQ",
    "language" : "fr",
    "shortcut" : "XXQ",
    "description" : "Marque de papier",
    "sortNr" : 9999
  }, {
    "code" : "XXQ",
    "language" : "en",
    "shortcut" : "XXQ",
    "description" : "Papermark",
    "sortNr" : 9999
  }, {
    "code" : "XXX",
    "language" : "de",
    "shortcut" : "XXX",
    "description" : "Stück",
    "sortNr" : 9999
  }, {
    "code" : "XXX",
    "language" : "fr",
    "shortcut" : "Unité",
    "description" : "Unité",
    "sortNr" : 9999
  }, {
    "code" : "XXX",
    "language" : "en",
    "shortcut" : "XXX",
    "description" : "Item",
    "sortNr" : 9999
  }, {
    "code" : "XZN",
    "language" : "de",
    "shortcut" : "XZN",
    "description" : "Zink",
    "sortNr" : 9999
  }, {
    "code" : "XZN",
    "language" : "fr",
    "shortcut" : "XZN",
    "description" : "Zinc",
    "sortNr" : 9999
  }, {
    "code" : "XZN",
    "language" : "en",
    "shortcut" : "XZN",
    "description" : "Zinc",
    "sortNr" : 9999
  }, {
    "code" : "YER",
    "language" : "de",
    "shortcut" : "YER",
    "description" : "Jemen Rial",
    "sortNr" : 9999
  }, {
    "code" : "YER",
    "language" : "fr",
    "shortcut" : "YER",
    "description" : "Jemen Rial",
    "sortNr" : 9999
  }, {
    "code" : "YER",
    "language" : "en",
    "shortcut" : "YER",
    "description" : "Jemen Rial",
    "sortNr" : 9999
  }, {
    "code" : "YUM",
    "language" : "de",
    "shortcut" : "YUM",
    "description" : "YUM",
    "sortNr" : 9999
  }, {
    "code" : "YUM",
    "language" : "fr",
    "shortcut" : "YUM",
    "description" : "YUM",
    "sortNr" : 9999
  }, {
    "code" : "YUM",
    "language" : "en",
    "shortcut" : "YUM",
    "description" : "YUM",
    "sortNr" : 9999
  }, {
    "code" : "ZAR",
    "language" : "de",
    "shortcut" : "ZAR",
    "description" : "Südafrikanischer Rand",
    "sortNr" : 140
  }, {
    "code" : "ZAR",
    "language" : "fr",
    "shortcut" : "ZAR",
    "description" : "Rand sud-africain",
    "sortNr" : 140
  }, {
    "code" : "ZAR",
    "language" : "en",
    "shortcut" : "ZAR",
    "description" : "South African Rand",
    "sortNr" : 140
  }, {
    "code" : "ZMK",
    "language" : "de",
    "shortcut" : "ZMK",
    "description" : "Zambian Kwacha",
    "sortNr" : 9999
  }, {
    "code" : "ZMK",
    "language" : "fr",
    "shortcut" : "ZMK",
    "description" : "Zambian Kwacha",
    "sortNr" : 9999
  }, {
    "code" : "ZMK",
    "language" : "en",
    "shortcut" : "ZMK",
    "description" : "Zambian Kwacha",
    "sortNr" : 9999
  }, {
    "code" : "ZMW",
    "language" : "de",
    "shortcut" : "ZMW",
    "description" : "Sambischer Kwacha",
    "sortNr" : 9999
  }, {
    "code" : "ZMW",
    "language" : "fr",
    "shortcut" : "ZMW",
    "description" : "Kwacha Zambien",
    "sortNr" : 9999
  }, {
    "code" : "ZMW",
    "language" : "en",
    "shortcut" : "ZMW",
    "description" : "Zambian Kwacha",
    "sortNr" : 9999
  }, {
    "code" : "ZWD",
    "language" : "de",
    "shortcut" : "ZWD",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  }, {
    "code" : "ZWD",
    "language" : "fr",
    "shortcut" : "ZWD",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  }, {
    "code" : "ZWD",
    "language" : "en",
    "shortcut" : "ZWD",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  }, {
    "code" : "ZWL",
    "language" : "de",
    "shortcut" : "ZWL",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  }, {
    "code" : "ZWL",
    "language" : "fr",
    "shortcut" : "ZWL",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  }, {
    "code" : "ZWL",
    "language" : "en",
    "shortcut" : "ZWL",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  }, {
    "code" : "ZWN",
    "language" : "de",
    "shortcut" : "ZWN",
    "description" : "Dollar (Zimbabwe) (Währungsreform) neu ZWR",
    "sortNr" : 9999
  }, {
    "code" : "ZWN",
    "language" : "fr",
    "shortcut" : "ZWN",
    "description" : "Dollar (Zimbabwe)",
    "sortNr" : 9999
  }, {
    "code" : "ZWN",
    "language" : "en",
    "shortcut" : "ZWN",
    "description" : "Dollar (Zimbabwe)",
    "sortNr" : 9999
  }, {
    "code" : "ZWR",
    "language" : "de",
    "shortcut" : "ZWR",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  }, {
    "code" : "ZWR",
    "language" : "fr",
    "shortcut" : "ZWR",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  }, {
    "code" : "ZWR",
    "language" : "en",
    "shortcut" : "ZWR",
    "description" : "Simbabwe Dollar",
    "sortNr" : 9999
  } ]
