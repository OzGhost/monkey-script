var src = src || {}
  src.collateralSubtype = [ {
    "code" : "1",
    "language" : "de",
    "shortcut" : "EFH",
    "description" : "Einfamilienhaus",
    "sortNr" : 1
  }, {
    "code" : "1",
    "language" : "fr",
    "shortcut" : "EFH",
    "description" : "Maison familiale",
    "sortNr" : 1
  }, {
    "code" : "1",
    "language" : "en",
    "shortcut" : "EFH",
    "description" : "Single-family house",
    "sortNr" : 1
  }, {
    "code" : "2",
    "language" : "de",
    "shortcut" : "STWE",
    "description" : "Stockwerkeigentum",
    "sortNr" : 2
  }, {
    "code" : "2",
    "language" : "fr",
    "shortcut" : "STWE",
    "description" : "Propriété par étages",
    "sortNr" : 2
  }, {
    "code" : "2",
    "language" : "en",
    "shortcut" : "STWE",
    "description" : "Residential flat",
    "sortNr" : 2
  }, {
    "code" : "3",
    "language" : "de",
    "shortcut" : "MFH",
    "description" : "Mehrfamilienhaus",
    "sortNr" : 3
  }, {
    "code" : "3",
    "language" : "fr",
    "shortcut" : "MFH",
    "description" : "Immeuble locatif",
    "sortNr" : 3
  }, {
    "code" : "3",
    "language" : "en",
    "shortcut" : "MFH",
    "description" : "Multi-family house",
    "sortNr" : 3
  }, {
    "code" : "4",
    "language" : "de",
    "shortcut" : "WoBür",
    "description" : "Wohnen / Büro",
    "sortNr" : 4
  }, {
    "code" : "4",
    "language" : "fr",
    "shortcut" : "WoBür",
    "description" : "Habitation/bureau",
    "sortNr" : 4
  }, {
    "code" : "4",
    "language" : "en",
    "shortcut" : "WoBür",
    "description" : "Home/office",
    "sortNr" : 4
  }, {
    "code" : "5",
    "language" : "de",
    "shortcut" : "WoGew",
    "description" : "Wohnen / Gewerbe",
    "sortNr" : 5
  }, {
    "code" : "5",
    "language" : "fr",
    "shortcut" : "WoGew",
    "description" : "Habitation/artisanat",
    "sortNr" : 5
  }, {
    "code" : "5",
    "language" : "en",
    "shortcut" : "WoGew",
    "description" : "Home/commerce",
    "sortNr" : 5
  }, {
    "code" : "6",
    "language" : "de",
    "shortcut" : "LW",
    "description" : "Landwirtschaft",
    "sortNr" : 6
  }, {
    "code" : "6",
    "language" : "fr",
    "shortcut" : "LW",
    "description" : "Agriculture",
    "sortNr" : 6
  }, {
    "code" : "6",
    "language" : "en",
    "shortcut" : "LW",
    "description" : "Agriculture",
    "sortNr" : 6
  }, {
    "code" : "7",
    "language" : "de",
    "shortcut" : "Land",
    "description" : "Land",
    "sortNr" : 7
  }, {
    "code" : "7",
    "language" : "fr",
    "shortcut" : "Terra",
    "description" : "Terrain",
    "sortNr" : 7
  }, {
    "code" : "7",
    "language" : "en",
    "shortcut" : "land",
    "description" : "Country",
    "sortNr" : 7
  }, {
    "code" : "9",
    "language" : "de",
    "shortcut" : "G/I",
    "description" : "Gewerbe / Industrie",
    "sortNr" : 9
  }, {
    "code" : "9",
    "language" : "fr",
    "shortcut" : "G/I",
    "description" : "Commerce / Industrie",
    "sortNr" : 9
  }, {
    "code" : "9",
    "language" : "en",
    "shortcut" : "G/I",
    "description" : "Commerce/industry",
    "sortNr" : 9
  }, {
    "code" : "11",
    "language" : "de",
    "shortcut" : "ÜObj",
    "description" : "Übrige Objekte",
    "sortNr" : 11
  }, {
    "code" : "11",
    "language" : "fr",
    "shortcut" : "ÜObj",
    "description" : "Autres immeubles",
    "sortNr" : 11
  }, {
    "code" : "11",
    "language" : "en",
    "shortcut" : "ÜObj",
    "description" : "Other objects",
    "sortNr" : 11
  }, {
    "code" : "1101",
    "language" : "de",
    "shortcut" : "GHEB",
    "description" : "Guthaben eigene Bank",
    "sortNr" : 1101
  }, {
    "code" : "1101",
    "language" : "fr",
    "shortcut" : "GHEB",
    "description" : "Avoir, propre banque",
    "sortNr" : 1101
  }, {
    "code" : "1101",
    "language" : "en",
    "shortcut" : "GHEB",
    "description" : "Credit own bank",
    "sortNr" : 1101
  }, {
    "code" : "1102",
    "language" : "de",
    "shortcut" : "GHFW",
    "description" : "Guthaben FW eigene Bank",
    "sortNr" : 1102
  }, {
    "code" : "1102",
    "language" : "fr",
    "shortcut" : "GHFW",
    "description" : "Avoir ME, propre banque",
    "sortNr" : 1102
  }, {
    "code" : "1102",
    "language" : "en",
    "shortcut" : "GHFW",
    "description" : "Credit balance foreign currency own bank",
    "sortNr" : 1102
  }, {
    "code" : "1104",
    "language" : "de",
    "shortcut" : "GH2S",
    "description" : "Guthaben 2. Säule eigene Bank",
    "sortNr" : 1104
  }, {
    "code" : "1104",
    "language" : "fr",
    "shortcut" : "GH2S",
    "description" : "Avoir 2e pilier, propre banque",
    "sortNr" : 1104
  }, {
    "code" : "1104",
    "language" : "en",
    "shortcut" : "GH2S",
    "description" : "Credit balance second-pillar own bank",
    "sortNr" : 1104
  }, {
    "code" : "1105",
    "language" : "de",
    "shortcut" : "GH3S",
    "description" : "Guthaben 3. Säule eigene Bank",
    "sortNr" : 1105
  }, {
    "code" : "1105",
    "language" : "fr",
    "shortcut" : "GH3S",
    "description" : "Avoir 3e pilier, propre banque",
    "sortNr" : 1105
  }, {
    "code" : "1105",
    "language" : "en",
    "shortcut" : "GH3S",
    "description" : "Credit balance pillar 3 own bank",
    "sortNr" : 1105
  }, {
    "code" : "1201",
    "language" : "de",
    "shortcut" : "DPEB",
    "description" : "Wertschriftendepot eigene Bank",
    "sortNr" : 1201
  }, {
    "code" : "1201",
    "language" : "fr",
    "shortcut" : "DPEB",
    "description" : "Dépôt titres, propre banque",
    "sortNr" : 1201
  }, {
    "code" : "1201",
    "language" : "en",
    "shortcut" : "DPEB",
    "description" : "Securities custody account - own bank",
    "sortNr" : 1201
  }, {
    "code" : "1202",
    "language" : "de",
    "shortcut" : "DPWE",
    "description" : "Wertschriftendepot eigene Bank (wirtschaftliche Einheit)",
    "sortNr" : 1202
  }, {
    "code" : "1202",
    "language" : "fr",
    "shortcut" : "DPWE",
    "description" : "Dépôt titres, propre banque (unité économique)",
    "sortNr" : 1202
  }, {
    "code" : "1202",
    "language" : "en",
    "shortcut" : "DPWE",
    "description" : "Securities own bank (financial entity)",
    "sortNr" : 1202
  }, {
    "code" : "1203",
    "language" : "de",
    "shortcut" : "3SFD",
    "description" : "Guthaben 3. Säule Fonds",
    "sortNr" : 1203
  }, {
    "code" : "1203",
    "language" : "fr",
    "shortcut" : "3SFD",
    "description" : "Avoir 3e pilier, fonds",
    "sortNr" : 1203
  }, {
    "code" : "1203",
    "language" : "en",
    "shortcut" : "3SFD",
    "description" : "Credit balance pillar 3 fund",
    "sortNr" : 1203
  }, {
    "code" : "1401",
    "language" : "de",
    "shortcut" : "TRP F",
    "description" : "Todesfallrisikopolice (frei)",
    "sortNr" : 1401
  }, {
    "code" : "1401",
    "language" : "fr",
    "shortcut" : "TRP F",
    "description" : "Police d'assurance risque décès (libre)",
    "sortNr" : 1401
  }, {
    "code" : "1401",
    "language" : "en",
    "shortcut" : "TRP F",
    "description" : "Risk-of-death policy (free)",
    "sortNr" : 1401
  }, {
    "code" : "1402",
    "language" : "de",
    "shortcut" : "TRP G",
    "description" : "Todesfallrisikopolice (gebunden)",
    "sortNr" : 1402
  }, {
    "code" : "1402",
    "language" : "fr",
    "shortcut" : "TRP G",
    "description" : "Police d'assurance risque décès (liée)",
    "sortNr" : 1402
  }, {
    "code" : "1402",
    "language" : "en",
    "shortcut" : "TRP G",
    "description" : "Risk-of-death policy (linked)",
    "sortNr" : 1402
  }, {
    "code" : "1403",
    "language" : "de",
    "shortcut" : "LVP F",
    "description" : "Lebensversicherungspolice (frei)",
    "sortNr" : 1403
  }, {
    "code" : "1403",
    "language" : "fr",
    "shortcut" : "LVP F",
    "description" : "Police d'assurance vie (libre)",
    "sortNr" : 1403
  }, {
    "code" : "1403",
    "language" : "en",
    "shortcut" : "LVP F",
    "description" : "Life insurance policy (free)",
    "sortNr" : 1403
  }, {
    "code" : "1404",
    "language" : "de",
    "shortcut" : "LVPFA",
    "description" : "Lebensversicherungspolice (frei) Ausland",
    "sortNr" : 1404
  }, {
    "code" : "1404",
    "language" : "fr",
    "shortcut" : "LVPFA",
    "description" : "Police d'assurance vie (libre) étranger",
    "sortNr" : 1404
  }, {
    "code" : "1404",
    "language" : "en",
    "shortcut" : "LVPFA",
    "description" : "Life insurance policy (free) foreign",
    "sortNr" : 1404
  }, {
    "code" : "1405",
    "language" : "de",
    "shortcut" : "PK 2S",
    "description" : "Pensionskasse (2. Säule)",
    "sortNr" : 1405
  }, {
    "code" : "1405",
    "language" : "fr",
    "shortcut" : "PK 2S",
    "description" : "Caisse de pension (2e pilier)",
    "sortNr" : 1405
  }, {
    "code" : "1405",
    "language" : "en",
    "shortcut" : "PK 2S",
    "description" : "Pension fund (pillar 2)",
    "sortNr" : 1405
  }, {
    "code" : "1406",
    "language" : "de",
    "shortcut" : "VP 3a",
    "description" : "Vorsorgepolice 3. Säule (gebunden)",
    "sortNr" : 1406
  }, {
    "code" : "1406",
    "language" : "fr",
    "shortcut" : "VP 3a",
    "description" : "Police de prévoyance du 3e pilier (lié)",
    "sortNr" : 1406
  }, {
    "code" : "1406",
    "language" : "en",
    "shortcut" : "VP 3a",
    "description" : "Third-pillar insurance policy (tied)",
    "sortNr" : 1406
  }, {
    "code" : "1407",
    "language" : "de",
    "shortcut" : "LVF3b",
    "description" : "Lebensversicherungspolice Fonds (frei)",
    "sortNr" : 1407
  }, {
    "code" : "1407",
    "language" : "fr",
    "shortcut" : "LVF3b",
    "description" : "Police d'assurance vie en fonds (libre)",
    "sortNr" : 1407
  }, {
    "code" : "1407",
    "language" : "en",
    "shortcut" : "LVF3b",
    "description" : "Life insurance policy fund (free)",
    "sortNr" : 1407
  }, {
    "code" : "1408",
    "language" : "de",
    "shortcut" : "LVF A",
    "description" : "Lebensversicherungspolice Fonds (frei) Ausland",
    "sortNr" : 1408
  }, {
    "code" : "1408",
    "language" : "fr",
    "shortcut" : "LVF A",
    "description" : "Police d'assurance vie en fonds (libre) étranger",
    "sortNr" : 1408
  }, {
    "code" : "1408",
    "language" : "en",
    "shortcut" : "LVF A",
    "description" : "Life insurance policy funds (free) foreign",
    "sortNr" : 1408
  }, {
    "code" : "1409",
    "language" : "de",
    "shortcut" : "VPF3a",
    "description" : "Vorsorgepolice 3. Säule Fonds (gebunden)",
    "sortNr" : 1409
  }, {
    "code" : "1409",
    "language" : "fr",
    "shortcut" : "VPF3a",
    "description" : "Police de prévoyance du 3e pilier (lié à des fonds)",
    "sortNr" : 1409
  }, {
    "code" : "1409",
    "language" : "en",
    "shortcut" : "VPF3a",
    "description" : "Pillar3 insurance policy funds (tied)",
    "sortNr" : 1409
  }, {
    "code" : "1501",
    "language" : "de",
    "shortcut" : "SOBU",
    "description" : "Solidarbürgschaft",
    "sortNr" : 1501
  }, {
    "code" : "1501",
    "language" : "fr",
    "shortcut" : "SOBU",
    "description" : "Cautionnement solidaire",
    "sortNr" : 1501
  }, {
    "code" : "1501",
    "language" : "en",
    "shortcut" : "SOBU",
    "description" : "Joint guarantee",
    "sortNr" : 1501
  }, {
    "code" : "1502",
    "language" : "de",
    "shortcut" : "EIBU",
    "description" : "Einfache Bürgschaft",
    "sortNr" : 1502
  }, {
    "code" : "1502",
    "language" : "fr",
    "shortcut" : "EIBU",
    "description" : "Cautionnement simple",
    "sortNr" : 1502
  }, {
    "code" : "1502",
    "language" : "en",
    "shortcut" : "EIBU",
    "description" : "Single guarantee",
    "sortNr" : 1502
  }, {
    "code" : "1503",
    "language" : "de",
    "shortcut" : "AUBU",
    "description" : "Ausfallbürgschaft",
    "sortNr" : 1503
  }, {
    "code" : "1503",
    "language" : "fr",
    "shortcut" : "AUBU",
    "description" : "Cautionnement en cas de défaillance",
    "sortNr" : 1503
  }, {
    "code" : "1503",
    "language" : "en",
    "shortcut" : "AUBU",
    "description" : "Loan loss guarantee",
    "sortNr" : 1503
  }, {
    "code" : "1504",
    "language" : "de",
    "shortcut" : "WEBU",
    "description" : "Bürgschaft WEG",
    "sortNr" : 1504
  }, {
    "code" : "1504",
    "language" : "fr",
    "shortcut" : "WEBU",
    "description" : "Cautionnement EPL",
    "sortNr" : 1504
  }, {
    "code" : "1504",
    "language" : "en",
    "shortcut" : "WEBU",
    "description" : "HOA guarantee",
    "sortNr" : 1504
  }, {
    "code" : "1505",
    "language" : "de",
    "shortcut" : "GEBU",
    "description" : "Bürgschaftsgenossenschaft",
    "sortNr" : 1505
  }, {
    "code" : "1505",
    "language" : "fr",
    "shortcut" : "GEBU",
    "description" : "Coopérative de cautionnement",
    "sortNr" : 1505
  }, {
    "code" : "1505",
    "language" : "en",
    "shortcut" : "GEBU",
    "description" : "Guarantee cooperative",
    "sortNr" : 1505
  }, {
    "code" : "1506",
    "language" : "de",
    "shortcut" : "BUWE",
    "description" : "Bürgschaft (wirtschaftliche Einheit)",
    "sortNr" : 1506
  }, {
    "code" : "1506",
    "language" : "fr",
    "shortcut" : "BUWE",
    "description" : "Cautionnement (unité économique)",
    "sortNr" : 1506
  }, {
    "code" : "1506",
    "language" : "en",
    "shortcut" : "BUWE",
    "description" : "Guarantee (financial entity)",
    "sortNr" : 1506
  }, {
    "code" : "1605",
    "language" : "de",
    "shortcut" : "B.n.S",
    "description" : "Blanko nachrangig (vom System generiert)",
    "sortNr" : 9999
  }, {
    "code" : "1605",
    "language" : "fr",
    "shortcut" : "B.s.s",
    "description" : "En blanc subordonné (généré par le système)",
    "sortNr" : 9999
  }, {
    "code" : "1605",
    "language" : "en",
    "shortcut" : "U.s.s",
    "description" : "Unsecured subordinated (generated by system)",
    "sortNr" : 9999
  }, {
    "code" : "1606",
    "language" : "de",
    "shortcut" : "GLOZ",
    "description" : "Globalzession",
    "sortNr" : 1601
  }, {
    "code" : "1606",
    "language" : "fr",
    "shortcut" : "GLOZ",
    "description" : "Cession globale",
    "sortNr" : 1601
  }, {
    "code" : "1606",
    "language" : "en",
    "shortcut" : "GLOZ",
    "description" : "Global assignment",
    "sortNr" : 1601
  }, {
    "code" : "1607",
    "language" : "de",
    "shortcut" : "GLOZa",
    "description" : "Globalzession anrechenbar",
    "sortNr" : 1602
  }, {
    "code" : "1607",
    "language" : "fr",
    "shortcut" : "GLOZa",
    "description" : "Cession globale déterminante",
    "sortNr" : 1602
  }, {
    "code" : "1607",
    "language" : "en",
    "shortcut" : "GLOZa",
    "description" : "Global assignment - eligible",
    "sortNr" : 1602
  }, {
    "code" : "1608",
    "language" : "de",
    "shortcut" : "EINZ",
    "description" : "Einzelzession",
    "sortNr" : 1603
  }, {
    "code" : "1608",
    "language" : "fr",
    "shortcut" : "EINZ",
    "description" : "Cession ind",
    "sortNr" : 1603
  }, {
    "code" : "1608",
    "language" : "en",
    "shortcut" : "EINZ",
    "description" : "Individual assignment",
    "sortNr" : 1603
  }, {
    "code" : "1609",
    "language" : "de",
    "shortcut" : "EINZa",
    "description" : "Einzelzession anrechenbar",
    "sortNr" : 1604
  }, {
    "code" : "1609",
    "language" : "fr",
    "shortcut" : "EINZa",
    "description" : "Cession individuelle déterminante",
    "sortNr" : 1604
  }, {
    "code" : "1609",
    "language" : "en",
    "shortcut" : "EINZa",
    "description" : "Individual assigment - eligible",
    "sortNr" : 1604
  }, {
    "code" : "1610",
    "language" : "de",
    "shortcut" : "GHDB",
    "description" : "Guthaben Drittbank",
    "sortNr" : 1605
  }, {
    "code" : "1610",
    "language" : "fr",
    "shortcut" : "GHDB",
    "description" : "Avoir, banque tierce",
    "sortNr" : 1605
  }, {
    "code" : "1610",
    "language" : "en",
    "shortcut" : "GHDB",
    "description" : "Credit balance third-party bank",
    "sortNr" : 1605
  }, {
    "code" : "1611",
    "language" : "de",
    "shortcut" : "GHDB2",
    "description" : "Guthaben 2. Säule",
    "sortNr" : 1606
  }, {
    "code" : "1611",
    "language" : "fr",
    "shortcut" : "GHDB2",
    "description" : "Avoir 2e pilier",
    "sortNr" : 1606
  }, {
    "code" : "1611",
    "language" : "en",
    "shortcut" : "GHDB2",
    "description" : "Credit balance second pillar",
    "sortNr" : 1606
  }, {
    "code" : "1612",
    "language" : "de",
    "shortcut" : "GHDB3",
    "description" : "Guthaben 3. Säule Drittbank",
    "sortNr" : 1607
  }, {
    "code" : "1612",
    "language" : "fr",
    "shortcut" : "GHDB3",
    "description" : "Avoir 3e pilier, banque tierce",
    "sortNr" : 1607
  }, {
    "code" : "1612",
    "language" : "en",
    "shortcut" : "GHDB3",
    "description" : "Credit balance third-pillar third-party bank",
    "sortNr" : 1607
  }, {
    "code" : "1613",
    "language" : "de",
    "shortcut" : "WSDB",
    "description" : "Wertschriftendepot Drittbank",
    "sortNr" : 1608
  }, {
    "code" : "1613",
    "language" : "fr",
    "shortcut" : "WSDB",
    "description" : "Dépôt titre, banque tierce",
    "sortNr" : 1608
  }, {
    "code" : "1613",
    "language" : "en",
    "shortcut" : "WSDB",
    "description" : "Securities custody account - third-party bank",
    "sortNr" : 1608
  }, {
    "code" : "1614",
    "language" : "de",
    "shortcut" : "GARAN",
    "description" : "Bankgarantie",
    "sortNr" : 1609
  }, {
    "code" : "1614",
    "language" : "fr",
    "shortcut" : "GARAN",
    "description" : "Garantie bancaire",
    "sortNr" : 1609
  }, {
    "code" : "1614",
    "language" : "en",
    "shortcut" : "GARAN",
    "description" : "Bank guarantee",
    "sortNr" : 1609
  }, {
    "code" : "1615",
    "language" : "de",
    "shortcut" : "ETV",
    "description" : "Eigentumsvorbehalt",
    "sortNr" : 1610
  }, {
    "code" : "1615",
    "language" : "fr",
    "shortcut" : "ETV",
    "description" : "Réserve de propriété",
    "sortNr" : 1610
  }, {
    "code" : "1615",
    "language" : "en",
    "shortcut" : "ETV",
    "description" : "Retention of title",
    "sortNr" : 1610
  }, {
    "code" : "1616",
    "language" : "de",
    "shortcut" : "Blank",
    "description" : "Blanko",
    "sortNr" : 1611
  }, {
    "code" : "1616",
    "language" : "fr",
    "shortcut" : "Blank",
    "description" : "En blanc",
    "sortNr" : 1611
  }, {
    "code" : "1616",
    "language" : "en",
    "shortcut" : "Blank",
    "description" : "Blank",
    "sortNr" : 1611
  }, {
    "code" : "1617",
    "language" : "de",
    "shortcut" : "üSich",
    "description" : "übrige Sicherheiten",
    "sortNr" : 1617
  }, {
    "code" : "1617",
    "language" : "fr",
    "shortcut" : "üSich",
    "description" : "Autres garanties",
    "sortNr" : 1617
  }, {
    "code" : "1617",
    "language" : "en",
    "shortcut" : "üSich",
    "description" : "Other collateral",
    "sortNr" : 1617
  }, {
    "code" : "1618",
    "language" : "de",
    "shortcut" : "ASach",
    "description" : "Abtretung Sachversicherungsansprüche",
    "sortNr" : 1613
  }, {
    "code" : "1618",
    "language" : "fr",
    "shortcut" : "ASach",
    "description" : "Cession de droits aux prestations de l'assurance chose",
    "sortNr" : 1613
  }, {
    "code" : "1618",
    "language" : "en",
    "shortcut" : "ASach",
    "description" : "Assignment of property insurance claims",
    "sortNr" : 1613
  }, {
    "code" : "1619",
    "language" : "de",
    "shortcut" : "AküFo",
    "description" : "Abtretung künftiger Forderungen",
    "sortNr" : 1614
  }, {
    "code" : "1619",
    "language" : "fr",
    "shortcut" : "AküFo",
    "description" : "Cession de créances futures",
    "sortNr" : 1614
  }, {
    "code" : "1619",
    "language" : "en",
    "shortcut" : "AküFo",
    "description" : "Assignment of future claims",
    "sortNr" : 1614
  }, {
    "code" : "3310",
    "language" : "de",
    "shortcut" : "PF3",
    "description" : "Portfolio Sparen 3",
    "sortNr" : 3310
  }, {
    "code" : "3310",
    "language" : "fr",
    "shortcut" : "PF3",
    "description" : "Portefeuille épargne 3",
    "sortNr" : 3310
  }, {
    "code" : "3310",
    "language" : "en",
    "shortcut" : "PF3",
    "description" : "Portfolio Sparen 3",
    "sortNr" : 3310
  } ]
